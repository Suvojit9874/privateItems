package com.ignite.assettracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssetTrackerTests {

	@Test
	void contextLoads() {
	}

}
