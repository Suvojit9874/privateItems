package com.ignite.assettracker.service;

import com.ignite.assettracker.dto.AssetDetailsDto;
import com.ignite.assettracker.dto.OptionDto;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface AssetDetailsService {
    public List<AssetDetailsDto> getAllAssets(Authentication authentication, String bId);

    public AssetDetailsDto addNewAsset(AssetDetailsDto assetDetailsDto, Authentication authentication);

    List<AssetDetailsDto> getAssetsByUser(Authentication authentication);

    public Integer deleteAssetById(Integer id);

    public AssetDetailsDto updateAssetById(Integer id, AssetDetailsDto assetDetailsDto);

    List<OptionDto> getAssetUserOption(Authentication authentication);

    List<OptionDto> getManufacturerOptions();

    List<OptionDto> getLocationOptions();

    AssetDetailsDto updateOldAsset(AssetDetailsDto assetDetailsDto, Authentication authentication);
}
