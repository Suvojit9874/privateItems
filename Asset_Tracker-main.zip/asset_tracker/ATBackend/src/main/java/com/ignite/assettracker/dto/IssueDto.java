package com.ignite.assettracker.dto;

import com.ignite.assettracker.model.Category;
import com.ignite.assettracker.model.Issues;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class IssueDto {
    private Integer issueId;
    private String issueName;
    private String issueDescription;
    private CategoryDto categoryDto;
    private String solution;
    private Boolean solutionAvailable;

    public IssueDto(Issues issues){
        this.issueId=issues.getIssueId();
        this.issueName=issues.getIssueName();
        this.issueDescription=issues.getIssueDescription();
        this.categoryDto=new CategoryDto(issues.getCategory());
        this.solution=issues.getSolution();
        this.solutionAvailable=issues.getSolutionAvailable();
    }
}
