package com.ignite.assettracker.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ignite.assettracker.dto.UserDashboardDto;
import com.ignite.assettracker.service.DashboardService;

@RestController
@RequestMapping("/userDashboard")
public class UserDashboardController {
    
    @Autowired
    private DashboardService dashboardService;

    @GetMapping("/getCounts")
    public ResponseEntity<UserDashboardDto> getUserIssueCount(Authentication authentication){
        UserDashboardDto userDashboardDto=dashboardService.getUserDashboard(authentication);
        return ResponseEntity.ok(userDashboardDto);
    }
}
