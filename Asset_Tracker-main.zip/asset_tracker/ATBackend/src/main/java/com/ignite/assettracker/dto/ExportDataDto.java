package com.ignite.assettracker.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExportDataDto {
    private Integer id;
    private Integer empId;
    private String name;
    private String email;
    private String tempBatch;
    private String batch;
    private String assetId;
    private String manufacturerName;
    private Boolean laptopCollected;
    private Boolean bitlockerStatus;
    private Boolean vdiInstalled;
    private Boolean vdiWorking;
    private Boolean cpaIssue;
    private Boolean duoWorking;
    private Boolean zScalerWorking;
    private Boolean gwsIssue;
    private Boolean adminLogin;
}
