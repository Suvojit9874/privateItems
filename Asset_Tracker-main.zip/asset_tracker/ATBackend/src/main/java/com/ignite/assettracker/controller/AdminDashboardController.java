package com.ignite.assettracker.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ignite.assettracker.dto.AdminDashboardDto;
import com.ignite.assettracker.dto.UserDashboardDto;
import com.ignite.assettracker.service.DashboardService;

@RestController
@RequestMapping("/adminDashboard")
@CrossOrigin("*")
public class AdminDashboardController {

    @Autowired
    private DashboardService dasboardService;
    
    @GetMapping("/getCounts/{bid}")
    public ResponseEntity<AdminDashboardDto> getAdminIssueCount(@PathVariable String bid){
        AdminDashboardDto totalIsuue=dasboardService.getAdminIssueCount(bid);
        return ResponseEntity.ok(totalIsuue);
    }

    
}
