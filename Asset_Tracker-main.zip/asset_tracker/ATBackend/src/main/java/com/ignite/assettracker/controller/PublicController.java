package com.ignite.assettracker.controller;

import com.ignite.assettracker.dto.AssetDetailsDto;
import com.ignite.assettracker.service.AssetDetailsService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;

import java.util.List;

@RestController
@RequestMapping("/public")
public class PublicController {
    AssetDetailsService assetDetailsService;
    
    @GetMapping("/test")
    public ResponseEntity<Object> getAllAssets(Authentication authentication) {
    

        // List<AssetDetailsDto> assetDetailsDtoList = assetDetailsService.getAllAssets(authentication);
        return new ResponseEntity<>("working", HttpStatus.OK);
    }

  
}
