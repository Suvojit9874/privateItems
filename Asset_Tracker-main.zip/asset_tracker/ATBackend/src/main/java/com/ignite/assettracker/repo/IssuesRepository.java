package com.ignite.assettracker.repo;

import com.ignite.assettracker.model.Category;
import com.ignite.assettracker.model.Issues;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface IssuesRepository extends JpaRepository<Issues, Integer> {
    List<Issues> findByCategory(Category category);

    Long countByCategory(Optional<Category> hard);

    // Issues findByName();

//    Long countByUserIdAndStatusName(Integer id,String statusName);

}
