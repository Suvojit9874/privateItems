package com.ignite.assettracker.serviceimpliment;

import com.ignite.assettracker.dto.AssetIssueDtoRequest;
import com.ignite.assettracker.dto.IssueDto;
import com.ignite.assettracker.dto.OptionDto;
import com.ignite.assettracker.model.*;
import com.ignite.assettracker.repo.*;
import com.ignite.assettracker.service.AssetIssueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AssetIssueServiceImpl implements AssetIssueService {
    @Autowired
    private UserRepo userRepo;
    @Autowired
    private AssetDetailsRepository assetDetailsRepository;
    @Autowired
    private IssuesRepository issuesRepository;
    @Autowired
    private AssetIssueRepository assetIssueRepository;
    @Autowired
    private StatusRepository statusRepository;
    @Autowired
    private CategoryRepository categoryRepository;


    public List<AssetIssueDtoRequest> getAllAssets(String bId) {
        List<AssetIssue> assetIssues = assetIssueRepository.findAllAssetOfBatch(bId);
        List<AssetIssueDtoRequest> assetIssueDtos = new ArrayList<>();
        for (AssetIssue assetIssue : assetIssues) {
            assetIssueDtos.add(new AssetIssueDtoRequest(assetIssue));
        }
        return assetIssueDtos;
    }

    @Override
    public AssetIssueDtoRequest addNewAssetIssue(AssetIssueDtoRequest assetIssueDto, Authentication authentication) {
        AssetDetails assetDetails = assetDetailsRepository.findById(assetIssueDto.getAaId()).get();
        Status status = statusRepository.findById(1).get();
        Issues issues = issuesRepository.findById(assetIssueDto.getIssueId()).get();
        AssetIssue assetIssue = AssetIssueDtoRequest.getAssetDetails(assetDetails, status, issues, assetIssueDto.getIssueComment(),assetIssueDto);
        AssetIssue assetIssue1 = assetIssueRepository.save(assetIssue);
        return new AssetIssueDtoRequest(assetIssue1);
    }

    @Override
    public AssetIssueDtoRequest updaetAssetIssue(Integer aaid, AssetIssueDtoRequest assetIssueDto, Authentication authentication) {
        System.out.println(assetIssueDto + "---" + aaid);
        AssetIssue assetIssue = assetIssueRepository.findById(aaid).get();
        assetIssue.setIdmReply(assetIssueDto.getIdmReply());
        if (assetIssueDto.getStatusId() != null) {
            Optional<Status> status = statusRepository.findById(assetIssueDto.getStatusId());
            if (status.isPresent()) {
                assetIssue.setStatus(status.get());
                if(status.get().getStatusId()==2){
                    assetIssue.setResolvedAt(LocalDateTime.now());
                }
            }
        }
        assetIssue.setTicketNumber(assetIssueDto.getTicketNumber());
        assetIssue.setIdmReply(assetIssueDto.getIdmReply());
        assetIssue.setIssueComment(assetIssueDto.getIssueComment());
        Issues issues=issuesRepository.findById(assetIssueDto.getIssueId()).get();
        AssetDetails assetDetails=assetDetailsRepository.findById(assetIssueDto.getAaId()).get();
        assetIssue.setAssetDetails(assetDetails);
        assetIssue.setIssues(issues);
        assetIssue.setIdmEmpId(assetIssueDto.getIdmEmpId());
        assetIssue.setIdmName(assetIssueDto.getIdmName());
        assetIssue.setUserSolution(assetIssueDto.getUserSolution());
        AssetIssue assetIssue1 = assetIssueRepository.save(assetIssue);

        return new AssetIssueDtoRequest(assetIssue1);
    }


    public static LocalDateTime convertTimestampToLocalDateTime(long timestamp) {
        LocalDateTime localDateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(timestamp), ZoneId.systemDefault());
        return localDateTime;
    }

    @Override
    public List<OptionDto> getAllCategory() {
        List<Category> categoryList = categoryRepository.findAll();
        List<OptionDto> options = new ArrayList<>();
        for (Category category : categoryList) {
            OptionDto optionDto = new OptionDto(category.getCategoryId(), category.getCategoryName());
            options.add(optionDto);
        }
        return options;
    }

    @Override
    public List<OptionDto> getIssueByCategoryId(Integer catId) {
        List<OptionDto> options = new ArrayList<>();
        Optional<Category> category = categoryRepository.findById(catId);
        if (category.isEmpty()) {
            return options;
        }
        List<Issues> issuesList = issuesRepository.findByCategory(category.orElse(null));
        for (Issues issues : issuesList) {
            OptionDto optionDto = new OptionDto(issues.getIssueId(), issues.getIssueName());
            options.add(optionDto);
        }
        return options;
    }

    @Override
    public List<AssetIssueDtoRequest> getAllAssetIssuesOfUser(Authentication authentication) {
        Optional<User> user=userRepo.findByEmail(authentication.getName());
        if(user.isEmpty()){
            return null;
        }
        List<AssetDetails> assetList=assetDetailsRepository.findByUser(user.get());
        List<AssetIssue> assetIssues = assetIssueRepository.findByAssetDetailsInOrderByReportedAtDesc(assetList);
        List<AssetIssueDtoRequest> assetIssueDtos = new ArrayList<>();
        for (AssetIssue assetIssue : assetIssues) {
            assetIssueDtos.add(new AssetIssueDtoRequest(assetIssue));
        }
        return assetIssueDtos;
    }

    @Override
    public List<OptionDto> getAllStatus() {
        List<OptionDto> options = new ArrayList<>();
        List<Status> statusList=statusRepository.findAll();
        for (Status status : statusList) {
            OptionDto optionDto = new OptionDto(status.getStatusId(), status.getStatusName());
            options.add(optionDto);
        }
        return options;
    }

    @Override
    public IssueDto getIssueById(Integer issId) {
        Optional<Issues> assetDetails=issuesRepository.findById(issId);
        if(assetDetails.isPresent()){
            return new IssueDto(assetDetails.get());
        }else{
        return null;
        }
    }
}
