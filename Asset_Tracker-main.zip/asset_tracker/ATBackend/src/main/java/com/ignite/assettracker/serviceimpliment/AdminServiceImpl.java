package com.ignite.assettracker.serviceimpliment;

import com.ignite.assettracker.dto.*;
import com.ignite.assettracker.model.AssetDetails;
import com.ignite.assettracker.model.Role;
import com.ignite.assettracker.model.User;
import com.ignite.assettracker.repo.AssetDetailsRepository;
import com.ignite.assettracker.repo.UserRepo;
import com.ignite.assettracker.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Service
public class AdminServiceImpl implements AdminService {
    @Value("${defaultPassword}")
    String password;
    private final PasswordEncoder passwordEncoder;
    @Autowired
    private UserRepo userRepo;
    @Autowired
    private AssetDetailsRepository assetDetailsRepository;

    public AdminServiceImpl(UserRepo userRepo, PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }


    public void saveAllUsers(List<UserBulkDto> userDto) {
        UserBulkDto userBulkDto = new UserBulkDto();

        List<User> userList = new ArrayList<>();
        for (UserBulkDto userBulkDto1 : userDto) {
            userList.add(convertToEntity(userBulkDto1));
        }

        userRepo.saveAll(userList);
    }

    public User convertToEntity(UserBulkDto uDto) {
        User user = new User();
        user.setUserId(uDto.getUserId());
        user.setEmail(uDto.getEmail());
        user.setName(uDto.getName());
        user.setEmpId(uDto.getEmpId());
        user.setTempBatch(uDto.getTempBatch());
        user.setMainBatch(uDto.getMainBatch());
        user.setIsEnabled(true);
//        user.setPassword(uDto.getPassword());
        user.setPassword(passwordEncoder.encode(uDto.getPassword()));
        user.setRole(Role.TRAINEE);

        return user;

    }


    @Override
    public List<OptionDto> getBatches() {
        List<String> batchList = userRepo.getBatches();
        List<OptionDto> options = new ArrayList<>();
        for (int i = 0; i < batchList.size(); i++) {
            OptionDto optionDto = new OptionDto(i + 1, batchList.get(i));
            options.add(optionDto);
        }
        return options;

    }

    @Override
    public Boolean resetPassword(Integer id) {
        Optional<User> optionaluserdata = userRepo.findById(id);
        if (optionaluserdata.isPresent()) {
            User user = optionaluserdata.get();
            user.setPassword(passwordEncoder.encode(password));
            userRepo.save(user);
            return true;
        }
        return false;
    }

    @Override
    public Integer changePassword(ChangePassword changePassword, Authentication authentication) {
        Optional<User> optionalUserdata = userRepo.findByEmail(authentication.getName());
        if (optionalUserdata.isPresent()) {
            User user = optionalUserdata.get();

            if (!passwordEncoder.matches(changePassword.getPassword(), user.getPassword())) {
                return 4;
            }

            if (passwordEncoder.matches(changePassword.getNewPassword(), user.getPassword())) {
                return 1;
            }

            if (changePassword.getNewPassword().equals(changePassword.getConfirmPassword())) {
                user.setPassword(passwordEncoder.encode(changePassword.getNewPassword()));
                userRepo.save(user);
                return 2;
            } else {
                return 3;
            }
        }
        return 3;
    }

    @Override
    public Integer addUpdateUser(BasicUserDetailsDTO basicUserDetailsDTO, Authentication authentication) {
        if (basicUserDetailsDTO.getIsNew()) {
            var user = User.builder()
                    .name(basicUserDetailsDTO.getName())
                    .email(basicUserDetailsDTO.getEmail())
                    .batch(basicUserDetailsDTO.getBatch())
                    .empId(basicUserDetailsDTO.getEmpId())
                    .mainBatch(basicUserDetailsDTO.getMainBatch())
                    .isEnabled(true)
                    .password(passwordEncoder.encode(String.valueOf(password)))
                    .role(Role.valueOf(Role.TRAINEE.name()))
                    .build();
            userRepo.save(user);
            return 3;
        } else {
            User aoptionalUserdata = userRepo.findByEmail(authentication.getName()).get();
            Optional<User> optionaluserdata = userRepo.findById(basicUserDetailsDTO.getId());
            if (optionaluserdata.isPresent()) {
                User userdata = optionaluserdata.get();
                if (aoptionalUserdata.getEmail().equals(userdata.getEmail())) {
                    return 1;
                } else {
                    userdata.setName(basicUserDetailsDTO.getName());
                    userdata.setMainBatch(basicUserDetailsDTO.getMainBatch());
                    userdata.setEmail(basicUserDetailsDTO.getEmail());
                    userdata.setBatch(basicUserDetailsDTO.getBatch());
                    userdata.setEmpId(basicUserDetailsDTO.getEmpId());
                    userdata.setRole(Role.valueOf(Role.TRAINEE.name()));
                    userRepo.save(userdata);
                    return 2;
                }
            }
            return 4;

        }

    }

    @Override
    public List<ExportDataDto> exportAssetData(String bid) {
        List<ExportDataDto> exportDataDtos = new ArrayList<>();

        List<User> userList = userRepo.findByMainBatchAndRoleNotOrderByUserId(bid,Role.ADMIN);
        for (User user : userList) {
            ExportDataDto exportDataDto = new ExportDataDto();
            exportDataDto.setId(user.getId());
            exportDataDto.setEmpId(user.getEmpId());
            exportDataDto.setName(user.getName());
            exportDataDto.setTempBatch(user.getTempBatch());
            exportDataDto.setBatch(user.getBatch());
            exportDataDto.setEmail(user.getEmail());
            List<AssetDetails> assetDetailsList = assetDetailsRepository.findByUser(user);
            if (assetDetailsList.size() > 0) {
                AssetDetails assetDetails = assetDetailsList.get(0);
                exportDataDto.setAssetId(assetDetails.getAssetId());
                exportDataDto.setManufacturerName(assetDetails.getMId().getManufacturerName());
                exportDataDto.setLaptopCollected(true);
                exportDataDto.setBitlockerStatus(assetDetails.getBitlockerStatus());
                exportDataDto.setVdiInstalled(assetDetails.getVdiInstalled());
                exportDataDto.setVdiWorking(assetDetails.getVdiWorking());
                exportDataDto.setCpaIssue(assetDetails.getCpaIssue());
                exportDataDto.setDuoWorking(assetDetails.getDuoWorking());
                exportDataDto.setZScalerWorking(assetDetails.getZScalerWorking());
                exportDataDto.setGwsIssue(assetDetails.getGwsIssue());
                exportDataDto.setAdminLogin(assetDetails.getAdminLogin());
            }

            exportDataDtos.add(exportDataDto);
        }
        return exportDataDtos;
    }

    @Override
    public boolean adminChangePassword(ChangePassword changePassword, Authentication authentication) {
        Optional<User> optionalUserdata = userRepo.findByEmail(authentication.getName());
        if (optionalUserdata.isPresent()) {
            User user = optionalUserdata.get();
            if (changePassword.getNewPassword().equals(changePassword.getConfirmPassword()) && passwordEncoder.matches(changePassword.getPassword(), user.getPassword())) {
                user.setPassword(passwordEncoder.encode(changePassword.getNewPassword()));
                userRepo.save(user);
                return true;
            } else {
                return false;
            }
        }
        return false;
    }


    @Override
    public void savePermanentUser(List<PermanentBatchDto> permanentBatchDtoList) {
        PermanentBatchDto permanentBatchDto = new PermanentBatchDto();

        List<User> batchList = new ArrayList<>();

        for (PermanentBatchDto permanentBatchDto1 : permanentBatchDtoList) {
            batchList.add(convertToEntity(permanentBatchDto1));
        }

        userRepo.saveAll(batchList);
    }

    public User convertToEntity(PermanentBatchDto permanentDto) {
        User user = userRepo.findByEmpId(permanentDto.getEmpId());
        user.setBatch(permanentDto.getBatch());
        user.setMainBatch(permanentDto.getMainBatch());
        return user;
    }

    ;
}
