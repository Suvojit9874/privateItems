package com.ignite.assettracker.dto;

import com.ignite.assettracker.model.Status;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

public class StatusDto {

    private Integer statusId;
    private String statusName;
    public StatusDto(Status status){
        this.statusId=status.getStatusId();
        this.statusName=status.getStatusName();
    }

}
