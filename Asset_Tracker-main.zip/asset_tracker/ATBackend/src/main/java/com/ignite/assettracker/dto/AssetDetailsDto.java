package com.ignite.assettracker.dto;

import com.ignite.assettracker.model.AssetDetails;
import com.ignite.assettracker.model.Location;
import com.ignite.assettracker.model.Manufacturer;
import com.ignite.assettracker.model.User;
import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class AssetDetailsDto {
    private Integer aaId;
    private String assetId;
    private String manufacturer;
    private Integer mid;
    private Boolean bitlockerStatus;
    private Boolean vdiInstalled;
    private Boolean vdiWorking;
    private Integer userId;
    private Integer locId;
    private String location;
    private User user;
    private String email;
    private Boolean zScalerWorking;
    private Boolean duoWorking;
    private Boolean cpaIssue;
    private Boolean gwsIssue ;
    private Boolean adminLogin;


    public AssetDetailsDto(AssetDetails assetDetails) {
        this.aaId=assetDetails.getAId();
        this.assetId = assetDetails.getAssetId();
        this.bitlockerStatus = assetDetails.getBitlockerStatus();
        this.manufacturer = assetDetails.getMId().getManufacturerName();
        this.mid =assetDetails.getMId().getMId();
        this.vdiInstalled = assetDetails.getVdiInstalled();
        this.vdiWorking = assetDetails.getVdiWorking();
        this.userId = assetDetails.getUser().getEmpId();
        this.locId = assetDetails.getLocation().getLocId();
        this.location = assetDetails.getLocation().getLocationName();
        this.email=assetDetails.getUser().getEmail();
        this.zScalerWorking=assetDetails.getZScalerWorking();
        this.duoWorking=assetDetails.getDuoWorking();
        this.cpaIssue=assetDetails.getCpaIssue();
        this.gwsIssue=assetDetails.getGwsIssue();
        this.adminLogin=assetDetails.getAdminLogin();
    }

    public AssetDetails createAssetDetailsByAssetDto(AssetDetailsDto assetDetailsDto, User user, Location location, Manufacturer manufacturer) {
        AssetDetails assetDetails = new AssetDetails();
        assetDetails.setAssetId(assetDetailsDto.getAssetId());
        assetDetails.setMId(manufacturer);
        assetDetails.setBitlockerStatus(assetDetailsDto.getBitlockerStatus());
        assetDetails.setVdiInstalled(assetDetailsDto.getVdiInstalled());
        assetDetails.setVdiWorking(assetDetailsDto.getVdiWorking());
        assetDetails.setUser(user);
        assetDetails.setLocation(location);
        assetDetails.setDuoWorking(assetDetailsDto.getDuoWorking());
        assetDetails.setZScalerWorking(assetDetailsDto.getZScalerWorking());
        assetDetails.setCpaIssue(assetDetailsDto.getCpaIssue());
        assetDetails.setGwsIssue(assetDetailsDto.getGwsIssue());
        assetDetails.setAdminLogin(assetDetailsDto.getAdminLogin());
        return assetDetails;
    }

}


