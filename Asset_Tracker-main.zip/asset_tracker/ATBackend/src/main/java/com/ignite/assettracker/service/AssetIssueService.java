package com.ignite.assettracker.service;

import com.ignite.assettracker.dto.AssetIssueDtoRequest;
import com.ignite.assettracker.dto.IssueDto;
import com.ignite.assettracker.dto.OptionDto;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

public interface AssetIssueService {
    List<AssetIssueDtoRequest> getAllAssets(String bId);

    AssetIssueDtoRequest addNewAssetIssue(AssetIssueDtoRequest assetIssueDto, Authentication authentication);

    AssetIssueDtoRequest updaetAssetIssue(Integer aaid, AssetIssueDtoRequest assetIssueDto, Authentication authentication);

    List<OptionDto> getAllCategory();

    List<OptionDto> getIssueByCategoryId(Integer catId);

    List<AssetIssueDtoRequest> getAllAssetIssuesOfUser(Authentication authentication);

    List<OptionDto> getAllStatus();

    IssueDto getIssueById(Integer issId);
}
