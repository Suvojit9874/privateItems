package com.ignite.assettracker.dto;

import com.ignite.assettracker.model.Role;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PermanentBatchDto {
    private Integer empId;
    private String batch;
    private String mainBatch;
}
