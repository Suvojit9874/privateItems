package com.ignite.assettracker.model;

import com.ignite.assettracker.dto.AssetIssueDtoRequest;
import jakarta.persistence.Entity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "asset_issue")
public class AssetIssue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "a_id", nullable = false)
    private AssetDetails assetDetails;

    @ManyToOne
    @JoinColumn(name = "issue_id", nullable = false)
    private Issues issues;

    @ManyToOne
    @JoinColumn(name = "status_id", nullable = false)
    private Status status;
    private String issueComment;
    private LocalDateTime reportedAt;
    private LocalDateTime resolvedAt;
    private String idmReply;
    private String ticketNumber;
    private String idmName;
    private Integer idmEmpId;
    private String userSolution;

}