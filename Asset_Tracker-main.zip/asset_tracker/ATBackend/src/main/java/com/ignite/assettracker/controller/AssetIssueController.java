package com.ignite.assettracker.controller;


import com.ignite.assettracker.dto.AssetIssueDtoRequest;
import com.ignite.assettracker.dto.IssueDto;
import com.ignite.assettracker.dto.OptionDto;
import com.ignite.assettracker.service.AssetIssueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/assetissue")
@CrossOrigin("*")
public class AssetIssueController {
    @Autowired
    private AssetIssueService assetIssueService;

    @GetMapping("/getAllAssetIssues/{bId}")
    public ResponseEntity<List<AssetIssueDtoRequest>> getAllAssets(@PathVariable String bId) {
        List<AssetIssueDtoRequest> assetIssueDtos = assetIssueService.getAllAssets(bId);
        return new ResponseEntity<>(assetIssueDtos, HttpStatus.OK);
    }
    @GetMapping("/getAllAssetIssuesOfUser")
    public ResponseEntity<List<AssetIssueDtoRequest>> getAllAssetIssuesOfUser(Authentication authentication) {
        List<AssetIssueDtoRequest> assetIssueDtos = assetIssueService.getAllAssetIssuesOfUser(authentication);
        return new ResponseEntity<>(assetIssueDtos, HttpStatus.OK);
    }

    @PostMapping("/addNewAssetIssue")
    public ResponseEntity<AssetIssueDtoRequest> addNewAssetIssue(@RequestBody AssetIssueDtoRequest assetIssueDto, Authentication authentication) {
        AssetIssueDtoRequest assetIssueDtos = assetIssueService.addNewAssetIssue(assetIssueDto, authentication);
        return new ResponseEntity<>(assetIssueDtos, HttpStatus.OK);
    }
    @PatchMapping("/updaetAssetIssue/{aaid}")
    public ResponseEntity<AssetIssueDtoRequest> updaetAssetIssue(@PathVariable Integer aaid,@RequestBody AssetIssueDtoRequest assetIssueDto, Authentication authentication) {
        AssetIssueDtoRequest assetIssueDtos = assetIssueService.updaetAssetIssue(aaid, assetIssueDto, authentication);
        return new ResponseEntity<>(assetIssueDtos, HttpStatus.OK);
    }
    @GetMapping("/getAllCategory")
    public ResponseEntity<List<OptionDto>> getAllCategory() {
        List<OptionDto> categoryList = assetIssueService.getAllCategory();
        return new ResponseEntity<>(categoryList, HttpStatus.OK);
    }
    @GetMapping("/getIssueByCategoryId/{catId}")
    public ResponseEntity<List<OptionDto>> getIssueByCategoryId(@PathVariable Integer catId) {
        List<OptionDto> issueList = assetIssueService.getIssueByCategoryId(catId);
        return new ResponseEntity<>(issueList, HttpStatus.OK);
    }

    @GetMapping("/getAllStatus")
    public ResponseEntity<List<OptionDto>> getAllStatus() {
        List<OptionDto> statusList = assetIssueService.getAllStatus();
        return new ResponseEntity<>(statusList, HttpStatus.OK);
    }

    @GetMapping("/getIssueById/{issId}")
    public ResponseEntity<IssueDto> getIssueById(@PathVariable Integer issId, Authentication authentication) {
        IssueDto assetIssueDtos = assetIssueService.getIssueById(issId);
        return new ResponseEntity<>(assetIssueDtos, HttpStatus.OK);
    }


}
