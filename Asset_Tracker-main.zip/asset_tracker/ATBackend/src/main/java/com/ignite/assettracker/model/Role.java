package com.ignite.assettracker.model;

public enum Role {
    TRAINEE, ADMIN
}
