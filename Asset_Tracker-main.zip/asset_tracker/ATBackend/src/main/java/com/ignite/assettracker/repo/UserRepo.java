package com.ignite.assettracker.repo;


import com.ignite.assettracker.dto.UserDashboardDto;
import com.ignite.assettracker.model.Role;
import com.ignite.assettracker.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface UserRepo extends JpaRepository<User, Integer> {

    Optional<User> findByEmail(String email);
    Optional<User> findByRoleAndUserId(Role role, Integer userId);
    List<User> findByRole(Role role);

    @Query(value = "SELECT DISTINCT main_batch FROM user_data ORDER BY main_batch", nativeQuery = true)
    List<String> getBatches();

    List<User> findByMainBatch(String number);

    List<User> findByMainBatchAndRoleNot(String bId, Role role);

    Long countByMainBatch(String bid);

    List<User> findByMainBatchAndRoleNotOrderByUserId(String bId, Role role);

    User findByEmpId(Integer empId);
//    UserDashboardDto findUserDashboardDataById(Integer id);
}
