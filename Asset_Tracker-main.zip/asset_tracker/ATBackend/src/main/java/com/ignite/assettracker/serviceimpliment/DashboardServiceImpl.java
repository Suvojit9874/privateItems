package com.ignite.assettracker.serviceimpliment;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.ignite.assettracker.model.AssetDetails;
import com.ignite.assettracker.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.ignite.assettracker.dto.UserDashboardDto;
import com.ignite.assettracker.dto.AdminDashboardDto;
import com.ignite.assettracker.model.Category;
import com.ignite.assettracker.model.Status;
import com.ignite.assettracker.repo.AssetDetailsRepository;
import com.ignite.assettracker.repo.AssetIssueRepository;
import com.ignite.assettracker.repo.CategoryRepository;
import com.ignite.assettracker.repo.IssuesRepository;
import com.ignite.assettracker.repo.StatusRepository;
import com.ignite.assettracker.repo.UserRepo;
import com.ignite.assettracker.service.DashboardService;

@Service
public class DashboardServiceImpl implements DashboardService{

    @Autowired
    private AssetIssueRepository assetIssuesRepo;
    @Autowired
    private UserRepo userRepo;
    @Autowired
    private AssetDetailsRepository assetDetailsRepo;
    @Autowired
    private StatusRepository statusRepo;
    @Autowired
    private IssuesRepository issuesRepo;
    @Autowired
    private CategoryRepository categoryRepo;


    @Override
    public AdminDashboardDto getAdminIssueCount(String bid) {
        AdminDashboardDto dashboardDto=new AdminDashboardDto();
        dashboardDto.setTotalIssue(assetIssuesRepo.getIssueCount(bid));

        dashboardDto.setPendingIssue(statusRepo.getStatusCount(1,bid));

        dashboardDto.setResolvedIssue(statusRepo.getStatusCount(2,bid));

        dashboardDto.setTotalUser(userRepo.countByMainBatch(bid));
        dashboardDto.setRegisteredAsset(assetDetailsRepo.getAssetDetailsCount(bid));

        List<Map<String, Object>> graphDtos=assetIssuesRepo.getGraphData(bid);
        dashboardDto.setGraphData(graphDtos);
        dashboardDto.setAllIssueGraph(assetIssuesRepo.allIssueGraph(bid));
        dashboardDto.setCategoryData(assetDetailsRepo.getCategoryIssueCount(bid));
        dashboardDto.setWeeklyCount(assetDetailsRepo.getWeeklyIssueCount(bid));

        return dashboardDto;
    }

    @Override
    public AdminDashboardDto getAdminIssueCount() {
        return null;
    }

    @Override
    public UserDashboardDto getUserDashboard(Authentication authentication){
        User user=userRepo.findByEmail(authentication.getName()).orElse(null);

        Integer pendingIssues=assetIssuesRepo.countByUserIdAndStatusName(user.getId(),1);

        Integer resolvedIssues=assetIssuesRepo.countByUserIdAndStatusName(user.getId(),2);

        UserDashboardDto userDashboardDto=new UserDashboardDto();
        assert user != null;
        userDashboardDto.setName(user.getName());
//        userDashboardDto.setRole(user.getRole());
        userDashboardDto.setEmail(user.getEmail());
        userDashboardDto.setEmpId(user.getEmpId());
        userDashboardDto.setBatch(user.getBatch());
        userDashboardDto.setMainBatch(user.getMainBatch());
        List<AssetDetails> assetDetails=assetDetailsRepo.findByUser(user);
        if(assetDetails.size()>=1){
            userDashboardDto.setAssetId(assetDetails.get(0).getAssetId());
            boolean vdiWorking=assetDetails.get(0).getVdiWorking();
            userDashboardDto.setVdiWorking(vdiWorking ? "Yes":"No");
        }else{
            userDashboardDto.setAssetId("No Asset Tagged");
            userDashboardDto.setVdiWorking("No");
        }
        userDashboardDto.setPendingIssues(pendingIssues);
        userDashboardDto.setResolvedIssues(resolvedIssues);

        return userDashboardDto;
    }

}
