package com.ignite.assettracker.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AdminDashboardDto {
    
    //For 1st div
    private Integer totalIssue;
    private Integer pendingIssue;
    private Integer resolvedIssue;
    private Long totalUser;
    private Integer registeredAsset;
    private List<Map<String, Object>> graphData;
    private List<Map<String, Object>> allIssueGraph;
    private List<Map<String, Object>> categoryData;
    private List<Map<String, Object>> weeklyCount;

}
