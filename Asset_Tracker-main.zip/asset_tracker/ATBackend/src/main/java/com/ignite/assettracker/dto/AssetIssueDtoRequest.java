package com.ignite.assettracker.dto;

import com.ignite.assettracker.model.AssetDetails;
import com.ignite.assettracker.model.AssetIssue;
import com.ignite.assettracker.model.Issues;
import com.ignite.assettracker.model.Status;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class AssetIssueDtoRequest {
    private Integer issueId;
    private Integer aaId;
    private Integer statusId;
    private String statusName;
    private String idmReply;
    private String ticketNumber;
    private String assetId;
    private String issueComment;
    private LocalDateTime reportedAt;
    private LocalDateTime resolvedAt;
    private Long resolvedAtUpdate;
    private String issueName;
    private String issueDescription;
    private Integer empId;
    private String email;
    private String category;
    private Integer categoryId;
    private Integer mappingId;
    private String solution;
    private Boolean solutionAvailable;
    private String idmName;
    private Integer idmEmpId;
    private String userSolution;



    public AssetIssueDtoRequest(AssetIssue assetIssue) {
        this.categoryId=assetIssue.getIssues().getCategory().getCategoryId();
        this.issueId = assetIssue.getIssues().getIssueId();
        this.issueName=assetIssue.getIssues().getIssueName();
        this.issueDescription=assetIssue.getIssues().getIssueDescription();
        this.idmReply = assetIssue.getIdmReply();
        this.ticketNumber = assetIssue.getTicketNumber();
        this.assetId = assetIssue.getAssetDetails().getAssetId();
        this.reportedAt = assetIssue.getReportedAt();
        this.resolvedAt = assetIssue.getResolvedAt();
        this.statusId=assetIssue.getStatus().getStatusId();
        this.aaId=assetIssue.getAssetDetails().getAId();
        this.empId=assetIssue.getAssetDetails().getUser().getEmpId();
        this.email=assetIssue.getAssetDetails().getUser().getEmail();
        this.category=assetIssue.getIssues().getCategory().getCategoryName();
        this.statusName=assetIssue.getStatus().getStatusName();
        this.issueComment=assetIssue.getIssueComment();
        this.mappingId=assetIssue.getId();
        this.solution=assetIssue.getIssues().getSolution();
        this.solutionAvailable=assetIssue.getIssues().getSolutionAvailable();
        this.idmName=assetIssue.getIdmName();
        this.idmEmpId=assetIssue.getIdmEmpId();
        this.userSolution=assetIssue.getUserSolution();
    }


    public static AssetIssue getAssetDetails(AssetDetails assetDetails, Status status,
                      Issues issues, String issueComment, AssetIssueDtoRequest assetIssueDto) {
        AssetIssue assetIssue = new AssetIssue();
        assetIssue.setAssetDetails(assetDetails);
        assetIssue.setStatus(status);
        assetIssue.setIssues(issues);
        assetIssue.setReportedAt(LocalDateTime.now());
        assetIssue.setIssueComment(issueComment);
        assetIssue.setTicketNumber(assetIssueDto.getTicketNumber());
        assetIssue.setIdmReply(assetIssueDto.getIdmReply());
        assetIssue.setIdmName(assetIssueDto.getIdmName());
        assetIssue.setIdmEmpId(assetIssueDto.getIdmEmpId());
        assetIssue.setUserSolution(assetIssueDto.getUserSolution());
        return assetIssue;
    }

}
