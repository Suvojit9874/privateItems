package com.ignite.assettracker.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserDashboardDto {

    private String name;
    private String role;
    private Integer pendingIssues;
    private Integer resolvedIssues;
    private  Integer empId;
    private String email;
    private String assetId;
    private String batch;
    private String  mainBatch;
    private String vdiWorking;
    // private Long registerIssue;
    
}
