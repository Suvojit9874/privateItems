package com.ignite.assettracker.service;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.ignite.assettracker.dto.AdminDashboardDto;
import com.ignite.assettracker.dto.UserDashboardDto;

@Service
public interface DashboardService{

    AdminDashboardDto getAdminIssueCount(String bid);
    AdminDashboardDto getAdminIssueCount();
    UserDashboardDto getUserDashboard(Authentication authentication);


}
