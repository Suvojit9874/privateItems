package com.ignite.assettracker.controller;

import com.ignite.assettracker.dto.ChangePassword;
import com.ignite.assettracker.dto.UserDto;
import com.ignite.assettracker.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
//import org.springframework.web.service.annotation.PutExchange;

import com.ignite.assettracker.dto.UserUpdateDto;
import com.ignite.assettracker.model.User;
import com.ignite.assettracker.service.UserService;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    public UserService userService;

    @Autowired
    public AdminService adminService;

    @PutMapping("/update/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Integer id, @RequestBody UserUpdateDto userUpdateDto){
        User updatedUser=userService.updateUser(id,userUpdateDto);

        if(updatedUser!=null){
            return ResponseEntity.ok(updatedUser);
        }
        else{
            return new ResponseEntity<>(HttpStatus.BAD_GATEWAY);
        }
    }

    @GetMapping("/getAllUsers/{bId}")
    public ResponseEntity<List<UserDto>> getAllUsers(@PathVariable String bId){
        List <UserDto> users=userService.getAllUsers(bId);
        return ResponseEntity.ok(users);
    }

    @PostMapping("/changePassword")
    public ResponseEntity<Object> changePassword(@RequestBody ChangePassword changePassword, Authentication authentication) {
        Integer changed = adminService.changePassword(changePassword, authentication);
        if (changed==2) {
            return new ResponseEntity<>("Password Changed Successfully", HttpStatus.OK);
        } else if(changed==1){
            return new ResponseEntity<>("Old Password And New Password Cannot Be Same", HttpStatus.BAD_REQUEST);
        }else if(changed==4){
            return new ResponseEntity<>("Please Enter Valid Old Password", HttpStatus.BAD_REQUEST);
        }else{
            return new ResponseEntity<>("Please Enter Valid Fields", HttpStatus.BAD_REQUEST);
        }

    }
    @GetMapping("/getPasswordChangeRequire")
    public ResponseEntity<Object> getPasswordChangeRequire(Authentication authentication) {
        Boolean changed = userService.getPasswordChangeRequire(authentication);
        return new ResponseEntity<>(changed, HttpStatus.OK);
    }

}
