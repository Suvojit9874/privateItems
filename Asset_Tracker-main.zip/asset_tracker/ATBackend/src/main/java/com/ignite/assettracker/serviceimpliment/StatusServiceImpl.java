package com.ignite.assettracker.serviceimpliment;

import com.ignite.assettracker.service.StatusService;
import org.springframework.stereotype.Service;

@Service
public class StatusServiceImpl implements StatusService {
}
