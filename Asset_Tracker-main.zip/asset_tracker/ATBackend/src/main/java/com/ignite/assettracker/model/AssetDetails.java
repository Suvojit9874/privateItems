package com.ignite.assettracker.model;

import jakarta.persistence.Entity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "asset_details")
public class AssetDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer aId;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false,unique = true)
    private String assetId;
    @ManyToOne
    @JoinColumn(name = "m_id",nullable = false)
    private Manufacturer mId;
    private Boolean bitlockerStatus=false;
    private Boolean vdiInstalled=false;
    private Boolean vdiWorking=false;
    private Boolean zScalerWorking =false;
    private Boolean duoWorking =false;
    private Boolean cpaIssue=false;
    private Boolean gwsIssue = false;
    private Boolean adminLogin=false;
    @ManyToOne
    @JoinColumn(name = "locId",nullable = false)
    private Location location;
}
