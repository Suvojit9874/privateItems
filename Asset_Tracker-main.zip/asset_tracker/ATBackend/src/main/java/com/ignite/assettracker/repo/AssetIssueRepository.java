package com.ignite.assettracker.repo;

import com.ignite.assettracker.model.AssetDetails;
import com.ignite.assettracker.model.AssetIssue;
import com.ignite.assettracker.model.Status;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.*;

public interface AssetIssueRepository extends JpaRepository<AssetIssue, Integer> {
    @Query(value = """
            SELECT  asset_issue.*
            FROM user_data
            RIGHT JOIN asset_details ON user_data.user_id = asset_details.user_id
            RIGHT JOIN asset_issue ON asset_details.a_id=asset_issue.a_id
            WHERE user_data.main_batch = ? ORDER BY asset_issue.id desc""", nativeQuery = true)
    List<AssetIssue> findAllAssetOfBatch(String bId);
    Long countByStatus(Optional<Status> pending);
    // Long getStatusName(Optional<Status> sts);

    @Query(value = """
    SELECT COUNT(*)
    FROM asset_issue ai
    JOIN asset_details ad ON ai.a_id = ad.a_id
    JOIN user_data ud ON ad.user_id = ud.user_id
    WHERE ud.main_batch = ?;""", nativeQuery = true)
    Integer getIssueCount( String bid);


    List<AssetIssue> findByAssetDetailsIn(List<AssetDetails> assetList);


    @Query(value = """
    SELECT COUNT(*)
    FROM asset_issue ai
    JOIN asset_details ad ON ai.a_id = ad.a_id
    JOIN user_data ud ON ad.user_id = ud.user_id
    WHERE ud.user_id=?  AND ai.status_id = ?;""", nativeQuery = true)
    Integer countByUserIdAndStatusName(Integer uId, Integer statusName);


    List<AssetIssue> findByAssetDetailsInOrderByReportedAtDesc(List<AssetDetails> assetList);

    @Query(value = """
    SELECT i.issue_name AS name, a.issue_count AS count
    FROM (
        SELECT issue_id, COUNT(*) AS issue_count
        FROM asset_issue ai
        JOIN asset_details ad ON ai.a_id = ad.a_id
        JOIN user_data ud ON ad.user_id = ud.user_id
        WHERE ud.main_batch = ?
        GROUP BY issue_id
    ) AS a
    JOIN issues AS i ON a.issue_id = i.issue_id
    ORDER BY a.issue_count DESC
    LIMIT 5;""", nativeQuery = true)
    List<Map<String, Object>> getGraphData(String bid);


    @Query(value = """
    SELECT i.issue_name as name, a.issue_count as count
     FROM (
         SELECT issue_id, COUNT(*) AS issue_count
         FROM asset_issue ai
         JOIN asset_details ad ON ai.a_id = ad.a_id
         JOIN user_data ud ON ad.user_id = ud.user_id
         WHERE ud.main_batch = ?
         GROUP BY issue_id
         ORDER BY issue_count DESC
     ) AS a
     JOIN issues AS i ON a.issue_id = i.issue_id;""", nativeQuery = true)
    List<Map<String, Object>> allIssueGraph(String bid);
}