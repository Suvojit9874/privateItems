package com.ignite.assettracker.exception;

public class ExceptedReturnKeys {
    public static final String MESSAGE = "message";
    public static final String ERROR = "error";
    public static final String DATA = "data";
}
