package com.ignite.assettracker;

import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

@SpringBootApplication
@AllArgsConstructor
public class AssetTracker {

	@Autowired
	private Environment environment;

	public static void main(String[] args) {
		SpringApplication.run(AssetTracker.class, args);

	}



}
