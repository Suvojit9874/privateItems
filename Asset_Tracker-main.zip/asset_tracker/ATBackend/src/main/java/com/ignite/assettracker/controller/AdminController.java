package com.ignite.assettracker.controller;

import com.ignite.assettracker.dto.*;
import com.ignite.assettracker.model.Role;
import com.ignite.assettracker.model.User;
import com.ignite.assettracker.repo.UserRepo;
import com.ignite.assettracker.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.MapReactiveUserDetailsService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/admin")
public class AdminController {
    public AdminService adminService;


    @Autowired
    public AdminController(AdminService adminService){
        this.adminService=adminService;
    }

    @Autowired
    private UserRepo userRepo;
    @PostMapping("/bulk")
    public ResponseEntity<String> addUsers(@RequestBody List<UserBulkDto> userDto) {

        adminService.saveAllUsers(userDto);
        return ResponseEntity.ok("Bulk data processed");

    }

    @GetMapping("/getBatches")
    public ResponseEntity<List<OptionDto>> getBatches() {
        List<OptionDto> optionDtos=adminService.getBatches();
        return new ResponseEntity<>(optionDtos,HttpStatus.OK);
    }
    @GetMapping("/resetPassword/{id}")
    public ResponseEntity<Object> resetPassword(@PathVariable Integer id, Authentication authentication) {

        Boolean status = adminService.resetPassword(id);
        return new ResponseEntity<>(status, HttpStatus.OK);
    }
    @PostMapping("/changePassword")
    public ResponseEntity<Object> changePassword(@RequestBody ChangePassword changePassword, Authentication authentication) {
        boolean changed = adminService.adminChangePassword(changePassword, authentication);
        if (changed) {
            return new ResponseEntity<>("Password Changed Successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Please Enter Valid Password", HttpStatus.BAD_REQUEST);
        }

    }
    @PostMapping("/addUpdateUser")
    public ResponseEntity<Object> addUpdateUser(@RequestBody BasicUserDetailsDTO basicUserDetailsDTO, Authentication authentication) {

        Integer statuscode = adminService.addUpdateUser(basicUserDetailsDTO, authentication);
        return new ResponseEntity<>(statuscode, HttpStatus.OK);

    }

    @PostMapping("/permanentBulkUpload")
    public ResponseEntity<String> permanentUserData(@RequestBody List<PermanentBatchDto> pDto){
        adminService.savePermanentUser(pDto);
        return ResponseEntity.ok("Got Permanent Batch Data");
    }


    //    @GetMapping("/users")
//    public ResponseEntity<Object> getAllUsers(List<AdminDto> usrDto) {
//        return ResponseEntity.ok(adminService.getAllUsers());
//    }



    @GetMapping("/exportAssetData/{bid}")
    public ResponseEntity<List<ExportDataDto>> exportAssetData(@PathVariable String bid, Authentication authentication) {
        List<ExportDataDto> exportAssetData = adminService.exportAssetData(bid);
        return new ResponseEntity<>(exportAssetData, HttpStatus.OK);
    }
}

