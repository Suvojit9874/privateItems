package com.ignite.assettracker.service;

import org.springframework.stereotype.Service;

@Service

public interface StatusService {
}
