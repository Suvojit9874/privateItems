package com.ignite.assettracker.repo;

import com.ignite.assettracker.model.Location;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LocationRepo extends JpaRepository<Location,Integer> {
}
