package com.ignite.assettracker.controller;

import com.ignite.assettracker.dto.AssetDetailsDto;
import com.ignite.assettracker.dto.OptionDto;
import com.ignite.assettracker.model.Role;
import com.ignite.assettracker.model.User;
import com.ignite.assettracker.service.AssetDetailsService;
import com.ignite.assettracker.service.UserService;

import jakarta.annotation.security.RolesAllowed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;

import java.util.ArrayList;
import java.util.List;

@CrossOrigin("*")
@RestController
@RequestMapping("/asset")
public class AssetController {
    private AssetDetailsService assetDetailsService;

    @Autowired
    public AssetController(AssetDetailsService assetDetailsService) {
        this.assetDetailsService = assetDetailsService;
    }

    @GetMapping("/getAllAssets/{bId}")
    public ResponseEntity<List<AssetDetailsDto>> getAllAssets(@PathVariable String bId, Authentication authentication) {
        List<AssetDetailsDto> assetDetailsDtoList = assetDetailsService.getAllAssets(authentication,bId);
        return new ResponseEntity<>(assetDetailsDtoList, HttpStatus.OK);
     }

    @PostMapping("/addNewAsset")
    public ResponseEntity<AssetDetailsDto> addNewAsset(@RequestBody AssetDetailsDto assetDetailsDto, Authentication authentication) {
        AssetDetailsDto assetDetailsDtoRes = assetDetailsService.addNewAsset(assetDetailsDto, authentication);
        return new ResponseEntity<>(assetDetailsDtoRes, HttpStatus.OK);
    }
    @GetMapping("/getAssetsOfUser")
    public ResponseEntity<List<AssetDetailsDto>> getAssetsByUser(Authentication authentication) {
        List<AssetDetailsDto> assetDetails = assetDetailsService.getAssetsByUser(authentication);
        return ResponseEntity.ok(assetDetails);

    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteAssetById(@PathVariable Integer id){
       Integer status= assetDetailsService.deleteAssetById(id);
       if(status==0){
        return new ResponseEntity<>("Asset Not Found",HttpStatus.NOT_FOUND);
       }
       return new ResponseEntity<>("Asset Deleted",HttpStatus.OK);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<AssetDetailsDto> updateAssetById(@PathVariable Integer id, @RequestBody AssetDetailsDto assetDetailsDto){
        AssetDetailsDto updatedAsset=assetDetailsService.updateAssetById(id,assetDetailsDto);
        return ResponseEntity.ok(updatedAsset);
    }
 @PutMapping("/updateOldAsset")
    public ResponseEntity<AssetDetailsDto> updateOldAsset(@RequestBody AssetDetailsDto assetDetailsDto,Authentication authentication){
        AssetDetailsDto updatedAsset=assetDetailsService.updateOldAsset(assetDetailsDto,authentication);
        return ResponseEntity.ok(updatedAsset);
    }


    @GetMapping("/getAssetUserOption")
    public ResponseEntity<List<OptionDto>> getAssetUserOption(Authentication authentication) {
        List<OptionDto> assetDetails = assetDetailsService.getAssetUserOption(authentication);
        return ResponseEntity.ok(assetDetails);

    }
    @GetMapping("/getManufacturerOptions")
    public ResponseEntity<List<OptionDto>> getManufacturerOptions() {
        List<OptionDto> manufacturerOptions = assetDetailsService.getManufacturerOptions();
        return ResponseEntity.ok(manufacturerOptions);

    }
    @GetMapping("/getLocationOptions")
    public ResponseEntity<List<OptionDto>> getLocationOptions() {
        List<OptionDto> locationOptions = assetDetailsService.getLocationOptions();
        return ResponseEntity.ok(locationOptions);

    }
}
