package com.ignite.assettracker.dto;

import com.fasterxml.jackson.core.type.WritableTypeId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserDto {
    private Integer id;
    private String name;
    private String email;
    private String batch;
    private Integer empId;
    private String mainBatch;
    private Boolean asset;
    private String tempBatch;
    
}
