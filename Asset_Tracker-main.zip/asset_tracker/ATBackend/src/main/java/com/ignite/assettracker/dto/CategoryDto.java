package com.ignite.assettracker.dto;

import com.ignite.assettracker.model.Category;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class CategoryDto {
    private Integer categoryId;
    private String categoryName;

    public CategoryDto(Category category){
        this.categoryId=category.getCategoryId();
        this.categoryName=category.getCategoryName();
    }
}
