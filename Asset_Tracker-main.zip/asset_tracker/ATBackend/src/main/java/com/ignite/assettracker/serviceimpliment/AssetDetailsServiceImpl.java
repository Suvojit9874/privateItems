package com.ignite.assettracker.serviceimpliment;

import com.ignite.assettracker.dto.AssetDetailsDto;
import com.ignite.assettracker.dto.OptionDto;
import com.ignite.assettracker.model.AssetDetails;
import com.ignite.assettracker.model.Location;
import com.ignite.assettracker.model.Manufacturer;
import com.ignite.assettracker.model.User;
import com.ignite.assettracker.repo.AssetDetailsRepository;
import com.ignite.assettracker.repo.LocationRepo;
import com.ignite.assettracker.repo.ManufacturerRepo;
import com.ignite.assettracker.repo.UserRepo;
import com.ignite.assettracker.service.AssetDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AssetDetailsServiceImpl implements AssetDetailsService {

    private AssetDetailsRepository assetDetailsRepository;
    private UserRepo userRepo;
    private LocationRepo locationRepo;
    private ManufacturerRepo manufacturerRepo;

    @Autowired
    public AssetDetailsServiceImpl(AssetDetailsRepository assetDetailsRepository, UserRepo userRepo, LocationRepo locationRepo, ManufacturerRepo manufacturerRepo) {
        this.assetDetailsRepository = assetDetailsRepository;
        this.userRepo = userRepo;
        this.locationRepo = locationRepo;
        this.manufacturerRepo = manufacturerRepo;
    }


    @Override
    public List<AssetDetailsDto> getAllAssets(Authentication authentication, String bId) {
        System.out.println("this how to access request sent by email " + authentication.getName());
        Optional<User> user = userRepo.findByEmail(authentication.getName());
        if (user.isPresent()) {
            System.out.println("this how to access request sent by empid " + user.get().getEmpId());
        }

        List<AssetDetails> assetDetailList = assetDetailsRepository.findAllByBatchId(bId);
        List<AssetDetailsDto> assetDetailsDtoList = new ArrayList<>();
        for (AssetDetails assetDetails : assetDetailList) {
            assetDetailsDtoList.add(new AssetDetailsDto(assetDetails));
        }
        return assetDetailsDtoList;
    }

    @Override
    public AssetDetailsDto addNewAsset(AssetDetailsDto assetDetailsDto, Authentication authentication) {
        Optional<User> user = userRepo.findByEmail(authentication.getName());
        if (user.isEmpty()) {
            return null;
        }
        Location location = locationRepo.findById(assetDetailsDto.getLocId()).get();
        AssetDetailsDto assetDetailsDto1 = new AssetDetailsDto();
        Manufacturer manufacturer = manufacturerRepo.findById(assetDetailsDto.getMid()).get();
        AssetDetails assetDetails = assetDetailsDto1.createAssetDetailsByAssetDto(assetDetailsDto, user.get(), location, manufacturer);
        AssetDetails assetDetailsOut = assetDetailsRepository.save(assetDetails);
        return new AssetDetailsDto(assetDetailsOut);
    }


    @Override
    public List<AssetDetailsDto> getAssetsByUser(Authentication authentication) {
        String email = authentication.getName();
        Optional<User> user = userRepo.findByEmail(email);
        if (user.isEmpty()) {
            return null;
        }
        List<AssetDetails> assetDetailsList = assetDetailsRepository.findByUser(user.get());
        List<AssetDetailsDto> assetDetailsDtoList = new ArrayList<>();

        for (AssetDetails assetDetails : assetDetailsList) {
            AssetDetailsDto dto = new AssetDetailsDto(assetDetails);
            assetDetailsDtoList.add(dto);
        }

        return assetDetailsDtoList;
    }

    @Override
    public Integer deleteAssetById(Integer id) {
        Optional<AssetDetails> assetDetails = assetDetailsRepository.findById(id);
        if (assetDetails.isEmpty()) {
            return 0;
        } else {
            assetDetailsRepository.deleteById(id);
            return 1;
        }

    }

    @Override
    public AssetDetailsDto updateAssetById(Integer id, AssetDetailsDto assetDetailsDto) {
        AssetDetails assetDetails = assetDetailsRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Asset with ID " + id + " not found"));
        Manufacturer manufacturer = manufacturerRepo.findById(assetDetailsDto.getMid()).orElseThrow(() -> new RuntimeException("Manufacturer with ID " + assetDetailsDto.getMid() + " not found"));
        Location location = locationRepo.findById(assetDetailsDto.getLocId()).orElseThrow(() -> new RuntimeException("Location with ID " + assetDetailsDto.getLocId() + " not found"));

        setAssetDetailsProperties(assetDetails, assetDetailsDto, manufacturer, location);

        AssetDetails updatedAsset = assetDetailsRepository.save(assetDetails);
        return new AssetDetailsDto(updatedAsset);
    }

    @Override
    public AssetDetailsDto updateOldAsset(AssetDetailsDto assetDetailsDto, Authentication authentication) {
        Optional<User> user=userRepo.findByEmail(authentication.getName());
        if(user.isEmpty()){
            return null;
        }

        List<AssetDetails> assetDetailList = assetDetailsRepository.findByUser(user.get());
        if (assetDetailList.isEmpty()) {
            return null;
        }
        AssetDetails assetDetails = assetDetailList.get(0);
        Manufacturer manufacturer = manufacturerRepo.findById(assetDetailsDto.getMid()).orElseThrow(() -> new RuntimeException("Manufacturer with ID " + assetDetailsDto.getMid() + " not found"));
        Location location = locationRepo.findById(assetDetailsDto.getLocId()).orElseThrow(() -> new RuntimeException("Location with ID " + assetDetailsDto.getLocId() + " not found"));

        setAssetDetailsProperties(assetDetails, assetDetailsDto, manufacturer, location);

        AssetDetails updatedAsset = assetDetailsRepository.save(assetDetails);
        return new AssetDetailsDto(updatedAsset);
    }


    private void setAssetDetailsProperties(AssetDetails assetDetails, AssetDetailsDto assetDetailsDto, Manufacturer manufacturer, Location location) {
        assetDetails.setMId(manufacturer);
        assetDetails.setAssetId(assetDetailsDto.getAssetId());
        assetDetails.setBitlockerStatus(assetDetailsDto.getBitlockerStatus());
        assetDetails.setVdiInstalled(assetDetailsDto.getVdiInstalled());
        assetDetails.setVdiWorking(assetDetailsDto.getVdiWorking());
        assetDetails.setZScalerWorking(assetDetailsDto.getZScalerWorking());
        assetDetails.setDuoWorking(assetDetailsDto.getDuoWorking());
        assetDetails.setCpaIssue(assetDetailsDto.getCpaIssue());
        assetDetails.setGwsIssue(assetDetailsDto.getGwsIssue());
        assetDetails.setAdminLogin(assetDetailsDto.getAdminLogin());
        assetDetails.setLocation(location);
    }


    @Override
    public List<OptionDto> getAssetUserOption(Authentication authentication) {
        Optional<User> user = userRepo.findByEmail(authentication.getName());
        List<OptionDto> output = new ArrayList<>();
        if (user.isEmpty()) {
            System.out.println(authentication.getName());
            return output;
        } else {
            System.out.println("full");
            List<AssetDetails> assetDetails = assetDetailsRepository.findByUser(user.get());
            for (AssetDetails assetDetails1 : assetDetails) {
                output.add(new OptionDto(assetDetails1.getAId(), assetDetails1.getAssetId()));
            }
            return output;
        }
    }

    @Override
    public List<OptionDto> getManufacturerOptions() {
        List<Manufacturer> manufacturers = manufacturerRepo.findAll();
        List<OptionDto> optionDtos = new ArrayList<>();
        for (Manufacturer manufacturer : manufacturers) {
            optionDtos.add(new OptionDto(manufacturer.getMId(), manufacturer.getManufacturerName()));
        }
        return optionDtos;
    }

    @Override
    public List<OptionDto> getLocationOptions() {
        List<Location> locationList = locationRepo.findAll();
        List<OptionDto> optionDtoList = new ArrayList<>();
        for (Location location : locationList) {
            optionDtoList.add(new OptionDto(location.getLocId(), location.getLocationName()));
        }
        return optionDtoList;
    }


}