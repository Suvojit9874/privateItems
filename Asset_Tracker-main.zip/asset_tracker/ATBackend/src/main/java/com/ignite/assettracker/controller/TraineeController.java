package com.ignite.assettracker.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// import com.ignite.assettracker.model.User;
import org.springframework.ui.Model;

import com.ignite.assettracker.model.User;
import com.ignite.assettracker.service.UserService;

@RestController
@RequestMapping("/trainee")
public class TraineeController {

    @Autowired
    private UserService userService;
    
    @GetMapping("/trainee")
    public ResponseEntity<Object> getAllUser() {
        return new ResponseEntity<>("trainee", HttpStatus.OK);
    }

    // @GetMapping("/update-password")
    // public String updatePasswordForm() {
    //     return "update-password";
    // }


}
