package com.ignite.assettracker.dto;

import com.ignite.assettracker.model.Role;

import com.ignite.assettracker.model.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserBulkDto {


    private Integer userId;
    private String email;
    private String name;
    private Integer empId;
    private Boolean isEnabled;
    private String password;
    private Role role;
    private String tempBatch;
    private String mainBatch;




}
