package com.ignite.assettracker.service;

import com.ignite.assettracker.dto.*;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface AdminService {
    public void saveAllUsers(List<UserBulkDto> users);


    List<OptionDto> getBatches();

    Boolean resetPassword(Integer id);

    Integer changePassword(ChangePassword changePassword, Authentication authentication);

    Integer addUpdateUser(BasicUserDetailsDTO basicUserDetailsDTO, Authentication authentication);

    public void savePermanentUser(List<PermanentBatchDto> user);
    List<ExportDataDto> exportAssetData(String bid);

    boolean adminChangePassword(ChangePassword changePassword, Authentication authentication);
}
