package com.ignite.assettracker.repo;

import com.ignite.assettracker.model.Status;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface StatusRepository extends JpaRepository<Status, Integer> {

    // Optional<Status> findByStatusName();

    @Query(value = """
    SELECT COUNT(*)
    FROM asset_issue ai
    JOIN asset_details ad ON ai.a_id = ad.a_id
    JOIN user_data ud ON ad.user_id = ud.user_id
    WHERE ai.status_id = ? AND ud.main_batch = ?;""", nativeQuery = true)
    Integer getStatusCount(int i, String bid);
}