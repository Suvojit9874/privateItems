package com.ignite.assettracker.auth;

import com.ignite.assettracker.model.User;
import com.ignite.assettracker.repo.UserRepo;
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.ignite.assettracker.service.UserService;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthenController {

    private final AuthService service;
    private UserRepo userRepo;
    //private final UserService userService;

    // @PostMapping("/register")
    // public ResponseEntity<AuthenticationResponse> register(
    //         @RequestBody AuthRegisterRequest request
    // ) {
    //     return ResponseEntity.ok(service.register(request));
    // }

    @Autowired
    public AuthenController(AuthService service,UserRepo userRepo){
        this.service=service;
        this.userRepo=userRepo;

    }
    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody AuthRegisterRequest authRegisterRequest){
        try{
            service.registerUser(authRegisterRequest);
                return new ResponseEntity<>("User registered successfully", HttpStatus.CREATED);
        }
        catch(Exception e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }



    @PostMapping("/authenticate")
    public ResponseEntity<AuthenticationResponse> authenticate(
            @RequestBody AuthLoginRequest request
    ) {
        return ResponseEntity.ok(service.authenticate(request));
    }

    @GetMapping("/getRole")
    public String getRole(Authentication authentication){
        User user=userRepo.findByEmail(authentication.getName()).get();
        return user.getRole().name();
    }

}
