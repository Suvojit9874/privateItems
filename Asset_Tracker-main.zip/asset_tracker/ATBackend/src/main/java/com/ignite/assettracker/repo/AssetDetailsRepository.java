package com.ignite.assettracker.repo;

import com.ignite.assettracker.model.AssetDetails;
import com.ignite.assettracker.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Map;


public interface AssetDetailsRepository extends JpaRepository<AssetDetails, Integer> {


    List<AssetDetails> findByUser(User user);

    @Query(value = """
            SELECT  asset_details.*
            FROM user_data
            RIGHT JOIN asset_details ON user_data.user_id = asset_details.user_id
            WHERE user_data.main_batch = ?""", nativeQuery = true)
    List<AssetDetails> findAllByBatchId(String bId);

    @Query(value = """
    SELECT COUNT(*)
    FROM asset_details ad
    JOIN user_data ud ON ad.user_id = ud.user_id
    WHERE ud.main_batch = ?;""", nativeQuery = true)
    Integer getAssetDetailsCount(String bid);



    @Query(value = """
    SELECT c.category_name AS categoryName, COUNT(ai.issue_id) AS issueCount
    FROM asset_issue ai
    JOIN issues i ON ai.issue_id = i.issue_id
    JOIN category c ON i.category_id = c.category_id
    JOIN asset_details ad ON ai.a_id = ad.a_id
    JOIN user_data ud ON ad.user_id = ud.user_id
    WHERE ud.main_batch = ?
    GROUP BY c.category_name;""", nativeQuery = true)
    List<Map<String, Object>> getCategoryIssueCount(String bid);

    List<AssetDetails> findByAssetId(String assetId);


    @Query(value = """
    SELECT TO_CHAR(DATE_TRUNC('week', ai.reported_at) + INTERVAL '6 days', 'YYYY-MM-DD') AS reported,
           COUNT(CASE WHEN ai.resolved_at IS NOT NULL THEN 1 END) AS resolvedCount,
           COUNT(ai.issue_id) AS issueCount
    FROM asset_issue ai
    JOIN asset_details ad ON ai.a_id = ad.a_id
    JOIN user_data ud ON ad.user_id = ud.user_id
    WHERE ud.main_batch = ?
    GROUP BY TO_CHAR(DATE_TRUNC('week', ai.reported_at) + INTERVAL '6 days', 'YYYY-MM-DD')
    ORDER BY reported;""", nativeQuery = true)
    List<Map<String, Object>> getWeeklyIssueCount(String bid);

}
