package com.ignite.assettracker.serviceimpliment;

import com.ignite.assettracker.service.CategoryService;
import org.springframework.stereotype.Service;

@Service
public class CategoryServiceImpl implements CategoryService {
}
