//package com.ignite.assettracker.service.serviceimpliment;
package com.ignite.assettracker.serviceimpliment;

import com.ignite.assettracker.auth.AuthRegisterRequest;
import com.ignite.assettracker.dto.UserDashboardDto;
import com.ignite.assettracker.dto.UserDto;
import com.ignite.assettracker.dto.UserUpdateDto;
import com.ignite.assettracker.model.AssetDetails;
import com.ignite.assettracker.model.Role;
import com.ignite.assettracker.model.User;
import com.ignite.assettracker.repo.AssetDetailsRepository;
import com.ignite.assettracker.repo.UserRepo;
import com.ignite.assettracker.service.UserService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepo userRepository;
    @Value("${defaultPassword}")
    String defaultpassword;
    private final PasswordEncoder passwordEncoder;

    private AssetDetailsRepository assetDetailsRepository;

    @Autowired
    public UserServiceImpl(UserRepo userRepository, PasswordEncoder passwordEncoder,AssetDetailsRepository assetDetailsRepository) {

        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.assetDetailsRepository=assetDetailsRepository;
    }




    @Override
    public void registerUser(AuthRegisterRequest authRegisterRequest) {
        User user = new User();
        user.setEmail(authRegisterRequest.getEmail());
        user.setPassword(passwordEncoder.encode(authRegisterRequest.getPassword()));
        user.setRole(authRegisterRequest.getRole());
        userRepository.save(user);

    }

    @Override
    public User updateUser(Integer id, UserUpdateDto userUpdateDto) {
        Optional<User> optionalUser = userRepository.findById(id);
        if (optionalUser.isPresent()) {
            User existingUser = optionalUser.get();
            existingUser.setName(userUpdateDto.getName());
            existingUser.setEmail(userUpdateDto.getEmail());
            existingUser.setBatch(userUpdateDto.getBatch());
            existingUser.setMainBatch(userUpdateDto.getMainBatch());
            return userRepository.save(existingUser);
        } else {
            return null;
        }
    }


    @Override
    public List<UserDto> getAllUsers(String bId) {
        List<User> userList= userRepository.findByMainBatchAndRoleNotOrderByUserId(bId, Role.ADMIN);
        List<UserDto> userDtos=new ArrayList<>();
        for(User user:userList){
            UserDto userDto=new UserDto();
            userDto.setId(user.getId());
            userDto.setName(user.getName());
            userDto.setEmpId(user.getEmpId());
            userDto.setMainBatch(user.getMainBatch());
            userDto.setEmail(user.getEmail());
            userDto.setBatch(user.getBatch());
            userDto.setTempBatch(user.getTempBatch());
            List<AssetDetails> assetDetails=assetDetailsRepository.findByUser(user);
            if(assetDetails.isEmpty()){
                userDto.setAsset(false);
            }else{
                userDto.setAsset(true);
            }
            userDtos.add(userDto);
        }

          return userDtos;

    }

    @Override
    public Boolean getPasswordChangeRequire(Authentication authentication) {
        Optional<User> optionalUserdata = userRepository.findByEmail(authentication.getName());
        if (optionalUserdata.isPresent()) {
            String password = optionalUserdata.get().getPassword();
            return passwordEncoder.matches(defaultpassword,password);
        } else {
            return false;
        }
    }

}
