package com.ignite.assettracker.service;

import com.ignite.assettracker.dto.UserDashboardDto;
import com.ignite.assettracker.dto.UserDto;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.ignite.assettracker.auth.AuthRegisterRequest;
import com.ignite.assettracker.dto.UserUpdateDto;
import com.ignite.assettracker.model.User;

import java.util.List;

@Service
public interface UserService {

    void registerUser (AuthRegisterRequest authRegisterRequest);
    User updateUser(Integer id, UserUpdateDto userUpdateDto);
    List<UserDto> getAllUsers(String bId);


    Boolean getPasswordChangeRequire(Authentication authentication);
}
