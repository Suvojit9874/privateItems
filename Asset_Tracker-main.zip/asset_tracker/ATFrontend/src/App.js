import './App.css';
import React, { useContext, useEffect, useState } from 'react';
import Login from './components/Login';
import ViewAssets from './components/ViewAssets';
import UploadPage from "./components/admin/uploadPage/UploadPage"
import ExportData from './components/ExportData'
// import MuiDataGrid from './components/MuiDataGrid';

import { ToastContainer } from 'react-toastify';
import "react-toastify/dist/ReactToastify.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from './components/Home'; // Updated import to Home component
import Users from './components/Users';
import Batches from './components/Batches';
import ManageUser from './components/ManageUser';
import ViewIssues from './components/ViewIssues';
import MyIssues from './components/MyIssues';
import UserProfilePage from './components/UserProfilePage';
import Dashboard from './components/dashboard/Dashboard';
import UDashboard from './components/udashboard/UDashboard';
import AddIssueModal from './components/Modals/AddIssueModal';
import Landing from './Landing'
import AddAssetModal from './components/Modals/AddAssetModal';
import MyAsset from './components/MyAsset';
import Temp from './components/Temp';
import { BatchContext } from './components/context/BatchContext';
import PemanentBatch from './components/admin/uploadPage/PermanentBatch';
import Support from './components/Support';

function App() {
  const { batchName, setBatchName,role,setrole } = useContext(BatchContext);
  const [myRole, setmyRole] = useState("")
  useEffect(() => {
    setmyRole(role)
  }, [role])
  


  return (
    <div className="App">
      <Router>
        <Routes>
            <Route path="/" element={<Landing/>} />
            <Route path="contactus" element={<Support/>} />
          <Route path="/login" element={<Login />} />
          <Route path="/Home/" element={<Home />}>
            <Route path="" element={myRole=="ADMIN"?<Dashboard/>:<UDashboard/>} />
            <Route path="dataupload" element={<UploadPage />} />
            <Route path="exportdata" element={<ExportData />} />
            <Route path="batchdataup" element={<PemanentBatch/>} />
            <Route path="users" element={<ManageUser />} />
            <Route path="assets" element={<ViewAssets />} />
            <Route path="issues" element={<ViewIssues />} />
            <Route path="myissue" element={<ViewIssues />} />
            <Route path="profile" element={<UserProfilePage />} />
            <Route path="myasset" element={<MyAsset/>} />
            <Route path="temp" element={< Temp/>} />
            <Route path="udashboard" element={<UDashboard/>} />

          </Route>
        </Routes>
      </Router>
    </div>
  );
}

export default App;