import React from 'react';
import { useNavigate } from 'react-router-dom';
// import { IoMdArrowRoundForward } from "react-icons/io";
import './Landing.css';
import Navbar from './Navbar';


const LandingPage = () => {
    const navigate = useNavigate() ;
    const Login = () => {
        navigate("/login")
      }
    //   const contactUs=()=>{
    //     navigate('/contactus')
    // }
    
    return (
        <>
        <Navbar />
        {/* <button  onClick={contactUs} style={{position:"absolute",right: "10px"}}>Contact us</button> */}

        <div className="landing-page">
            <div className="contents">
                <p className="animated-text">Welcome to Asset Tracker!</p>
                <span className='tag'>Your one-stop solution for<br></br>&nbsp;&nbsp;
                    <span className='high'>efficient and effective</span></span><br></br>
                <span className='about'>asset management.<br></br>
                    <span className='abou'> </span><span className='auth'></span>  <span className='auth'></span> <br></br>
                     </span><br></br>
                <button  onClick={Login}>Get Started</button>
                
            </div>
        </div>
        </>
    );
};

export default LandingPage;