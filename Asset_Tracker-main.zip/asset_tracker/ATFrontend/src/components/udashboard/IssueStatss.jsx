import React from 'react';
import { Box, Paper, Typography } from '@mui/material';
import './IssueStats.css';

const IssueStats = ({ pending, resolved }) => {

  return (
    <Box className="issue-stats-box">
      <Paper className="issue-stats-paper" elevation={3} sx={{borderRadius:'10px'}}>
      <Box sx={{ height: '100%' , width:'100%', borderRadius:'10px'}}>
        <Typography variant="h6" sx={{fontSize:'1rem'}}>Pending Issues</Typography>
        <Typography variant="h4" sx={{fontSize:'1.5rem'}}>{pending}</Typography>
        </Box>
      </Paper>
      <Paper className="issue-stats-paper" elevation={3} sx={{borderRadius:'10px'}}>
        <Box sx={{ height: '100%' , width:'100%', borderRadius:'10px'}}>
        <Typography variant="h6" sx={{fontSize:'1rem'}}>Resolved Issues</Typography>
        <Typography variant="h4" sx={{fontSize:'1.5rem'}}>{resolved}</Typography>
        </Box>
      </Paper>
    </Box>
  );
};

export default IssueStats;