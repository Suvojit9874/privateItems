import React from 'react';
import { Box, Grid, Paper, Typography } from '@mui/material';
import './AssetInfo.css';

const AssetInfo = ({ assetId, vdiWorking, batch, subBatch }) => {

  return (

    <Grid container spacing={2} className="asset-info-grid" sx={{borderRadius:'10px'}}>
      <Grid item xs={12} sm={6}>
        <Paper className="asset-info-paper" elevation={3} sx={{borderRadius:'10px'}}>
        <Box sx={{ height: '100%' , width:'100%',borderRadius:'10px' }}>
          <Typography variant="h6" sx={{fontSize:'1rem'}}>Asset ID</Typography>
          <Typography variant="body1" sx={{fontSize:'1rem'}}>{assetId}</Typography>
          </Box>
        </Paper>
      </Grid>

      <Grid item xs={12} sm={6}>
        <Paper className="asset-info-paper" elevation={3} sx={{borderRadius:'10px'}}>
        <Box sx={{ height: '100%' , width:'100%',borderRadius:'10px' }}>
          <Typography variant="h6" sx={{fontSize:'1rem'}}>VDI Working Status</Typography>
          <Typography variant="body1" sx={{fontSize:'1rem'}}>{vdiWorking ? 'Yes' : 'No'}</Typography>
          </Box>
        </Paper>
      </Grid>
      
      <Grid item xs={12} sm={6}>
        <Paper className="asset-info-paper" elevation={3} sx={{borderRadius:'10px'}}>
        <Box sx={{ height: '100%' , width:'100%',borderRadius:'10px' }}>
          <Typography variant="h6" sx={{fontSize:'1rem'}}>Batch</Typography>
          <Typography variant="body1" sx={{fontSize:'1rem'}}>{subBatch}</Typography>
          </Box>
        </Paper>
      </Grid>

      <Grid item xs={12} sm={6}>
        <Paper className="asset-info-paper" elevation={3} sx={{borderRadius:'10px'}}>
        <Box sx={{ height: '100%' , width:'100%',borderRadius:'10px' }}>
          <Typography variant="h6" sx={{fontSize:'1rem'}}>Sub Batch</Typography>
          <Typography variant="body1" sx={{fontSize:'1rem'}}>{batch}</Typography>
          </Box>
        </Paper>
      </Grid>

      
    </Grid>
  );
};

export default AssetInfo;