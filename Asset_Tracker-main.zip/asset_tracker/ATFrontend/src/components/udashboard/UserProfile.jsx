import React, { useEffect, useState } from 'react';
import { Avatar, Paper, Typography, Grid, Button, Box } from '@mui/material';
import ChangePassword from './ChangePassword';

import './UserProfile.css';
// import { toast } from 'react-toastify';
import { useCookies } from 'react-cookie';
import axios from 'axios';
import Support from '../Support';

const UserProfile = ({ user }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [bool, setBool] = useState(false)
  const [contactModal, setContactModal] = useState(false)

  const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL;

  const [cookies] = useCookies(["jwttoken"]);


  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };


  const changeRequire=()=>{

    axios({
      url: `${REACT_APP_BASE_URL}/user/getPasswordChangeRequire`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    }).then((response)=>{
      if(response.data===true){
        setBool(response.data)
        setIsModalOpen(response.data)
        console.log(response.data,"Hello");
      }
    }).catch((error)=>{
      console.log("Error checking password change requirement", error);
    })
  }
  useEffect(() => {
    changeRequire()

  }, [REACT_APP_BASE_URL,cookies.jwttoken]) 

  return (

    <Paper className="user-profile-paper" elevation={3} sx={{borderRadius:'10px' , position:'relative', padding:'10px'}}>

      <Box className="user-profile-header" sx={{position:'relative'}}>

        <Avatar className="user-profile-avatar">{user.initials}</Avatar>

        <button onClick={openModal} className="change-password-button">Change Password</button>
        <button onClick={()=>setContactModal(true)} className="change-password-button" style={{position: "absolute",right:"20px",top:"60px"}}>Contact us</button>

      </Box>
      <Typography variant="h6">{user.name}</Typography>

      <Typography variant="subtitle1">{user.role}</Typography>

      <Grid container spacing={0.5} justifyContent="center" className="user-profile-grid">

        <Grid item>

          <Paper className="user-profile-issue-paper" elevation={3} sx={{borderRadius:'10px'}}>
          <Box sx={{ height: '100%' , width:'100%' ,borderRadius:'10px'}}>
            <Typography variant="h6" sx={{fontSize:'1rem'}}>Pending Issues</Typography>
            <Typography variant="h4" sx={{fontSize:'1.5rem'}}>{user.pendingIssues}</Typography>
            </Box>

          </Paper>

        </Grid>

        <Grid item>
          <Paper className="user-profile-issue-paper" elevation={3} sx={{borderRadius:'10px'}}>
          <Box sx={{ height: '100%' , width:'100%' ,borderRadius:'10px'}}>
            <Typography variant="h6" sx={{fontSize:'1rem'}}>Resolved Issues</Typography>
            <Typography variant="h4" sx={{fontSize:'1.5rem'}}>{user.resolvedIssues}</Typography>
            </Box>

          </Paper>

        </Grid>

      </Grid>
      
      {isModalOpen && <ChangePassword setBool={setBool} bool={bool} isModalOpen={isModalOpen} closeModal={closeModal} />}
      {contactModal && <Support  contactModal={contactModal} setContactModal={setContactModal} />}
      

    </Paper>

  );

};



export default UserProfile;