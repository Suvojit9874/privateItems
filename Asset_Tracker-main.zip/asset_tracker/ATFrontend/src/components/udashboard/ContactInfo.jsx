import React from 'react';
import { Box, Grid, Paper, Typography } from '@mui/material';
import './ContactInfo.css';

const ContactInfo = ({ mailId, empId }) => {

  return (

    <Grid container spacing={2} className="contact-info-grid" sx={{borderRadius:'10px'}}>

      <Grid item xs={12} sm={6}>
        <Paper className="contact-info-paper" elevation={3} sx={{borderRadius:'10px'}}>
        <Box sx={{ height: '100%' , width:'100%',borderRadius:'10px' }}>
          <Typography variant="h6" sx={{fontSize:'1rem'}}>Mail ID</Typography>
          <Typography variant="body1" sx={{fontSize:'1rem'}}>{mailId}</Typography>
          </Box>
        </Paper>
      </Grid>

      <Grid item xs={12} sm={6}>
        <Paper className="contact-info-paper" elevation={3} sx={{borderRadius:'10px'}}>
        <Box sx={{ height: '100%' , width:'100%',borderRadius:'10px' }}>
          <Typography variant="h6" sx={{fontSize:'1rem'}}>EMP ID</Typography>
          <Typography variant="body1" sx={{fontSize:'1rem'}}>{empId}</Typography>
          </Box>
        </Paper>
      </Grid>
    </Grid>
  );
};

export default ContactInfo;