import React, { useContext, useEffect, useState } from "react";
import zxcvbn from "zxcvbn";
import "./ChangePassword.css";
import "../Modals/modal.css";
import { useCookies } from "react-cookie";
import { toast } from "react-toastify";
import OutsideClickHandler from "react-outside-click-handler";
import axios from "axios";
import { BatchContext } from "../context/BatchContext";
import { errortoast, successtoast } from "../ExtraExports/Exports";
import { Navigate, useNavigate } from "react-router-dom";
import { FaEye, FaEyeSlash } from "react-icons/fa";

function ChangePassword({ bool, setBool, isModalOpen, closeModal }) {
  const { batchName, setBatchName, role, setRole } = useContext(BatchContext);

  const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL;
  const [cookies] = useCookies(["jwttoken"]);
  const [require, setRequire] = useState("");
  const [showOldPassword, setShowOldPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const navigate = useNavigate();

  const [passwordDetails, setPasswordDetails] = useState({
    password: "",
    newPassword: "",
    confirmPassword: "",
  });

  const [error, setError] = useState("");
  const [passwordStrength, setPasswordStrength] = useState(null);
  const handleOldPasswordChange = (e) => {
    setPasswordDetails({ ...passwordDetails, password: e.target.value });
  };

  const handleNewPasswordChange = (e) => {
    setPasswordDetails({ ...passwordDetails, newPassword: e.target.value });
    const strength = zxcvbn(e.target.value);
    setPasswordStrength(strength);

    if (strength.score < 2) {
      setError("Password is too week. Please use a strong password.");
    } else {
      setError("");
    }
  };

  const handleConfirmPasswordChange = (e) => {
    setPasswordDetails({ ...passwordDetails, confirmPassword: e.target.value });
  };
  const changePassword = () => {
    const { password, newPassword, confirmPassword } = passwordDetails;
    if (!password || !newPassword || !confirmPassword) {
      setError("Please Fill All The Fields");
      return;
    } else if (newPassword != confirmPassword) {
      setError("New Password And Confirm Password Should Be Same");
      return;
    }

    axios({
      url: `${REACT_APP_BASE_URL}/user/changePassword`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "POST",
      data: { password, newPassword, confirmPassword },
    })
      .then((response) => {
        console.log("Password change response:", response);

        setPasswordDetails({
          password: "",
          newPassword: "",
          confirmPassword: "",
        });

        successtoast(response?.data);
        setBool(false);
        setError("");
        closeModal();
      })

      .catch((error) => {
        console.log("Error changing password:", error);

        if (error.response) {
          console.error(error.response.data);

          setError(error.response.data.message || "Failed to change password");

          errortoast(error.response.data);
        } else {
          setError("Something went wrong");
          errortoast("Something went wrong");
        }
      });
  };

  const handleSubmit = () => {
    setError("");

    if (passwordDetails.newPassword !== passwordDetails.confirmPassword) {
      setError("New password and confirm password do not match");

      return;
    }
    if (passwordStrength < 2) {
      // errortoast("Password is too waek. Please use a strong password.");
    }

    changePassword();
  };

  const toggleOldPasswordVisibility = () => {
    setShowOldPassword(!showOldPassword);
  };
  const toggleNewPasswordVisibility = () => {
    setShowNewPassword(!showNewPassword);
  };
  const toggleConfirmPasswordVisibility = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };

  const handleSubmitOut = () => {
    navigate("/");
  };

  return (
    <div className="createprojectmodalouter">
      <OutsideClickHandler onOutsideClick={() => !bool && closeModal(false)}>
        <div className="card scale-up-center-animation">
          <div className="card-header">
            <div className="text-header">Change Password</div>
          </div>
          <div className="card-body">
            {error && <div className="error-message">{error}</div>}
            <div className="form-group">
              <label htmlFor="oldPassword">Old Password:</label>
              <input
                // type="password"
                id="oldPassword"
                value={passwordDetails.password}
                onChange={handleOldPasswordChange}
                maxLength={20}
                type={showOldPassword ? "text" : "password"}
                required
              />
              <span className="eyebutton" onClick={toggleOldPasswordVisibility}>
                {showOldPassword ? (
                  <FaEye size={"1.2rem"} />
                ) : (
                  <FaEyeSlash size={"1.2rem"} />
                )}
              </span>
            </div>
            <div className="form-group">
              <label htmlFor="newPassword">New Password:</label>
              <input
                type={showNewPassword ? "text" : "password"}
                id="newPassword"
                value={passwordDetails.newPassword}
                onChange={handleNewPasswordChange}
                required
              />
              <span className="eyebutton" onClick={toggleNewPasswordVisibility}>
                {showNewPassword ? (
                  <FaEye size={"1.2rem"} />
                ) : (
                  <FaEyeSlash size={"1.2rem"} />
                )}
              </span>
              {passwordStrength && (
                <div className="password-strength">
                  <progress value={passwordStrength.score} max="4" />

                  <p>{passwordStrength.feedback.suggestions.join(" ")}</p>
                </div>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="confirmPassword">Confirm Password:</label>
              <input
                type={showConfirmPassword ? "text" : "password"}
                id="confirmPassword"
                value={passwordDetails.confirmPassword}
                onChange={handleConfirmPasswordChange}
                required
              />
              <span className="eyebutton" onClick={toggleConfirmPasswordVisibility}>
                {showConfirmPassword ? (
                  <FaEye size={"1.2rem"} />
                ) : (
                  <FaEyeSlash size={"1.2rem"} />
                )}
              </span>
            </div>
            <button type="button" onClick={handleSubmit}>
              Change Password
            </button>
            <button type="button" onClick={handleSubmitOut}>
              Log Out
            </button>
          </div>
        </div>
      </OutsideClickHandler>
    </div>
  );
}

export default ChangePassword;
