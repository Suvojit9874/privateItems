import React, { useEffect, useState } from 'react';
import { Container, Grid } from '@mui/material';
import UserProfile from './UserProfile';
import AssetInfo from './AssetInfo';
import ContactInfo from './ContactInfo';
import './UDashboard.css';
import axios from "axios";
import {useCookies } from 'react-cookie';
const UDashboard = () => {

  const [user, setUser] = useState([])
  const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL;
  const [cookies] = useCookies(["jwttoken"]);

  const userDashboard=()=>{
    axios({
      url: `${REACT_APP_BASE_URL}/userDashboard/getCounts`,
      method:"GET",
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
    })
    .then((response)=>{
      setUser(response.data)
      console.log(response.data);
    })
    .catch((error)=>{
      console.log(error);
    })
  }

  useEffect(() => {
    userDashboard();
  }, [])
  


  return (
    <Container maxWidth="lg" className="dashboard-container">
      <UserProfile user={user} />
      <Grid container spacing={2} sx={{ marginTop: 0 }}>
        <Grid item xs={12}>
          <ContactInfo mailId={user.email} empId={user.empId} />
        </Grid>
        <Grid item xs={12}>
          <AssetInfo
            assetId={user.assetId}
            vdiWorking={user.vdiWorking}
            batch={user.batch}
            subBatch={user.mainBatch}
          />
        </Grid>
      </Grid>
    </Container>
  );
};

export default UDashboard;