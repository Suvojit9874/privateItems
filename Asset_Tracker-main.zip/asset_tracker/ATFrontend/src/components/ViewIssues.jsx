import React, { useContext, useEffect, useState } from "react";
import ReactPaginate from "react-paginate";
import Select from "react-dropdown-select";
import makeAnimated from "react-select/animated";
import "./ViewIssues.css";
import axios from "axios";

import { useCookies } from "react-cookie";
import { BatchContext } from "./context/BatchContext";
import IssueDiv from "./IssueDiv";
import { HashLoader } from "react-spinners";
import { IoMdAdd } from "react-icons/io";
import AddIssueModal from "./Modals/AddIssueModal";
import EditIssueModal from "./Modals/EditIssueModal";
import ViewIssueModel from "./Modals/ViewIssueModel";
import SolutionIssueModal from "./Modals/SolutionIssueModal";
import { FaPlus } from "react-icons/fa";
const itemsPerPage = 4;

function ViewIssues() {
  const [editIssueData, seteditIssueData] = useState({});
  const { batchName, role } = useContext(BatchContext);
  const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL;
  const [cookies, setCookie, removeCookie] = useCookies(["jwttoken"]);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchOption, setSearchOption] = useState([
    { value: "issueName", label: "Issue Name" },
  ]);
  const [currentPage, setCurrentPage] = useState(0);
  const [categoryList, setcategoryList] = useState([]);
  const [statusList, setstatusList] = useState([]);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [selectedStatuses, setSelectedStatuses] = useState([]);
  const [issueData, setIssueData] = useState([]);
  const [loading, setloading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [openEditModal, setopenEditModal] = useState(false);
  const [viewModal, setviewModal] = useState(false)
const [showSolutionModal, setshowSolutionModal] = useState(false)

  const searchOptions = [
    { value: "issueName", label: "Issue Name" },
    { value: "ticketNumber", label: "Ticket Number" },
    { value: "assetId", label: "Asset ID" },
    { value: "issueDescription", label: "Issue Description" },
    { value: "issueComment", label: "Issue Comments" },
    { value: "empId", label: "Employee ID" },
    { value: "email", label: "Email" },
  ];

  const getAllIssues = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/assetissue/getAllAssetIssues/${batchName.label}`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setloading(false);
        setIssueData(response.data);
        console.log(response.data);
      })
      .catch((error) => {
        setloading(false);
        console.log(error);
      });
  };

  const getAllAssetIssuesOfUser = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/assetissue/getAllAssetIssuesOfUser`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setloading(false);
        setIssueData(response.data);
        console.log(response.data);
      })
      .catch((error) => {
        setloading(false);
        console.log(error);
      });
  };

  const getAllCategory = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/assetissue/getAllCategory`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setcategoryList(response.data);
      })
      .catch((error) => {});
  };

  const fetchStatuses = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/assetissue/getAllStatus`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setstatusList(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  useEffect(() => {
    setloading(true);
    if (role === "ADMIN") getAllIssues();
    else getAllAssetIssuesOfUser();
  }, [batchName, role]);

  useEffect(() => {
    getAllCategory();
    fetchStatuses();
  }, []);

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleSearchOptionChange = (selectedOptions) => {
    setSearchOption(selectedOptions || []);
  };

  const handlePageClick = (event) => {
    setCurrentPage(event.selected);
  };

  const handleCategoryChange = (selectedOptions) => {
    console.log(selectedOptions);
    setSelectedCategories(selectedOptions || []);
  };

  const handleStatusChange = (selectedOptions) => {
    setSelectedStatuses(selectedOptions || []);
  };

  const filterIssues = (issues) => {
    return issues.filter(
      (issue) =>
        issue[searchOption[0]?.value]
          ?.toString()
          .toLowerCase()
          .includes(searchTerm.toLowerCase()) &&
        (selectedCategories.length === 0 ||
          selectedCategories.some((cat) => cat.label === issue.category)) &&
        (selectedStatuses.length === 0 ||
          selectedStatuses.some((st) => st.label === issue.statusName))
    );
  };

  const offset = currentPage * itemsPerPage;
  const currentPageData = issueData.slice(offset, offset + itemsPerPage);
  const filteredIssues = filterIssues(currentPageData);

  return (
    <div className="issues-details">
      <div className="issues-header">
        {role === "TRAINEE" && (
          <button className="add-assetbtn" onClick={() => setIsModalOpen(true)}>
            <FaPlus />&nbsp;
            Add Issue
          </button>
        )}
        <Select
          options={searchOptions}
          value={searchOption}
          onChange={handleSearchOptionChange}
          components={makeAnimated()}
          className="category-select"
          multi={false}
          style={{
            minWidth: "170px",
            padding: "10px",
          }}
        />
        <input
          type="text"
          placeholder="Search..."
          value={searchTerm}
          onChange={handleSearch}
          className="search-bar"
        />
        <Select
          closeMenuOnSelect={false}
          components={makeAnimated()}
          multi={true}
          options={categoryList}
          placeholder="Select Categories"
          onChange={handleCategoryChange}
          className="category-select"
          style={{
            minWidth: "170px",
            padding: "10px",
          }}
        />
        <Select
          closeMenuOnSelect={false}
          components={makeAnimated()}
          // multi={true}
          options={statusList}
          clearable={true}
          placeholder="Select Statuses"
          onChange={handleStatusChange}
          className="status-select"
          style={{
            minWidth: "170px",
            padding: "10px",
          }}
        />
      </div>
      
      <div className="issues-list">
        {filteredIssues.map((issue) => (
          <IssueDiv issue={issue} key={issue.id} seteditIssueData={seteditIssueData}
            closeModal={setopenEditModal} 
            setviewModal={setviewModal} 
            setshowSolutionModal={setshowSolutionModal}
            />
            
        ))}
      </div>
      
      <div className="paginate">
        <ReactPaginate
          previousLabel={"previous"}
          nextLabel={"next"}
          breakLabel={"..."}
          pageCount={Math.ceil(issueData.length / itemsPerPage)}
          marginPagesDisplayed={2}
          pageRangeDisplayed={3}
          onPageChange={handlePageClick}
          containerClassName={"pagination"}
          subContainerClassName={"pages pagination"}
          activeClassName={"active"}
        />
        {isModalOpen && (
          <AddIssueModal
            closeModal={setIsModalOpen}
            modalfun={role === "ADMIN" ? getAllIssues : getAllAssetIssuesOfUser}
          />
        )}
        {openEditModal && (
          <EditIssueModal
            closeModal={setopenEditModal}
            editIssueData={editIssueData}
            modalfun={role == "ADMIN" ? getAllIssues : getAllAssetIssuesOfUser}
          />
        )}
        {viewModal && (
          <ViewIssueModel
            editIssueData={editIssueData}
            closeModal={setviewModal}
            modalfun={role == "ADMIN" ? getAllIssues : getAllAssetIssuesOfUser}
          />
        )}
        {showSolutionModal && (
          <SolutionIssueModal
            editIssueData={editIssueData}
            closeModal={setshowSolutionModal}
            modalfun={role == "ADMIN" ? getAllIssues : getAllAssetIssuesOfUser}
          />
        )}
      

        
{loading && <HashLoader color={"#2f215e"} size={"60"} />}
      </div>
    </div>
  );
}

export default ViewIssues;
