import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import ViewIssues from '../ViewIssues';

import { BrowserRouter } from 'react-router-dom';
import { BatchContext } from '../context/BatchContext';
const issuetest=() =>{}

describe('Input value', () => {
    test('validate searchbar functionalities', () => {
      render(
        <BatchContext.Provider value={{issuetest}}>
        <BrowserRouter>
      <ViewIssues/>
      </BrowserRouter>
      </BatchContext.Provider>
      );
        const searchInput = screen.getByPlaceholderText('Search...')
        fireEvent.change(searchInput, { target: { value: 'test' } });
        expect(searchInput.value).toBe('test');
    })
    
    test('validate on searchBar', () => {
      render(
        <BatchContext.Provider value={{issuetest}}>
        <BrowserRouter>
      <ViewIssues/>
      </BrowserRouter>
      </BatchContext.Provider>
      );
        const searchInput = screen.getByPlaceholderText('Search...');
       expect(searchInput).toBeInTheDocument();
    })

    test('validate button', () => {
      render(
        <BatchContext.Provider value={{issuetest}}>
        <BrowserRouter>
      <ViewIssues/>
      </BrowserRouter>
      </BatchContext.Provider>
      );
        const btn = screen.getByRole('button',{name:'<IoMdAdd />Add Issue'});
       expect(btn).toBeInTheDocument();
    })

    // test('validate button functionalities', () => {
    //   render(
    //     <BatchContext.Provider value={{issuetest}}>
    //     <BrowserRouter>
    //     <ViewIssues/>
    //     </BrowserRouter>
    //     </BatchContext.Provider>
    //   );
    //   const Button = screen.getByRole('button', { name: 'Add Issue' });
    //   fireEvent.click(Button);
    // })
  });

    
  


