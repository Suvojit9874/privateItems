import React, { useContext } from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import AddIssueModal from '../Modals/AddIssueModal';

import { BrowserRouter } from 'react-router-dom';
import { BatchContext } from '../context/BatchContext';
const issuemodal =()=>{}
describe('Add issue modal', () =>{

    
    test('renders the modal', ()=> {
        render(
            <BatchContext.Provider value={{issuemodal}}>
            <BrowserRouter>
            <AddIssueModal />
            </BrowserRouter>
            </BatchContext.Provider>
        );
        const txt=screen.getByText('Add Issue');
        expect(txt).tobeIntheDocument();
    })
})