// // UploadPage.test.js
// import React from 'react';
// import { render, screen, fireEvent } from '@testing-library/react';

// import UploadPage from './UploadPage';
// import { BrowserRouter as Router } from 'react-router-dom';

// jest.mock('axios');
// jest.mock('papaparse', () => ({
//   parse: (file, options) => {
//     options.complete({
//       data: [
//         { email: 'test@tcs.com', id: '1', empId: '123456', name: 'Test User', password: 'password1', batch: 'A1', mainBatch: 'A' },
//         // Add more mock data if needed
//       ]
//     });
//   }
// }));

// describe('UploadPage Component', () => {
//   test('renders without crashing', () => {
//     render(<Router><UploadPage /></Router>);
//     expect(screen.getByText('Browse Files to upload')).toBeInTheDocument();
//   });

//   test('handles file upload and CSV parsing', async () => {
//     render(<Router><UploadPage /></Router>);

//     const file = new Blob([`email,id,empId,name,password,batch,mainBatch\ntest@tcs.com,1,123456,Test User,password1,A1,A`], { type: 'text/csv' });
//     const input = screen.getByPlaceholderText('Browse Files to upload');
    
//     Object.defineProperty(input, 'files', {
//       value: [file],
//     });

//     fireEvent.change(input);

//     await waitFor(() => {
//       expect(screen.getByText('File uploaded')).toBeInTheDocument();
//       expect(screen.getByText('test@tcs.com')).toBeInTheDocument();
//     });
//   });

//   test('validates form data correctly', async () => {
//     render(<Router><UploadPage /></Router>);

//     const file = new Blob([`empId,name,password,batch,mainBatch\ntest@tcs.com,1,123456,Test User,password1,A1,A`], { type: 'text/csv' });
//     const input = screen.getByPlaceholderText('Browse Files to upload');

//     Object.defineProperty(input, 'files', {
//       value: [file],
//     });

//     fireEvent.change(input);

//     await waitFor(() => {
//       expect(screen.queryByText('Invalid email')).not.toBeInTheDocument();
//       expect(screen.queryByText('Password is not Strong')).not.toBeInTheDocument();
//     });
//   });

//   test('submits form data', async () => {
//     axios.post.mockResolvedValue({ data: 'Success' });

//     render(<Router><UploadPage /></Router>);

//     const file = new Blob([`email,id,empId,name,password,batch,mainBatch\ntest@tcs.com,1,123456,Test User,password1,A1,A`], { type: 'text/csv' });
//     const input = screen.getByPlaceholderText('Browse Files to upload');

//     Object.defineProperty(input, 'files', {
//       value: [file],
//     });

//     fireEvent.change(input);

//     await waitFor(() => {
//       expect(screen.getByText('Submit')).not.toBeDisabled();
//     });

//     fireEvent.click(screen.getByText('Submit'));

//     await waitFor(() => {
//       expect(axios.post).toHaveBeenCalledWith(`${process.env.REACT_APP_BASE_URL}/admin/bulk`, [
//         { email: 'test@tcs.com', id: '1', empId: '123456', name: 'Test User', password: 'password1', batch: 'A1', mainBatch: 'A' },
//       ], { headers: { "Authorization": `Bearer undefined` } });
//     });
//   });
// });
