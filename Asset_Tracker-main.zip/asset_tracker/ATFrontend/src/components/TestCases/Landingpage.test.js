import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import Landing from "../../../src/Landing";

import { BrowserRouter } from 'react-router-dom';




describe('Landing Component', () => {



  test('validates getStarted button', () => {
    render(<BrowserRouter>
      <Landing />
      </BrowserRouter>);
    const getStartedButton = screen.getByRole('button', { name: 'Get Started' });
    expect(getStartedButton).toBeInTheDocument();
  });


test('renders span element with text "Asset Tracker"', () => {
    const { getByText } =render(
    <BrowserRouter>
    <Landing/>
    </BrowserRouter>
    );
    const spanElement = getByText('Asset Tracker!');
    expect(spanElement).toBeInTheDocument();
    expect(spanElement).toHaveClass('txt');
  });


    test('validates the getStarted button',()=>{
      render(
        <BrowserRouter>
        <Landing/>
        </BrowserRouter>
      );
      const getStarted = screen.getByRole('button', { name: 'Get Started' })
      fireEvent.click(getStarted)
    });

    test('validates the getStarted functionality',()=>{
      render(
        <BrowserRouter>
        <Landing/>
        </BrowserRouter>
      );
      const getStartedButton = screen.getByRole('button', { name: 'Get Started' })
      expect(getStartedButton).toBeInTheDocument();
    });

  });