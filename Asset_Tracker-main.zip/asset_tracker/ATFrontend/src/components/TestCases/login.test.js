import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import Login from '../Login';

import { BrowserRouter } from 'react-router-dom';



describe('Login Component', () => {
  test('renders the login form', () => {
    render(
      <BrowserRouter>
    <Login />
    </BrowserRouter>
    );
    const signInText = screen.getByText('Asset Tracker',{ selector: 'h1' });
    expect(signInText).toBeInTheDocument();
  });

  test('validates input fields', () => {
    render(<BrowserRouter>
      <Login />
      </BrowserRouter>);
    const emailInput = screen.getByPlaceholderText('Email ID');
    const passwordInput = screen.getByPlaceholderText('Password');
    expect(emailInput).toBeInTheDocument();
    expect(passwordInput).toBeInTheDocument();
  });

  test('validates input value', () => {
    render(<BrowserRouter>
      <Login />
      </BrowserRouter>);
    const emailInput = screen.getByPlaceholderText('Email ID');
    const passwordInput = screen.getByPlaceholderText('Password');
    fireEvent.change(emailInput,{target:{value:'admin@tcs.com'}});
    fireEvent.change(passwordInput,{target:{value:'jayesh'}});
    expect(emailInput.value).toBe('admin@tcs.com');
    expect(passwordInput.value).toBe('jayesh');
  });


  test('validates Login in button', () => {
    render(<BrowserRouter>
      <Login />
      </BrowserRouter>);
    const LoginButton = screen.getByRole('button', { name: 'Login' });
    expect(LoginButton).toBeInTheDocument();
  });

  test('validates Login in functinality', () => {
    render(<BrowserRouter>
      <Login />
      </BrowserRouter>);
    const LoginButton = screen.getByRole('button', { name: 'Login' });
    fireEvent.click(LoginButton);
  });

  });