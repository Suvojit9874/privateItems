// import React from 'react';
// import { render, screen, fireEvent } from '@testing-library/react';
// import '@testing-library/jest-dom/extend-expect';
// import AssetDetails from './AssetDetails';

// describe('AssetDetails Component', () => {

//   test('renders AssetDetails component', () => {
//     render(<AssetDetails />);
    
//     // Check if the main header is present
//     const signInText = screen.getByText('Asset Details',{ selector: 'h2' });
//     expect(signInText).toBeInTheDocument();

//     // Check if the Create Asset button is present
//     expect(screen.getByText(/Create Asset/i)).toBeInTheDocument();

//     // Check if the Submit button is present
//     expect(screen.getByText(/Submit/i)).toBeInTheDocument();
//   });

//   test('Create Asset button click triggers assetHandler', () => {
//     // Mock console.log
//     console.log = jest.fn();

//     render(<AssetDetails />);
//     const createButton = screen.getByText(/Create Asset/i);
//     fireEvent.click(createButton);

//     expect(console.log).toHaveBeenCalledWith('asset created');
//   });

//   test('Submit button click triggers submitHandler', () => {
//     // Mock console.log
//     console.log = jest.fn();

//     render(<AssetDetails />);
//     const submitButton = screen.getByText(/Submit/i);
//     fireEvent.click(submitButton);

//     expect(console.log).toHaveBeenCalledWith('Button clicked');
//   });

// });
