import React, { useEffect, useState } from 'react'
import { FaLaptop } from 'react-icons/fa'
import { FaLocationDot } from 'react-icons/fa6'
import { MdEmail, MdExpandLess, MdExpandMore } from 'react-icons/md'
import { FaCheckCircle } from "react-icons/fa";
import { FaTimesCircle } from "react-icons/fa";

import { PiDevicesFill } from 'react-icons/pi'
import { MdEdit } from "react-icons/md";

function AssetDiv({ asset, modalfun,closeModal,seteditAssetData,setviewModal }) {

    const [isOpen, setisOpen] = useState(false)
    return (
        <div key={asset.a_id} className="asset-item">
            <div className="accordianhead">
                <div className="data-asset" id="assetDivLogo"><FaLaptop className="div-icons" size={"1.7rem"} /> {asset.assetId}</div>
                <div className="data-asset" id="data1"><b><PiDevicesFill className="div-icons" size={"1.4rem"} /></b><b>{asset.manufacturer}</b></div>
                <div className="data-asset" id="data3"><MdEmail className="div-icons" />{asset.email}</div>
                <div className="data-asset" id="data4">{asset.location}<FaLocationDot className="div-icons" /></div>
                {/* <div className="data-asset" id="data5"> </div> */}
                <span className='editbutton' onClick={()=>{seteditAssetData(asset);closeModal(true)}} >
                    <MdEdit size={"1.4rem"} />
                </span>
                <div onClick={() => setisOpen(!isOpen)}>
                    {isOpen ?
                        <MdExpandMore size={"1.5rem"} />
                        :
                        <MdExpandLess size={"1.5rem"} />
                    }
                </div>
                <button onClick={()=>{seteditAssetData(asset);setviewModal(true)}}>view</button>
            </div>
            <div className={`${isOpen ? "accshow" : "acchide"}`}>
                <div className='accord-components'>
                    <div className="data-asset" id="data6">VDI Installed: {asset.vdiInstalled ? <FaCheckCircle/> : <FaTimesCircle/>}</div>
                    <div className="data-asset" id="data7">VDI(CPA) Working: {asset.cpaIssue ? <FaCheckCircle/> : <FaTimesCircle/>}</div>
                    <div className="data-asset" id="data7">Bitlocker: {asset.bitlockerStatus ? <FaCheckCircle/> : <FaTimesCircle/>}</div>
                </div>
            </div>
           
        </div>
    )
}

export default AssetDiv
