import React from 'react'

function UserProfilePage() {
  return (
    <div>UserProfilePage</div>
  )
}

export default UserProfilePage