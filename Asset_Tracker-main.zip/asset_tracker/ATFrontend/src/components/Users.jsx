import React from 'react'

function Users() {
  return (
    <div className="view-user">
      

            <h1>View Existing users</h1>

    </div>
  )
}

export default Users