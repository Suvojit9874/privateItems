import React from 'react'
import './Support.css'
import OutsideClickHandler from 'react-outside-click-handler'


function Support({contactModal ,setContactModal}) {
  return (
    <div className="createprojectmodalouter">
      <OutsideClickHandler
        onOutsideClick={() => {
          setContactModal(false);
        }}
      >
        <div className="card scale-up-center-anmiation" style={{width:'450px'}}>
          <div className="card-header">
            <div className="text-header">Contact Us</div>
          </div>
        </div>
        <div className="card-body" style={{backgroundColor:"white"}}> Email : nitish.bhatt1@tcs.com</div>
      </OutsideClickHandler>
    </div>
  )
}



export default Support

