import React, { useEffect, useState } from "react";
import { IoMdAdd } from "react-icons/io";
import AddAssetModal from "./Modals/AddAssetModal";
import axios from "axios";
import { useCookies } from "react-cookie";
import { errortoast, successtoast } from "./ExtraExports/Exports";
import AssetDiv from "./AssetDiv";
import EditAssetModal from "./Modals/EditAssetModal";
import ViewAssetModal from "./Modals/ViewAssetModal";
import UpdateOldAsset from "./Modals/UpdateOldAsset";
import { FaPlus } from "react-icons/fa";
import { Link, useNavigate } from "react-router-dom";

function MyAsset() {
  const [openEditModal, setopenEditModal] = useState(false);
  const [showModal, setshowModal] = useState(false);
  const [shownewTaggedAsset, setshownewTaggedAsset] = useState(false);
  const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL;
  const [cookies, setcookie, removecookie] = useCookies(["jwttoken"]);
  const [assetList, setassetList] = useState([]);
  const [editAssetData, seteditAssetData] = useState();
  const [viewModal, setviewModal] = useState(false);
  const navigate = useNavigate();
  const getUserAsset = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/asset/getAssetsOfUser`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setassetList(response.data);
      })
      .catch((error) => {});
  };
  useEffect(() => {
    getUserAsset();
  }, []);

  return (
    <div className="asset-details">
      {assetList?.length < 1 && (
        <div className="asset-header">
          <button className="add-assetbtn" onClick={() => setshowModal(true)}>
            <FaPlus />
            &nbsp; Add Assets
          </button>
        </div>
      )}
      <div className="asset-list">
        {assetList?.map((asset) => {
          return (
            <AssetDiv
              seteditAssetData={seteditAssetData}
              asset={asset}
              setviewModal={setviewModal}
              closeModal={setopenEditModal}
            />
          );
        })}
        {showModal && (
          <AddAssetModal closeModal={setshowModal} modalfun={getUserAsset} />
        )}
        {shownewTaggedAsset && (
          <UpdateOldAsset
            closeModal={setshownewTaggedAsset}
            modalfun={getUserAsset}
          />
        )}
        {openEditModal && (
          <EditAssetModal
            setshownewTaggedAsset={setshownewTaggedAsset}
            editAssetData={editAssetData}
            closeModal={setopenEditModal}
            modalfun={getUserAsset}
          />
        )}
        {viewModal && (
          <ViewAssetModal
            editAssetData={editAssetData}
            closeModal={setviewModal}
            modalfun={getUserAsset}
          />
        )}
      </div>&nbsp;


{assetList?.length>=1 &&
      <button
        type="button"
        onClick={() =>
          window.open(
            "https://internalissentinel.ultimatix.net/CompNotify/#/home",
            "_blank"
          )
        }
      >
        Check Competency
      </button>
}
    </div>
  );
}

export default MyAsset;
