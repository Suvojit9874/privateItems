import React, { useContext, useEffect, useState } from "react";
import { Navigate, NavLink, Outlet, useNavigate } from "react-router-dom";
import "./Home.css";
import { BsFire, BsFolderFill, BsCalendar2RangeFill } from "react-icons/bs";
import { HiRectangleGroup } from "react-icons/hi2";
import { TbTableFilled } from "react-icons/tb";
import { FaFileExport } from "react-icons/fa6";

import { FaUsersLine } from "react-icons/fa6";
import Select from "react-select";
import makeAnimated from "react-select/animated";
// import { colourOptions } from './docs/data'
import { IoMdCloudUpload } from "react-icons/io";

import { IoSettings } from "react-icons/io5";
import { MdSpaceDashboard } from "react-icons/md";
import { AiFillHome } from "react-icons/ai";
import { IoLogOut } from "react-icons/io5";
import { useCookies } from "react-cookie";
import { TbAlertSquareRoundedFilled } from "react-icons/tb";
import { FaLaptop, FaUser } from "react-icons/fa";

import Cookies from "./Login";
import { jwtDecode } from "jwt-decode";
import axios from "axios";
// import {useNavigate} from "react-router-dom";
import { BatchContext } from "./context/BatchContext";
import { ImUpload2 } from "react-icons/im";
import Timechart from "./dashboard/Timechart";

function Home() {
  const { batchName, setBatchName,role,setrole,refresh,setrefresh } = useContext(BatchContext);

  const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL;
  const navigate = useNavigate();
  // const animatedComponents = makeAnimated();
  const [cookies, setcookie, removecookie] = useCookies(["jwttoken"]);
  const [batch, setBatch] = useState([]);
  const logoutFun = () => {
    removecookie("jwttoken");
    navigate("/");
  };
  const getRole = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/api/v1/auth/getRole`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setrole(response.data);
        console.log(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  useEffect(() => {
    getRole();
    const token = cookies.jwttoken;
    if (token) {
      const decodedToken = jwtDecode(token);
      if (decodedToken.exp * 1000 < Date.now()) {
        removecookie("jwttoken");
        navigate("/");
      }
    } else {
      removecookie("jwttoken");
      navigate("/");
    }
  }, []);

  const getBatch = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/admin/getBatches`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setBatchName(response.data[response.data.length - 1]);
        setBatch(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  useEffect(() => {
    getBatch();
  }, [refresh]);

  return (
    <div className="home-root home-container">
      <div className="header">
        <div id="nav-header">
          <span>Asset Tracker</span>
          <div className="drop-main">
            {role === "ADMIN" && (
              <>
                <span>Select Batch</span>
                <Select
                  id="batch-selector"
                  styles={{border:'none !important'}}
                  closeMenuOnSelect={false}
                  options={batch}
                  onChange={(e) => setBatchName(e)}
                  value={batchName}
                />
              </>
            )}
          </div>
          <img src="/tcs.png" height={"100%"} alt='tcs logo' style={{marginLeft:"20px"}}></img>
        </div>
      </div>
      <div className="remainingbody">
        <div id="nav-bar">
          <div className="sidebar">
            <div
              className="sidebar-upper"
              style={{ width: "100%", height: "auto" }}
            >
              {role === "ADMIN" && (
                <>
                  <NavLink
                    end
                    to=""
                    className={({ isActive }) =>
                      isActive ? "sidebarmenuactive" : "sidebarmenu"
                    }
                  >
                    <div className="sidebarmenu-icon">
                      <AiFillHome size={"2rem"}></AiFillHome>
                    </div>
                      <div className="sidebarmenu-text">Home</div>
                  </NavLink>
                  <NavLink
                    to="users"
                    className={({ isActive }) =>
                      isActive ? "sidebarmenuactive" : "sidebarmenu"
                    }
                  >
                    <div className="sidebarmenu-icon">
                      <FaUsersLine size={"2rem"}></FaUsersLine>
                    </div>
                    <div className="sidebarmenu-text">Existing Users</div>
                  </NavLink>
                  <NavLink
                    to="issues"
                    className={({ isActive }) =>
                      isActive ? "sidebarmenuactive" : "sidebarmenu"
                    }
                  >
                    <div className="sidebarmenu-icon">
                      <TbAlertSquareRoundedFilled
                        size={"2rem"}
                      ></TbAlertSquareRoundedFilled>
                    </div>
                    <div className="sidebarmenu-text">Issues</div>
                  </NavLink>
                  <NavLink
                    to="assets"
                    className={({ isActive }) =>
                      isActive ? "sidebarmenuactive" : "sidebarmenu"
                    }
                  >
                    <div className="sidebarmenu-icon">
                      <HiRectangleGroup size={"2rem"}></HiRectangleGroup>
                    </div>
                    <div className="sidebarmenu-text">Assets</div>
                  </NavLink>
                    
                  <NavLink
                    to="exportdata"
                    className={({ isActive }) =>
                      isActive ? "sidebarmenuactive" : "sidebarmenu"
                    }
                  >
                    <div className="sidebarmenu-icon">
                      <FaFileExport size={"2rem"}></FaFileExport>
                    </div>
                    <div className="sidebarmenu-text">Export</div>
                  </NavLink>

                  <NavLink
                    to="dataupload"
                    className={({ isActive }) =>
                      isActive ? "sidebarmenuactive" : "sidebarmenu"
                    }
                  >
                    <div className="sidebarmenu-icon">
                      <IoMdCloudUpload size={"2rem"}></IoMdCloudUpload>
                    </div>
                    <div className="sidebarmenu-text">Bulk User Upload</div>
                  </NavLink>
                  <NavLink
                    to="batchdataup"
                    className={({ isActive }) =>
                      isActive ? "sidebarmenuactive" : "sidebarmenu"
                    }
                  >
                    <div className="sidebarmenu-icon">
                      <ImUpload2 size={"1.8rem"}></ImUpload2>
                    </div>
                    <div className="sidebarmenu-text">Permanent Batching</div>
                  </NavLink>
                </>
              )}
              {role === "TRAINEE" && (
                <>
                  <NavLink
                    end
                    to=""
                    className={({ isActive }) =>
                      isActive ? "sidebarmenuactive" : "sidebarmenu"
                    }
                  >
                    <div className="sidebarmenu-icon">
                      <FaUser size={"1.6rem"}></FaUser>{" "}
                    </div>
                    <div className="sidebarmenu-text">Profile</div>
                  </NavLink>
                  <NavLink
                    to="myasset"
                    className={({ isActive }) =>
                      isActive ? "sidebarmenuactive" : "sidebarmenu"
                    }
                  >
                    <div className="sidebarmenu-icon">
                      <FaLaptop
                        size={"1.9rem"}
                      ></FaLaptop>{" "}
                    </div>
                    <div className="sidebarmenu-text">My Asset</div>
                  </NavLink>
                  <NavLink
                    to="myissue"
                    className={({ isActive }) =>
                      isActive ? "sidebarmenuactive" : "sidebarmenu"
                    }
                  >
                    <div className="sidebarmenu-icon">
                      <TbAlertSquareRoundedFilled
                        size={"2rem"}
                      ></TbAlertSquareRoundedFilled>{" "}
                    </div>
                    <div className="sidebarmenu-text">My Issues</div>
                  </NavLink>
                 
                </>
              )}
              <div className="project-divider"></div>
              <a className="sidebarmenu">
                <div className={"sidebarmenu"} onClick={logoutFun}>
                  <div className="sidebarmenu-icon">
                    <IoLogOut size={"2rem"}></IoLogOut>
                  </div>

                  <div  className="sidebarmenu-text"> Logout </div>
                </div>
              </a>
            </div>
            <div className="sidebar-bottom"></div>
          </div>
        </div>
        <div className="content">
          <div className="routecontent">
            <Outlet batchName={batchName} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;
