import React, { useContext, useEffect, useState } from "react";
import IssueStats from "./IssueStats";
import IssueChart from "./IssueChart";
import MostOccurredRequests from "./MostOccurredRequests";
import Timechart from "./Timechart";

import "./dash.css";
import { useCookies } from "react-cookie";
import { BatchContext } from "../context/BatchContext";
import axios from "axios";
import { HashLoader } from "react-spinners";
import AllIssueChart from "./AllIssueChart";

// const mostOccurredRequests = [
//   { title: 'Hardware', count: 23 },
//   { title: 'Software', count: 17 },
//   { title: 'Network', count: 15 },
// ];

const Dashboard = () => {
  const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL;
  const { batchName, setBatchName, role, setrole } = useContext(BatchContext);
  const [cookies, setCookie, removeCookie] = useCookies(["jwttoken"]);
  const [dashboardData, setdashboardData] = useState({});
  const [loading, setloading] = useState(true);

  useEffect(() => {
    fetchCounts();
    console.log(batchName.label);
  }, [batchName]);

  const fetchCounts = () => {
    setloading(true);
    axios({
      url: `${REACT_APP_BASE_URL}/adminDashboard/getCounts/${batchName.label}`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setdashboardData(response.data);
        setloading(false);

        // console.log(response.data);
      })
      .catch((error) => {
        setloading(false);
        console.log(error);
      });
  };
  return (
    <div className="dashboard">
      <h1 className="dashboardheading">Welcome Back!</h1>
      {loading ? (
        <div className="loaderdiv">
          <HashLoader color={"#2f215e"} size={"60"}></HashLoader>
        </div>
      ) : (
        <div class="scroll">
          <div className="main-container">
            <IssueStats dashboardData={dashboardData} />
            <IssueChart graphData={dashboardData?.graphData} />
            <MostOccurredRequests categoryData={dashboardData?.categoryData} />
          </div>
          <div className="main-container">
            {/* <MostOccurredRequests categoryData={dashboardData?.categoryData}/> */}
            <Timechart weeklyCount={dashboardData?.weeklyCount}/>
          </div>
          <div className="main-container">
            {/* <MostOccurredRequests categoryData={dashboardData?.categoryData}/> */}
            <AllIssueChart graphData={dashboardData?.allIssueGraph} />
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
