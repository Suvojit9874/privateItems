import React from 'react';
import "./MostOccurredRequests.css";
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from "recharts";

const MostOccurredRequests = ({ categoryData }) => {
  const COLORS = ['#8884d1', '#8884d1', '#8884d1', '#8884d1'];

  const truncateText = (text, maxLength) => {
    if (text.length > maxLength) {
      return text.substring(0, maxLength) + '...';
    }
    return text;
  };

  const renderCustomizedLabel = ({ x, y, name, value, index }) => {
    return (
      <text
        x={x}
        y={y}
        fill="#2f215e"
        textAnchor="middle"
        dominantBaseline="central"
        fontSize="0.9rem"
      >
        {truncateText(name, 10)} {value}
      </text>
    );
  };

  return (
    <div className="most-occurred-requests">
      <h3>Category</h3>&nbsp;
      <div style={{ width: "100%", height: "100%",boxSizing:"border-box" }}>
        <ResponsiveContainer>
          <PieChart>
            <Pie
              dataKey="issuecount"
              isAnimationActive={true}
              animationDuration={500}
              data={categoryData}
              cx="50%"
              cy="50%"
              fill="#8884d8"
              label={renderCustomizedLabel}
              nameKey="categoryname"
              innerRadius={40} outerRadius={80}
              paddingAngle={5}

            >
              {categoryData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default MostOccurredRequests;
