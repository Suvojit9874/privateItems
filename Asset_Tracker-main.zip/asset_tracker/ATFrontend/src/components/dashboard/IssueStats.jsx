import React, { useContext, useEffect, useState } from 'react';
import StatCard from './StatCard';
import { useCookies } from "react-cookie";
// import { jwtDecode } from "jwt-decode";
import axios from "axios";
import { BatchContext } from '../context/BatchContext';



const IssueStats = ({dashboardData}) => {

    

  return (
    <div className="stats-container">
      <StatCard title="No. of Issues" value={dashboardData.totalIssue} />
      <StatCard title="Pending Issues" value={dashboardData.pendingIssue} />
      <StatCard title="Resolved Issues" value={dashboardData.resolvedIssue} />
      <StatCard title="Total No. of Users" value={dashboardData.totalUser} />
      <StatCard title="Registered Assets" value={dashboardData.registeredAsset} />
    </div>
  );
};

export default IssueStats;
