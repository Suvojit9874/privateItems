import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const Timechart = ({ weeklyCount }) => {
  return (
    <div className="most-occurred-requests">
      <h3 style={{ color: '#2f215e' }}>Weekly Reported Vs Resolved Issues</h3>&nbsp;
      <div style={{ width: "100%", height: 280 }}>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart
            width={500}
            height={300}
            data={weeklyCount}
            margin={{
              top: 5,
              right: 30,
              left: 20,
              bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="3 3"/>
            <XAxis dataKey="reported" tick={{ fill: '#2f215e' }} />
            <YAxis tick={{ fill: '#2f215e' }} />
            <Tooltip contentStyle={{ color: '#2f215e' }} />
            {/* <Legend wrapperStyle={{ color: '#2f215e' }} /> */}
            <Line
              type="monotone"
              dataKey="issuecount"
              stroke="#8884d8"
              name="Issue Reported"
            />
            <Line
              type="monotone"
              dataKey="resolvedcount"
              stroke="#82ca9d"
              name="Issue Resolved"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export default Timechart;
