import React, { createContext, useEffect, useState } from 'react';

const BatchContext = createContext();

const BatchProvider = ({ children }) => {
  const [batchName, setBatchName] = useState({});
  const [role, setrole] = useState("")
  const [refresh, setrefresh] = useState(true)
  useEffect(() => {
   console.log(refresh);
  }, [refresh])
  
  return (
    <BatchContext.Provider value={{ batchName, setBatchName,role, setrole,refresh,setrefresh}}>
      {children}
    </BatchContext.Provider>
  );
};

export { BatchProvider, BatchContext };