import React from 'react';
import './Asset.css';

const AssetDetails = () => {

  const submitHandler=()=>{
    console.log("Butoon clicked");
  }

  const assetHandler=()=>{
    console.log("asset created")
  }

  return (

    <div className="asset-tracking">

      <h2>Asset  Details</h2>
      <div><button className='btn1' onClick={assetHandler}>Create Asset</button></div>
      <hr
      
        style={{
          background: 'purple',
          color: 'lime',
          borderColor: 'pruple',
          height: '3px',
          width:'100%'
        }}
      />
      


      <div className="header">
        
        <div className="header-item">Asset_id</div>
        <div className="header-item">Employee_id</div>
        <div className="header-item">Name</div>
        <div className="header-item">Company</div>
        

      </div>
      
      <div className="body">
        <div className="body-item">
          <select>
            <option value="asset1">Asset 1</option>
            <option value="asset2">Asset 2</option>

          </select>
        </div>
        <div className="body-item">
          <select>
            <option value="employee1">Employee 1</option>
            <option value="employee2">Employee 2</option>
          </select>

        </div>

        <div className="body-item">

          <select>
            <option value="name1">Name 1</option>
            <option value="name2">Name 2</option>
          </select>
        </div>
        <div className="body-item">
          <select>
            <option value="company1">Company 1</option>
            <option value="company2">Company 2</option>
          </select>

          

        </div>
      </div>
      <button onClick={submitHandler} className='btn'>Submit</button>
    </div>

  );

};

export default AssetDetails;

