import React, { useContext, useEffect, useState } from "react";
import ReactPaginate from "react-paginate";
import Select from "react-dropdown-select";
import makeAnimated from "react-select/animated";
import { HashLoader } from "react-spinners";
import "./ViewAssets.css";
import { useCookies } from "react-cookie";
import axios from "axios";
import { BatchContext } from "./context/BatchContext";
import AssetDiv from "./AssetDiv";
import AddIssueModal from "./Modals/AddIssueModal";
import EditAssetModal from "./Modals/EditAssetModal";
import ViewAssetModal from "./Modals/ViewAssetModal";

const itemsPerPage = 4;

const BitlockerOptions = [
  { value: true, label: "Yes" },
  { value: false, label: "No" }
];
const vdiOptions = [
  { value: true, label: "Yes" },
  { value: false, label: "No" }
];
const vdiInstallOptions = [
  { value: true, label: "Yes" },
  { value: false, label: "No" }
];

const searchOptions = [
  { value: "location", label: "Location" },
  { value: "assetId", label: "Asset ID" },
  { value: "manufacturer", label: "Manufacturer" },
  { value: "userId", label: "User ID" },
  { value: "email", label: "Email" },
];

function ViewAssets() {
  const [editAssetData, seteditAssetData] = useState({});
  const { batchName, setBatchName, role, setrole } = useContext(BatchContext);
  const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL;
  const [cookies] = useCookies(["jwttoken"]);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchOption, setSearchOption] = useState([{ value: "location", label: "Location" }]);
  const [currentPage, setCurrentPage] = useState(0);
  const [selectedVdi, setSelectedVdi] = useState([]);
  const [selectedVdiWorking, setSelectedVdiWorking] = useState([]);
  const [selectedBitLocker, setSelectedBitLocker] = useState([]);
  const [assetData, setAssetData] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [openEditModal, setopenEditModal] = useState(false);
  const [loading, setloading] = useState(true);
  const [viewModal, setviewModal] = useState(false);

  const getAllAssets = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/asset/getAllAssets/${batchName?.label}`,
      method: "GET",
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
    })
      .then((response) => {
        setloading(false);
        console.log("Fetched assets data:", response.data);
        setAssetData(response.data);
      })
      .catch((error) => {
        setloading(false);
        console.error("Error fetching assets data:", error);
      });
  };

  useEffect(() => {
    setloading(true);
    getAllAssets();
  }, [batchName]);

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleSearchOptionChange = (selectedOptions) => {
    setSearchOption(selectedOptions || []);
  };

  const handlePageClick = (event) => {
    setCurrentPage(event.selected);
  };

  const handleVdiChange = (selectedOptions) => {
    setSelectedVdi(selectedOptions || []);
  };

  const handleVdiWorkingChange = (selectedOptions) => {
    setSelectedVdiWorking(selectedOptions || []);
  };

  const handleBitLockerChange = (selectedOptions) => {
    setSelectedBitLocker(selectedOptions || []);
  };

  const filteredAssets = assetData.filter(
    (asset) =>
      asset[searchOption[0]?.value]?.toString().toLowerCase().includes(searchTerm.toLowerCase()) &&
      (selectedBitLocker.length === 0 || selectedBitLocker.some((bt) => bt.value === asset.bitlockerStatus)) &&
      (selectedVdiWorking.length === 0 || selectedVdiWorking.some((vdi) => vdi.value === asset.cpaIssue)) &&
      (selectedVdi.length === 0 || selectedVdi.some((vdiInstall) => vdiInstall.value === asset.vdiInstalled))
  );

  const offset = currentPage * itemsPerPage;
  const currentPageData = filteredAssets.slice(offset, offset + itemsPerPage);

  console.log("Filtered assets data:", filteredAssets);

  return (
    <div className="asset-details">
      <div className="asset-header">
        <Select
          options={searchOptions}
          value={searchOption}
          onChange={handleSearchOptionChange}
          components={makeAnimated()}
          className="search-option"
          multi={false}
          style={{
            minWidth: "170px",
            padding: "10px",
          }}
        />
        <input
          type="text"
          placeholder="Search..."
          value={searchTerm}
          onChange={handleSearch}
          className="search-bar"
         
        />
        <Select
          closeMenuOnSelect={false}
          components={makeAnimated()}
          multi={true}
          options={BitlockerOptions}
          placeholder="Bitlocker Status"
          onChange={handleBitLockerChange}
          className="bitlocker-select"
          style={{
            minWidth: "70px",
            padding: "10px",
          }}
        />
        <Select
          closeMenuOnSelect={false}
          components={makeAnimated()}
          multi={true}
          options={vdiOptions}
          placeholder="VDI(CPA) Status"
          onChange={handleVdiWorkingChange}
          className="location-select"
          style={{
            minWidth: "100px",
            padding: "10px",
          }}
        />
        <Select
          closeMenuOnSelect={false}
          multi={true}
          components={makeAnimated()}
          options={vdiInstallOptions}
          placeholder="VDI Installed"
          onChange={handleVdiChange}
          className="location-select"
          style={{
            minWidth: "100px",
            padding: "10px",
          }}
        />
      </div>

      <div className="asset-list">
        {currentPageData.length === 0 ? (
          <p>No assets found.</p>
        ) : (
          currentPageData.map((asset) => (
            <AssetDiv
              seteditAssetData={seteditAssetData}
              asset={asset}
              closeModal={setopenEditModal}
              setviewModal={setviewModal}
            />
          ))
        )}
      </div>
      {loading && <HashLoader color={"#2f215e"} size={"60"} />}

      <ReactPaginate
        previousLabel={"previous"}
        nextLabel={"next"}
        breakLabel={"..."}
        pageCount={Math.ceil(filteredAssets.length / itemsPerPage)}
        marginPagesDisplayed={2}
        pageRangeDisplayed={3}
        onPageChange={handlePageClick}
        containerClassName={"pagination"}
        subContainerClassName={"pages pagination"}
        activeClassName={"active"}
      />
      {isModalOpen && (
        <AddIssueModal closeModal={setIsModalOpen} modalfun={getAllAssets} />
      )}
      {openEditModal && (
        <EditAssetModal editAssetData={editAssetData} closeModal={setopenEditModal} modalfun={getAllAssets} />
      )}
      {viewModal && (
        <ViewAssetModal editAssetData={editAssetData} closeModal={setviewModal} modalfun={getAllAssets} />
      )}
    </div>
  );
}

export default ViewAssets;
