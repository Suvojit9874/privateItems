import React from 'react'

function Temp() {
  return (
    <div>Temp</div>
  )
}

export default Temp