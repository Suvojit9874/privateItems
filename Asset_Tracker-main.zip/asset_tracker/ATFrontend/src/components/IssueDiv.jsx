import React, { useState } from 'react'
import { FaUserCircle } from 'react-icons/fa';
import { HiMiniBugAnt } from 'react-icons/hi2';
import { MdExpandMore, MdExpandLess, MdEmail, MdEdit, MdReportProblem } from 'react-icons/md';
import { FaClipboardCheck } from "react-icons/fa";

import { RxLapTimer } from "react-icons/rx";
import { IoCheckmarkDoneCircle } from "react-icons/io5";
import { FaCircleExclamation } from "react-icons/fa6";

import { IoNewspaperOutline } from "react-icons/io5";
import {  formatRelative, subDays } from 'date-fns'
function IssueDiv({ issue,closeModal,seteditIssueData,setviewModal,setshowSolutionModal}) {

  const [isOpen, setisOpen] = useState(false)

  return (
    <div key={issue.issueId} className="issues-item" onDoubleClick={() => setisOpen(!isOpen)}>
      <div className="accordianhead">
        <div className='Bug-icon'><FaCircleExclamation className="div-icons" size={"1.5rem"} /></div>
        <div className="data-issues" id="issueId"> {issue.issueName}</div>
        <div className="data-issues" id="ticketNumber"><IoNewspaperOutline className="div-icons" size={"1rem"} />
          {issue.ticketNumber != null ? "No Tickets" : issue.ticketNumber}
        </div>
        <div className="data-issues" id="issueName"><b>Category:</b> {issue.category}</div>
        
        <div className="data-issues" id="status">
        {issue.statusName=="PENDING"?<RxLapTimer className="div-icons" size={"1.2rem"} />:<FaClipboardCheck className="div-icons" size={"1.2rem"} />}{issue.statusName}
         </div> 
          {/* {issue.statusName == Pending ? <MdPendingActions /> :<AiOutlineFileDone />}
           */}
        <div className="data-issues" id="email"><MdEmail className="div-icons" /> {issue.email}</div>
       {issue?.statusId==1&&
        <span className='editbutton' onClick={()=>{seteditIssueData(issue);closeModal(true)}} >
                    <MdEdit size={"1.4rem"} />
        </span>
       }
        <div onClick={() => setisOpen(!isOpen)}>
          {isOpen ?
            <MdExpandMore size={"1.5rem"} />
            :
            <MdExpandLess size={"1.5rem"} />
          }
        </div >
        <div className='button-div' style={{display:"flex",flexDirection:"column",gap:"3px"}}>
        <button style={{
          height:'35px',
          width:'100px',
        }} onClick={()=>{seteditIssueData(issue);setviewModal(true)}}>view&nbsp;&nbsp;</button>
        <button style={{
          height:'35px',
          width:'100px'
        }} onClick={()=>{seteditIssueData(issue);setshowSolutionModal(true)}}>solution&nbsp;&nbsp;</button>
        </div>

      </div>
      <div className={`${isOpen ? "accshow" : "acchide"}`}>
        {console.log(issue)}
        <div className='discripion-box'>
          {/* {issue.ticketNumber != null ? <div ><b>&nbsp;Ticket:&nbsp;</b> ${issue.ticketNumber}</div>:<></>   }
          <div  ><b>&nbsp;IDM Replay:&nbsp;</b> {issue.idmReply == null ? "No Reply" : issue.idmReply}</div>
          <div className='discription-box' ><b>&nbsp;Discription:&nbsp;</b> {issue.issueDescription == null ? "No discription" : issue.issueDescription}</div>
          <div className='discription-box'><b>&nbsp;Comments:&nbsp;</b><textarea disabled='true' value= {issue.issueComment == null ? "No Comments" : issue.issueComment}></textarea></div> */}
          <div style={{margin:'4px'}}><b>&nbsp;Reported:&nbsp;</b> {issue.reportedAt == null ? "" : formatRelative(subDays(issue.reportedAt, 0),new Date() )} </div>
          <div ><b>&nbsp;Resolved At:&nbsp;</b> {issue.resolvedAt == null ? "Not yet Resolved" :formatRelative(subDays(issue.reportedAt, 0),new Date()  ) }</div>
        </div>
      </div>
    </div>
  )
}

export default IssueDiv