import { useCookies } from "react-cookie";
import "./modal.css";
import OutsideClickHandler from "react-outside-click-handler";
import axios from "axios";
import { useEffect, useState } from "react";
import Select from "react-dropdown-select";
import { errortoast, successtoast } from "../ExtraExports/Exports";
import Switch from "react-switch";
import { useDropzone } from 'react-dropzone';
import Tesseract from 'tesseract.js';
import "./AddAssetAnimation.css"
import { HashLoader } from "react-spinners";

function UpdateOldAsset({ closeModal, modalfun }) {
  const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL;
  const [cookies, setcookie, removecookie] = useCookies(["jwttoken"]);
  const [manufacturerList, setmanufacturerList] = useState([])
  const [locationList, setlocationList] = useState([])
  const [step, setStep] = useState(1);
  const [detectedText, setDetectedText] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [loading, setloading] = useState(false)
  const [assetDetails, setassetDetails] = useState({
    "assetId": "",
    "mid": null,
    "bitlockerStatus": false,
    "vdiInstalled": false,
    "vdiWorking": false,
    "locId": null,
    "zscalerWorking": false,
    "duoWorking": false,
    "cpaIssue": false,
    "gwsIssue": false,
    "adminLogin": false
  })
  const getManufacturerOptions = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/asset/getManufacturerOptions`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setmanufacturerList(response.data)
      })
      .catch((error) => {
      });
  }
  const getLocationOptions = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/asset/getLocationOptions`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setlocationList(response.data)
      })
      .catch((error) => {
      });
  }



  useEffect(() => {
    getLocationOptions()
    getManufacturerOptions()
  }, [])


  const addAsset = () => {
    if (assetDetails.assetId.length != 11
      || assetDetails.locId == null
      || assetDetails.mid == null
    ) {
      errortoast("Please Fill All The Field")
      return;
    }
    console.log(assetDetails);
    axios({
      url: `${REACT_APP_BASE_URL}/asset/updateOldAsset`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "PUT",
      data: assetDetails
    })
      .then((response) => {
        successtoast("Added Issue Succesfully")
        modalfun()
        closeModal(false)

      })
      .catch((error) => {
        errortoast("Duplicate Asset Not Allowed")
      });
  }
  const onDrop = (acceptedFiles) => {
    setloading(true)
    const file = acceptedFiles[0];
    const reader = new FileReader();

    reader.onload = () => {
      setImagePreview(reader.result);

      Tesseract.recognize(
        reader.result,
        'eng',
        {
          logger: (m) => console.log(m)
        }
      ).then(({ data: { text } }) => {
        const matchedText = text.match(/01HW\w*/g);
        if (matchedText && matchedText.length > 0)
          setassetDetails({ ...assetDetails, assetId: matchedText[0] || "" })
        setDetectedText(matchedText ? matchedText.join(', ') : 'No Asset Found');

        // Validation
        if (!text.includes("Inward Outward Material Movement System") || !text.includes("Select the asset to return")) {
          errortoast("Please Upload Valid Screenshot")
        } else {
          successtoast("Uploaded Valid Screenshot")
        }
        setloading(false)
      });
    };

    reader.readAsDataURL(file);
  };

  const { getRootProps, getInputProps } = useDropzone({ onDrop });

  const handleReupload = () => {
    setloading(false)
    setDetectedText(null);
    setImagePreview(null);
    setStep(1);
  };
  const handleContinue = () => setStep(2);
  const handleSaveDetails = () => setStep(1);
  return (
    <div className="createprojectmodalouter">
      <OutsideClickHandler
        onOutsideClick={() => {
          closeModal(false);
        }}
      >
        
        <div className="card scale-up-center-anmiation" style={{width:'450px'}} >
          <div className="card-header">
            <div className="text-header">Add Newly Tagged Asset</div>
          </div>
          <div className="card-body">
            {step == 1 ?
              <>
                <div className="assetuploadDiv">
                  <>
                    <div {...getRootProps({ className: 'assetmodaldropzone' })}>
                      <input {...getInputProps()} />
                      <p>Drag & drop an image here, or click to select one</p>
                    </div>
                    <a style={{ marginTop: "10px" }} target="_blank" href="https://mmt-sbws.ultimatix.net/mmt/index.html?cd=1722331906516#/sbwsReturnRequest">Go To MMT Page</a>
                  </>
                  {loading ?
                    <div className="loaderdiv">
                      <HashLoader color={"#2f215e"} size={"60"} ></HashLoader>
                    </div>
                    :
                    <>
                      {imagePreview && (
                        <div className="assetmodalimage-preview-container assetgap form-group">
                          <label className="assetmodalheader">Image Preview:</label>
                          <img src={imagePreview} alt="Preview" className="assetmodalimage" />
                        </div>
                      )}
                      {detectedText && (
                        <div className="form-group assetgap">
                          <h3 className="assetmodalheader">Detected AssetId:</h3>
                          <p>{detectedText}</p>
                        </div>
                      )}
                    </>

                  }

                </div>
                {imagePreview &&
                  <>
                    <button onClick={handleReupload}>Reupload</button>
                    {detectedText != "No Asset Found" &&
                      <button onClick={handleContinue}>Continue</button>
                    }
                  </>
                }
              </>
              :
              <>
                <div className="form-group">
                  <label htmlFor="username">Asset Id: *</label>
                  <input value={assetDetails?.assetId} maxLength={11} type="text" disabled></input>
                </div>
                <div className="form-group">
                  <label htmlFor="email">Select Manufacturer: *</label>
                  <Select
                    style={{
                      borderRadius: "9px",
                      height: "40px",
                      paddingLeft: "15px",
                    }}
                    options={manufacturerList}
                    searchable={false}
                    onChange={(e) => { setassetDetails({ ...assetDetails, mid: e[0].value }) }}
                  ></Select>
                </div>

                <div className="form-group">
                  <label htmlFor="confirm-password">Select Location: *</label>
                  <Select
                    style={{
                      borderRadius: "9px",
                      height: "40px",
                      paddingLeft: "15px",
                    }}
                    options={locationList}
                    searchable={false}
                    onChange={(e) => { setassetDetails({ ...assetDetails, locId: e[0].value }) }}

                  ></Select>
                </div>
                <div className="form-container" style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '20px' }}>
                <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <label htmlFor="bitlocker-status">BitLocker Status:</label>
                  <Switch 
                    onColor={"#2f215e"} 
                    onChange={(checked) => setassetDetails({ ...assetDetails, bitlockerStatus: checked })} 
                    checked={assetDetails.bitlockerStatus} 
                  />
                </div>
                <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <label htmlFor="vdi-installed">VDI Installed:</label>
                  <Switch 
                    onColor={"#2f215e"} 
                    onChange={(checked) => setassetDetails({ ...assetDetails, vdiInstalled: checked })} 
                    checked={assetDetails.vdiInstalled} 
                  />
                </div>
                <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <label htmlFor="cpa-issue">VDI(CPA) Working:</label>
                  <Switch 
                    onColor={"#2f215e"} 
                    onChange={(checked) => setassetDetails({ ...assetDetails, cpaIssue: checked })} 
                    checked={assetDetails.cpaIssue} 
                  />
                </div>
               
                <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <label htmlFor="zscaler-working">ZScaler Working:</label>
                  <Switch 
                    onColor={"#2f215e"} 
                    onChange={(checked) => setassetDetails({ ...assetDetails, zscalerWorking: checked })} 
                    checked={assetDetails.zscalerWorking} 
                  />
                </div>
                <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <label htmlFor="duo-working">Duo Working:</label>
                  <Switch 
                    onColor={"#2f215e"} 
                    onChange={(checked) => setassetDetails({ ...assetDetails, duoWorking: checked })} 
                    checked={assetDetails.duoWorking} 
                  />
                </div>
              
                <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <label htmlFor="gws-issue">GWS Issue:</label>
                  <Switch 
                    onColor={"#2f215e"} 
                    onChange={(checked) => setassetDetails({ ...assetDetails, gwsIssue: checked })} 
                    checked={assetDetails.gwsIssue} 
                  />
                </div>
                <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <label htmlFor="admin-login">Admin Login:</label>
                  <Switch 
                    onColor={"#2f215e"} 
                    onChange={(checked) => setassetDetails({ ...assetDetails, adminLogin: checked })} 
                    checked={assetDetails.adminLogin} 
                  />
                </div>
              </div>

                <button onClick={addAsset} >
                  Add Newly Tagged Asset
                </button>
                <button onClick={handleReupload} >
                  Reupload
                </button>
              </>
            }
          </div>
        </div>
      </OutsideClickHandler>
    </div>
  );
}


export default UpdateOldAsset;
