import { useCookies } from "react-cookie";
import "./modal.css";
import OutsideClickHandler from "react-outside-click-handler";
import axios from "axios";
import { useEffect, useState } from "react";
import Select from "react-dropdown-select";
import { errortoast, successtoast } from "../ExtraExports/Exports";
import { formatRelative, subDays } from "date-fns";


function ViewIssueModel({ closeModal, modalfun, editIssueData }) {
    const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL;
    const [cookies, setcookie, removecookie] = useCookies(["jwttoken"]);
    const [assetList, setassetList] = useState([])
    const [categoryList, setcategoryList] = useState([])
    const [categoryId, setcategoryId] = useState({})
    const [issueList, setissueList] = useState([])
    const [statusList, setstatusList] = useState([])
    const [addIssueDetails, setaddIssueDetails] = useState({
        "aaId": editIssueData?.aaId,
        "issueId": editIssueData?.issueId,
        "issueComment": editIssueData?.issueComment,
        "ticketNumber": editIssueData?.ticketNumber,
        "idmReply": editIssueData?.idmReply,
        "categoryId": editIssueData?.categoryId,
        "statusId": editIssueData?.statusId,
        "userSolution":editIssueData?.userSolution

    })

    useEffect(() => {
        console.log(editIssueData, "++++");
    }, [])

    const handleticketChange = (e) => {
        const newValue = e.target.value;
        if (/^\d*$/.test(newValue) && newValue.length <= 10) {
            setaddIssueDetails({ ...addIssueDetails, ticketNumber: newValue });
        }
    };

    const getAllIssues = () => {
        if (!addIssueDetails?.categoryId) {
            return;
        } else if (addIssueDetails?.categoryId) {
            console.log(addIssueDetails?.categoryId);
            axios({
                url: `${REACT_APP_BASE_URL}/assetissue/getIssueByCategoryId/${addIssueDetails?.categoryId}`,
                headers: { Authorization: `Bearer ${cookies.jwttoken}` },
                method: "GET",
            })
                .then((response) => {
                    setissueList(response.data)
                })
                .catch((error) => {
                });
        }
    }

    useEffect(() => {
    }, [])


    useEffect(() => {
        getAllIssues()
    }, [addIssueDetails?.categoryId])


    return (
        <div className="createprojectmodalouter">
            <OutsideClickHandler
                onOutsideClick={() => {
                    closeModal(false);
                }}>
                <div className="height-modal" >
                <div className="card scale-up-center-anmiation" >
                    <div className="card-header">
                        <div className="text-header">View Issue Details</div>
                    </div>
                    <div className="card-body">
                        <div className="form-group">
                            <label htmlFor="username">Asset:
                                <div className="desc_text">{editIssueData?.assetId}</div>
                            </label>
                        </div>
                        <div className="form-group">
                            <label htmlFor="email">Category:
                                <div className="desc_text">{editIssueData?.category}</div>
                            </label>
                        </div>

                        <div className="form-group">
                            <label htmlFor="confirm-password">Issue:
                                <div className="desc_text">{editIssueData?.issueName}</div>
                            </label>
                        </div>
                        <div className="form-group">
                            <label htmlFor="confirm-password">Status:
                                <div className="desc_text">{editIssueData?.statusName}</div>
                            </label>
                        </div>
                        <div className="form-group">
                            <label htmlFor="confirm-password">Reported At:
                                <div className="desc_text">
                                    {formatRelative(subDays(editIssueData?.reportedAt, 0), new Date())}
                                </div>
                            </label>
                        </div>
                        {editIssueData?.statusName == "RESOLVED" ?
                            <div className="form-group">
                                <label htmlFor="confirm-password">Resolved At:
                                    <div className="desc_text">
                                        {formatRelative(subDays(editIssueData?.resolvedAt, 0), new Date())}
                                    </div>
                                </label>
                            </div>
                            :
                            <></>}

                        <div className="form-group">
                            <label htmlFor="confirm-password">Ticket Number:
                                <div className="desc_text">{editIssueData?.ticketNumber}</div>
                            </label>
                        </div>
                        <div className="form-group">
                            <label htmlFor="confirm-password">Employee Id:
                                <div className="desc_text">{editIssueData?.empId}</div>
                            </label>
                        </div>
                        <div className="form-group">
                            <label htmlFor="confirm-password">Email:
                                <div className="desc_text">{editIssueData?.email}</div>
                            </label>
                        </div>
                        <div className="form-group">
                            <label htmlFor="confirm-password">IDM EMPId:
                                <div className="desc_text">{editIssueData?.idmEmpId?editIssueData?.idmEmpId:"N/A"}</div>
                            </label>
                        </div>
                        <div className="form-group">
                            <label htmlFor="confirm-password">IDM Name:
                                <div className="desc_text">{editIssueData?.idmName?editIssueData?.idmName:"N/A"}</div>
                            </label>
                        </div>
                        {editIssueData?.idmReply != "" ?
                            <div className="form-group">

                                <label htmlFor="confirm-password">IDM Reply:
                                </label>
                                    <div className="desc_textArea">{editIssueData?.idmReply?editIssueData?.idmReply:"N/A"}</div>
                                {/* <textarea
                                    style={{ height: 'fit-content' }}
                                    className="textareacss"
                                    disabled
                                    value={addIssueDetails?.idmReply}
                                ></textarea> */}
                            </div>
                            : <></>}
                        {editIssueData?.userSolution != "" ?
                            <div className="form-group">

                                <label htmlFor="confirm-password">User Solution:
                                </label>
                                    <div className="desc_textArea">{editIssueData?.userSolution?editIssueData?.userSolution:"N/A"}</div>
                                {/* <textarea
                                    style={{ height: 'fit-content' }}
                                    className="textareacss"
                                    disabled
                                    value={addIssueDetails?.idmReply}
                                ></textarea> */}
                            </div>
                            : <></>}
                        {/* {addIssueDetails?.issueDescription != '' ?
                            <div className="form-group">
                                <label htmlFor="confirm-password">Issue Details:
                                  
                                </label>
                                  <div className="desc_textArea">{editIssueData?.issueDescription?editIssueData?.issueDescription:"N/A"}</div>
                               
                            </div> :
                            <></>} */}
                        <div className="form-group">
                            <label htmlFor="confirm-password">Issue Comment:
                                
                            </label>
                            <div className="desc_textArea">{editIssueData?.issueComment?editIssueData?.issueComment:"N/A"}</div>
                            {/* <textarea
                                style={{ height: 'fit-content' }}
                                disabled
                                value={addIssueDetails?.issueComment}
                            ></textarea> */}
                        </div>


                        <button onClick={() => {
                            closeModal(false);
                        }} >
                            Close
                        </button>
                    </div>
                </div>
                </div>
            </OutsideClickHandler>
        </div>
    );
}


export default ViewIssueModel;
