import { useCookies } from "react-cookie";
import "./modal.css";
import OutsideClickHandler from "react-outside-click-handler";
import axios from "axios";
import { useEffect, useState } from "react";
import Select from "react-dropdown-select";
import { errortoast, successtoast } from "../ExtraExports/Exports";


function AddIssueModal({ closeModal, modalfun }) {
  const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL;
  const [cookies, setcookie, removecookie] = useCookies(["jwttoken"]);
  const [assetList, setassetList] = useState([])
  const [categoryList, setcategoryList] = useState([])
  const [categoryId, setcategoryId] = useState({})
  const [issueList, setissueList] = useState([])
  const [issueId, setissueId] = useState(0)
  const [issueSolutionData, setissueSolutionData] = useState({})
  const [step, setstep] = useState(1)
  const [selectedCategory, setselectedCategory] = useState([])
  const [selectedIssue, setselectedIssue] = useState([])
  const [addIssueDetails, setaddIssueDetails] = useState({
    "aaId": null,
    "issueId": null,
    "issueComment": "",
    "ticketNumber": "",
    "idmReply": "",
    "idmEmpId": "",
    "idmName": null,

  })

  const handleticketChange = (e) => {
    const newValue = e.target.value;
    if (/^\d*$/.test(newValue) && newValue.length <= 10) {
      setaddIssueDetails({ ...addIssueDetails, ticketNumber: newValue });
    }
  };
  const handleidmEmpIdChange = (e) => {
    const newValue = e.target.value;
    if (/^\d*$/.test(newValue) && newValue.length <= 10) {
      setaddIssueDetails({ ...addIssueDetails, idmEmpId: newValue });
    }
  };


  const getUserAssets = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/asset/getAssetUserOption`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setassetList(response.data)
      })
      .catch((error) => {
      });
  }
  const getAllCategory = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/assetissue/getAllCategory`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setcategoryList(response.data)
      })
      .catch((error) => {
      });
  }
  const getAllIssues = () => {
    if (categoryId.value) {
      axios({
        url: `${REACT_APP_BASE_URL}/assetissue/getIssueByCategoryId/${categoryId?.value}`,
        headers: { Authorization: `Bearer ${cookies.jwttoken}` },
        method: "GET",
      })
        .then((response) => {
          setissueList(response.data)
        })
        .catch((error) => {
        });
    }
  }

  const getIssueById = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/assetissue/getIssueById/${parseInt(issueId)}`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setissueSolutionData(response.data)
        if (response.data.solution) {
          setstep(2);
        }
      })
      .catch((error) => {
      });
  }

  useEffect(() => {
    getUserAssets()
    getAllCategory()
  }, [])


  useEffect(() => {
    console.log(categoryId);
    getAllIssues()
  }, [categoryId])


  useEffect(() => {
    getIssueById()
  }, [issueId])


  const addIssue = () => {
    if (addIssueDetails.aaId == null ||
      addIssueDetails.issueId == null ||
      addIssueDetails.issueComment == "" ||
      categoryId == {}
    ) {
      errortoast("Please Fill All The Field")
      return;
    }
    console.log(addIssueDetails);
    axios({
      url: `${REACT_APP_BASE_URL}/assetissue/addNewAssetIssue`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "POST",
      data: addIssueDetails
    })
      .then((response) => {
        successtoast("Issue Added Succesfully")
        modalfun()
        closeModal(false)

      })
      .catch((error) => {
        errortoast("Error While Adding Issue")
      });
  }
  return (
    <div className="createprojectmodalouter">
      <OutsideClickHandler
        onOutsideClick={() => {
          closeModal(false);
        }}
      >
        <div className="card scale-up-center-anmiation" style={{width:'450px'}}>
          <div className="card-header">
            <div className="text-header">Add Issue</div>
          </div>
          <div className="card-body">
            {issueSolutionData?.solution && step == 2 ?
              <>
                <label>Possible Solution:</label>
                <h3>{issueSolutionData.solution}</h3>
                <button onClick={() => setstep(1)}>Continue To Raise Issue</button>
                <button onClick={() => closeModal(false)}>Close</button>
              </>
              :
              <>
                <div className="form-group">
                  <label htmlFor="username">Select Asset: *</label>
                  <Select
                    style={{
                      borderRadius: "9px",
                      height: "40px",
                      paddingLeft: "15px",
                    }}
                    values={assetList?.filter((data) => data.value == addIssueDetails?.aaId) || [{ value: 1, label: "Loading Value" }]}
                    options={assetList}
                    searchable={false}
                    onChange={(e) => setaddIssueDetails({ ...addIssueDetails, aaId: e[0].value })}

                  ></Select>
                </div>
                <div className="form-group">
                  <label htmlFor="email">Select Category: *</label>
                  <Select
                    style={{
                      borderRadius: "9px",
                      height: "40px",
                      paddingLeft: "15px",
                    }}
                    values={selectedCategory}
                    options={categoryList}
                    searchable={false}
                    onChange={(e) => { setcategoryId(e[0]); setselectedCategory(e) }}
                  ></Select>
                </div>

                <div className="form-group">
                  <label htmlFor="confirm-password">Select Issue: *</label>
                  <Select
                    style={{
                      borderRadius: "9px",
                      height: "40px",
                      paddingLeft: "15px",
                    }}
                    values={selectedIssue}
                    options={issueList}
                    searchable={false}
                    onChange={(e) => { setaddIssueDetails({ ...addIssueDetails, issueId: e[0].value }); setissueId(e[0].value); setselectedIssue(e) }}
                  ></Select>
                </div>
                <div className="form-group">
                  <label htmlFor="confirm-password">Ticket Number:</label>
                  <input type="text"
                    min={6}
                    maxLength={10}
                    onChange={handleticketChange}
                    value={addIssueDetails?.ticketNumber}
                  ></input>
                </div>
                <div className="form_div_shrinkable">
                  <div className="form-group">
                    <label htmlFor="confirm-password">IDM EMP:</label>
                    <input type="text"
                      min={6}
                      maxLength={10}
                      onChange={handleidmEmpIdChange}
                      value={addIssueDetails.idmEmpId}
                    ></input>
                  </div>
                  <div className="form-group">
                    <label htmlFor="confirm-password">IDM Name:</label>
                    <input type="text"
                      maxLength={20}
                      value={addIssueDetails?.idmName}
                      onChange={(e) => setaddIssueDetails({ ...addIssueDetails, idmName: e.target.value })}

                    ></input>
                  </div>
                </div>


                <div className="form-group">
                  <label htmlFor="confirm-password">IDM Reply:</label>
                  <textarea
                    maxLength={120}
                    onChange={(e) => setaddIssueDetails({ ...addIssueDetails, idmReply: e.target.value })}

                  ></textarea>
                </div>
                <div className="form-group">
                  <label htmlFor="confirm-password">Issue Details: *</label>
                  <textarea
                    maxLength={120}
                    onChange={(e) => setaddIssueDetails({ ...addIssueDetails, issueComment: e.target.value })}

                  ></textarea>
                </div>
                <button onClick={addIssue} >
                  Add Issue
                </button>
              </>
            }
          </div>
        </div>
      </OutsideClickHandler>
    </div>
  );
}


export default AddIssueModal;
