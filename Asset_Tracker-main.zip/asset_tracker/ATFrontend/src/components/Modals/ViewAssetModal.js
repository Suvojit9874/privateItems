import { useCookies } from "react-cookie";
import "./modal.css";
import OutsideClickHandler from "react-outside-click-handler";
import axios from "axios";
import { useContext, useEffect, useState } from "react";
import { errortoast, successtoast } from "../ExtraExports/Exports";
import Switch from "react-switch";
import { BatchContext } from "../context/BatchContext";
import { PiDevicesFill } from "react-icons/pi";


function ViewAssetModal({ closeModal, modalfun, editAssetData }) {
  const { batchName, setBatchName, role, setrole, refresh, setrefresh } = useContext(BatchContext)
  const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL;
  const [cookies, setcookie, removecookie] = useCookies(["jwttoken"]);
  const [categoryId, setcategoryId] = useState({})
  const [issueList, setissueList] = useState([])
  const [assetDetails, setassetDetails] = useState({
    "assetId": editAssetData?.assetId,
    "mid": editAssetData?.mid,
    "bitlockerStatus": editAssetData?.bitlockerStatus,
    "vdiInstalled": editAssetData?.vdiInstalled,
    "vdiWorking": editAssetData?.vdiWorking,
    "locId": editAssetData?.locId,
    "zscalerWorking": editAssetData?.zscalerWorking,
    "duoWorking": editAssetData?.duoWorking

  })


  const getAllIssues = () => {
    if (categoryId.value) {
      axios({
        url: `${REACT_APP_BASE_URL}/assetissue/getIssueByCategoryId/${categoryId?.value}`,
        headers: { Authorization: `Bearer ${cookies.jwttoken}` },
        method: "GET",
      })
        .then((response) => {
          setissueList(response.data)
        })
        .catch((error) => {
        });
    }
  }

  useEffect(() => {
    console.log(editAssetData)
  }, [])


  useEffect(() => {
    getAllIssues()
  }, [categoryId])

  // const updateAsset = () => {
  //   if (assetDetails.assetId.length != 11
  //     || assetDetails.locId == null
  //     || assetDetails.mid == null
  //   ) {
  //     errortoast("Please Fill All The Field")
  //     return;
  //   }
  //   console.log(assetDetails);
  //   axios({
  //     url: `${REACT_APP_BASE_URL}/asset/update/${editAssetData?.aaId}`,
  //     headers: { Authorization: `Bearer ${cookies.jwttoken}` },
  //     method: "PUT",
  //     data: assetDetails
  //   })
  //     .then((response) => {
  //       successtoast("Issue Updated Succesfully")
  //       modalfun()
  //       closeModal(false)

  //     })
  //     .catch((error) => {
  //       errortoast("Error While Updating Issue")
  //     });
  // }

  return (
    <div className="createprojectmodalouter">
      <OutsideClickHandler
        onOutsideClick={() => {
          closeModal(false);
        }}
      >
        <div className="card scale-up-center-anmiation" style={{width:'450px'}}>
          <div className="card-header" >
            <div className="text-header">View Asset Details</div>
          </div>
          <div className="card-body">
            <div className="form-group">
              <label >Asset Id: <div className="desc_text">{assetDetails?.assetId} </div>
              </label>

            </div>
            <div className="form-group">
              <label htmlFor="email">Manufacturer:
                <div className="desc_text">
                  <PiDevicesFill className="div-icons" size={"1.4rem"} />
                  {editAssetData?.manufacturer}
                </div> </label>
            </div>

            <div className="form-group">
              <label htmlFor="confirm-password">Location: <div className="desc_text">{editAssetData?.location}</div> </label>
            </div>
            <div className="form-group">
              <label htmlFor="confirm-password">Employee Id: <div className="desc_text">{editAssetData?.userId}</div> </label>
            </div>
            <div className="form-group">
              <label htmlFor="confirm-password">Owner Email: <div className="desc_text">{editAssetData?.email}</div> </label>
            </div>
            <div className="form-container" style={{ display: 'flex', flexWrap: 'wrap', gap: '20px' }}>
            <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <label htmlFor="bitlocker-status">BitLocker Status:</label>
              <Switch onColor={"#2f215e"} checked={assetDetails.bitlockerStatus} disabled />
            </div>
            <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <label htmlFor="vdi-installed">VDI Installed:</label>
              <Switch onColor={"#2f215e"} checked={assetDetails.vdiInstalled} disabled />
            </div>
            <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <label htmlFor="cpa-issue">VDI(CPA) Working:</label>
              <Switch onColor={"#2f215e"} checked={assetDetails.cpaIssue} disabled />
            </div>
           
            <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <label htmlFor="zscaler-working">ZScaler Working:</label>
              <Switch onColor={"#2f215e"} checked={assetDetails.zscalerWorking} disabled />
            </div>
            <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <label htmlFor="duo-working">Duo Working:</label>
              <Switch onColor={"#2f215e"} checked={assetDetails.duoWorking} disabled />
            </div>
           
            <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <label htmlFor="gws-issue">GWS Issue:</label>
              <Switch onColor={"#2f215e"} checked={assetDetails.gwsIssue} disabled />
            </div>
            <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <label htmlFor="admin-login">Admin Login:</label>
              <Switch onColor={"#2f215e"} checked={assetDetails.adminLogin} disabled />
            </div>  
          </div>

            <button onClick={() => {
              closeModal(false);
            }} >
              Close
            </button>
          </div>
        </div>
      </OutsideClickHandler>
    </div>
  );
}


export default ViewAssetModal;
