import { useCookies } from "react-cookie";
import "./modal.css";
import OutsideClickHandler from "react-outside-click-handler";
import axios from "axios";
import { useContext, useEffect, useState } from "react";
import Select from "react-dropdown-select";
import { errortoast, successtoast } from "../ExtraExports/Exports";
import Switch from "react-switch";
import { BatchContext } from "../context/BatchContext";
import { MdEdit } from "react-icons/md";


function EditAssetModal({ closeModal, modalfun, editAssetData, setshownewTaggedAsset }) {
  const { batchName, setBatchName, role, setrole, refresh, setrefresh } = useContext(BatchContext)
  const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL;
  const [cookies, setcookie, removecookie] = useCookies(["jwttoken"]);
  const [manufacturerList, setmanufacturerList] = useState([])
  const [locationList, setlocationList] = useState([])
  const [categoryList, setcategoryList] = useState([])
  const [categoryId, setcategoryId] = useState({})
  const [issueList, setissueList] = useState([])
  const [myRole, setmyRole] = useState(role);
  const [assetDetails, setassetDetails] = useState({
    "assetId": editAssetData?.assetId,
    "mid": editAssetData?.mid,
    "bitlockerStatus": editAssetData?.bitlockerStatus,
    "vdiInstalled": editAssetData?.vdiInstalled,
    "vdiWorking": editAssetData?.vdiWorking,
    "locId": editAssetData?.locId,
    "zscalerWorking": editAssetData?.zscalerWorking,
    "duoWorking": editAssetData?.duoWorking,
    "cpaIssue": editAssetData?.cpaIssue,
    "gwsIssue": editAssetData?.gwsIssue,
    "adminLogin": editAssetData?.adminLogin
  })
  const getManufacturerOptions = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/asset/getManufacturerOptions`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setmanufacturerList(response.data)
      })
      .catch((error) => {
      });
  }
  useEffect(() => {
    setmyRole(role)
  }, [role])

  const getLocationOptions = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/asset/getLocationOptions`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setlocationList(response.data)
      })
      .catch((error) => {
      });
  }
  const getAllCategory = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/assetissue/getAllCategory`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setcategoryList(response.data)
      })
      .catch((error) => {
      });
  }
  const getAllIssues = () => {
    if (categoryId.value) {
      axios({
        url: `${REACT_APP_BASE_URL}/assetissue/getIssueByCategoryId/${categoryId?.value}`,
        headers: { Authorization: `Bearer ${cookies.jwttoken}` },
        method: "GET",
      })
        .then((response) => {
          setissueList(response.data)
        })
        .catch((error) => {
        });
    }
  }

  useEffect(() => {
    getLocationOptions()
    getManufacturerOptions()
    getAllCategory()
  }, [])


  useEffect(() => {
    console.log(categoryId);
    getAllIssues()
  }, [categoryId])

  const updateAsset = () => {
    if (assetDetails.assetId.length != 11
      || assetDetails.locId == null
      || assetDetails.mid == null
    ) {
      errortoast("Please Fill All The Field")
      return;
    }
    console.log(assetDetails);
    axios({
      url: `${REACT_APP_BASE_URL}/asset/update/${editAssetData?.aaId}`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "PUT",
      data: assetDetails
    })
      .then((response) => {
        successtoast("Issue Updated Succesfully")
        modalfun()
        closeModal(false)

      })
      .catch((error) => {
        errortoast("Error While Updating Issue")
      });
  }

  return (
    <div className="createprojectmodalouter">
      <OutsideClickHandler
        onOutsideClick={() => {
          closeModal(false);
        }}
      >
        <div className="card scale-up-center-anmiation" style={{ width: "450px" }}>
          <div className="card-header">
            <div className="text-header">Update Asset Details</div>
          </div>
          <div className="card-body">
            <div className="form-group" style={{ position: "relative" }}>
              <label htmlFor="username">Asset Id: *</label>
              <input minLength={10} maxLength={11} type="text"
                value={assetDetails?.assetId}
                disabled
                onChange={(e) => { setassetDetails({ ...assetDetails, assetId: e.target.value }); }
                }>
              </input>
              {myRole == "TRAINEE" &&
                <span className='editbutton' onClick={() => { setshownewTaggedAsset(true); closeModal(false) }}>
                  <MdEdit size={"1.4rem"} />
                </span>
              }
            </div>
            <div className="form-group">
              <label htmlFor="email">Select Manufacturer: *</label>
              <Select
                style={{
                  borderRadius: "9px",
                  height: "40px",
                  paddingLeft: "15px",
                }}
                values={manufacturerList?.filter((data) => data.value == editAssetData?.mid) || [{ value: 1, label: "Loading Value" }]}
                options={manufacturerList}
                searchable={false}
                onChange={(e) => { setassetDetails({ ...assetDetails, mid: e[0].value }) }}
              ></Select>
            </div>
            <div className="form-container" style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '20px' }}>
              <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <label htmlFor="bitlocker-status">BitLocker Status:</label>
                <Switch
                  onColor={"#2f215e"}
                  onChange={(checked) => setassetDetails({ ...assetDetails, bitlockerStatus: checked })}
                  checked={assetDetails.bitlockerStatus}
                />
              </div>
              <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <label htmlFor="vdi-installed">VDI Installed:</label>
                <Switch
                  onColor={"#2f215e"}
                  onChange={(checked) => setassetDetails({ ...assetDetails, vdiInstalled: checked })}
                  checked={assetDetails.vdiInstalled}
                />
              </div>
              <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <label htmlFor="cpa-issue">VDI(CPA) Working:</label>
                <Switch
                  onColor={"#2f215e"}
                  onChange={(checked) => setassetDetails({ ...assetDetails, cpaIssue: checked })}
                  checked={assetDetails.cpaIssue}
                />
              </div>
             
              <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <label htmlFor="zscaler-working">ZScaler Working:</label>
                <Switch
                  onColor={"#2f215e"}
                  onChange={(checked) => setassetDetails({ ...assetDetails, zscalerWorking: checked })}
                  checked={assetDetails.zscalerWorking}
                />
              </div>
              <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <label htmlFor="duo-working">Duo Working:</label>
                <Switch
                  onColor={"#2f215e"}
                  onChange={(checked) => setassetDetails({ ...assetDetails, duoWorking: checked })}
                  checked={assetDetails.duoWorking}
                />
              </div>
             
              <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <label htmlFor="gws-issue">GWS Issue:</label>
                <Switch
                  onColor={"#2f215e"}
                  onChange={(checked) => setassetDetails({ ...assetDetails, gwsIssue: checked })}
                  checked={assetDetails.gwsIssue}
                />
              </div>
              <div className="form-group" style={{ flex: '1 1 calc(50% - 20px)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <label htmlFor="admin-login">Admin Login:</label>
                <Switch
                  onColor={"#2f215e"}
                  onChange={(checked) => setassetDetails({ ...assetDetails, adminLogin: checked })}
                  checked={assetDetails.adminLogin}
                />
              </div>
            </div>
            <button onClick={updateAsset} >
              Update
            </button>
          </div>
        </div>
      </OutsideClickHandler>
    </div>
  );
}


export default EditAssetModal;
