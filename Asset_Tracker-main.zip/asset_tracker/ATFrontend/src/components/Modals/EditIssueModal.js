import { useCookies } from "react-cookie";
import "./modal.css";
import OutsideClickHandler from "react-outside-click-handler";
import axios from "axios";
import { useEffect, useState } from "react";
import Select from "react-dropdown-select";
import { errortoast, successtoast } from "../ExtraExports/Exports";


function EditIssueModal({ closeModal, modalfun, editIssueData }) {
  const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL;
  const [cookies, setcookie, removecookie] = useCookies(["jwttoken"]);
  const [assetList, setassetList] = useState([])
  const [categoryList, setcategoryList] = useState([])
  const [categoryId, setcategoryId] = useState({})
  const [issueList, setissueList] = useState([])
  const [statusList, setstatusList] = useState([])
  const [addIssueDetails, setaddIssueDetails] = useState({
    "aaId": editIssueData?.aaId,
    "issueId": editIssueData?.issueId,
    "issueComment": editIssueData?.issueComment,
    "ticketNumber": editIssueData?.ticketNumber,
    "idmReply": editIssueData?.idmReply,
    "categoryId": editIssueData?.categoryId,
    "statusId": editIssueData?.statusId,
    "assetId": editIssueData?.assetId,
    "idmEmpId": editIssueData?.idmEmpId,
    "idmName": editIssueData?.idmName,
    "userSolution":editIssueData?.userSolution
  })

  useEffect(() => {
    console.log(editIssueData?.mappingId);
  }, [])

  const handleticketChange = (e) => {
    const newValue = e.target.value;
    if (/^\d*$/.test(newValue) && newValue.length <= 10) {
      setaddIssueDetails({ ...addIssueDetails, ticketNumber: newValue });
    }
  };


  const getUserAssets = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/asset/getAssetUserOption`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setassetList(response.data)
      })
      .catch((error) => {
      });
  }
  const getAllCategory = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/assetissue/getAllCategory`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setcategoryList(response.data)
      })
      .catch((error) => {
      });
  }
  const getAllStatus = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/assetissue/getAllStatus`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setstatusList(response.data)
      })
      .catch((error) => {
      });
  }
  const getAllIssues = () => {
    if (!addIssueDetails?.categoryId) {
      return;
    } else if (addIssueDetails?.categoryId) {
      console.log(addIssueDetails?.categoryId);
      axios({
        url: `${REACT_APP_BASE_URL}/assetissue/getIssueByCategoryId/${addIssueDetails?.categoryId}`,
        headers: { Authorization: `Bearer ${cookies.jwttoken}` },
        method: "GET",
      })
        .then((response) => {
          setissueList(response.data)
        })
        .catch((error) => {
        });
    }
  }

  useEffect(() => {
    getAllStatus()
    getUserAssets()
    getAllCategory()
  }, [])


  useEffect(() => {
    getAllIssues()
  }, [addIssueDetails?.categoryId])

  const updateIssue = () => {
    if (addIssueDetails.aaId == null ||
      addIssueDetails.issueId == null ||
      addIssueDetails.issueComment == "" ||
      categoryId == {} ||
      (addIssueDetails?.statusId==2 && !addIssueDetails?.userSolution)
    ) {
      errortoast("Please Fill All The Field")
      return;
    }
    console.log(addIssueDetails);
    axios({
      url: `${REACT_APP_BASE_URL}/assetissue/updaetAssetIssue/${parseInt(editIssueData?.mappingId)}`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "PATCH",
      data: addIssueDetails
    })
      .then((response) => {
        successtoast("Issue Updated Succesfully")
        modalfun()
        closeModal(false)

      })
      .catch((error) => {
        errortoast("Error While Updating Issue")
      });
  }
  return (
    <div className="createprojectmodalouter">
      <OutsideClickHandler
        onOutsideClick={() => {
          closeModal(false);
        }}
      >
        <div className="card scale-up-center-anmiation" style={{width:'450px'}}>
          <div className="card-header">
            <div className="text-header">Update Issue Details</div>
          </div>
          <div className="card-body">
            <div className="form-group">
              <label htmlFor="username">Select Asset: *</label>
              <input type="text" value={addIssueDetails.assetId} disabled></input>
            </div>

            <div className="form-group">
              <label htmlFor="email">Select Category: *</label>
              <Select
                style={{
                  borderRadius: "9px",
                  height: "40px",
                  paddingLeft: "15px",
                }}
                values={categoryList?.filter((data) => data.value == editIssueData?.categoryId) || [{ value: 1, label: "Loading Value" }]}
                options={categoryList}
                searchable={false}
                onChange={(e) => { setaddIssueDetails({ ...addIssueDetails, categoryId: e[0]?.value }); }}
              ></Select>
            </div>

            <div className="form-group">
              <label htmlFor="confirm-password">Select Issue: *</label>
              <Select
                style={{
                  borderRadius: "9px",
                  height: "40px",
                  paddingLeft: "15px",
                }}
                values={issueList?.filter((data) => data.value == editIssueData?.issueId) || [{ value: 1, label: "Loading Value" }]}
                options={issueList}
                searchable={false}
                onChange={(e) => { setaddIssueDetails({ ...addIssueDetails, issueId: e[0]?.value || {} }); }}
              ></Select>
            </div>
            <div className="form_div_shrinkable">
              <div className="form-group">
                <label htmlFor="confirm-password">Ticket Number:</label>
                <input type="text"
                  minLength={6}
                  maxLength={10}
                  onChange={handleticketChange}
                  value={addIssueDetails?.ticketNumber}
                ></input>
              </div>
              <div className="form-group"
              style={{
                "display": "flex",
                "flexDirection": "column",
                "flexGrow": 1,
                paddingLeft:"20px"
              }}
              >
                <label htmlFor="confirm-password">Status: </label>
                <Select
                  style={{
                    borderRadius: "9px",
                    height: "40px",
                    paddingLeft: "15px",
                  }}
                  values={statusList?.filter((data) => data.value == editIssueData?.statusId) || [{ value: 1, label: "Loading Value" }]}
                  options={statusList}
                  searchable={false}
                  onChange={(e) => setaddIssueDetails({ ...addIssueDetails, statusId: e[0].value })}
                ></Select>
              </div>
            </div>


            <div className="form_div_shrinkable">
              <div className="form-group">
                <label htmlFor="confirm-password">IDM EMP:</label>
                <input type="text"
                  min={6}
                  maxLength={10}
                  value={addIssueDetails.idmEmpId}
                  onChange={(e) => setaddIssueDetails({ ...addIssueDetails, idmEmpId: parseInt(e.target.value) })}
                ></input>
              </div>
              <div className="form-group">
                <label htmlFor="confirm-password">IDM Name:</label>
                <input type="text"
                  maxLength={20}
                  value={addIssueDetails?.idmName}
                  onChange={(e) => setaddIssueDetails({ ...addIssueDetails, idmName: e.target.value })}

                ></input>
              </div>
            </div>


            <div className="form-group">
              <label htmlFor="confirm-password">IDM Reply:</label>
              <textarea maxLength={100}
                onChange={(e) => setaddIssueDetails({ ...addIssueDetails, idmReply: e.target.value })}
                value={addIssueDetails?.idmReply}
              ></textarea>
            </div>
            {addIssueDetails?.statusId==2&&
            <div className="form-group">
              <label htmlFor="confirm-password">Solution Of This Issue: *</label>
              <textarea maxLength={100}
                onChange={(e) => setaddIssueDetails({ ...addIssueDetails, userSolution: e.target.value })}
                value={addIssueDetails?.userSolution}
              ></textarea>
            </div>
            }
            <div className="form-group">
              <label htmlFor="confirm-password">Issue Details: *</label>
              <textarea maxLength={100}
                onChange={(e) => setaddIssueDetails({ ...addIssueDetails, issueComment: e.target.value })}
                value={addIssueDetails?.issueComment}
              ></textarea>
            </div>

            <button onClick={updateIssue} >
              Update Issue
            </button>
          </div>
        </div>
      </OutsideClickHandler>
    </div>
  );
}


export default EditIssueModal;
