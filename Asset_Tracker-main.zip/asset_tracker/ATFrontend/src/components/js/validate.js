
  const checkDuplicateEmail = (email) => {
    let seen = [], dupl = [];
    rows.filter(user => {
      if (seen.includes(user.email)) {
        dupl.push(user.email)
        return true
      }
      seen.push(user.email)
      return false
    })
    return dupl.includes(email)
  }
  const checkDuplicateId = (empId) => {
    let seen = [], dupl = [];
    let res = rows.filter(user => {
      if (seen.includes(user.empId)) {
        dupl.push(user.empId)
        return true
      }
      seen.push(user.empId)
      return false
    })
    return dupl.includes(empId)
  }
  const validateEmail = (email) => {
    const emailPattern = /^[a-zA-Z0-9._%+-]+@tcs.com/;
    return emailPattern.test(email)
  };
  const validatePW = (password) => {
    const psPattern = /^(?=.*\d)(?=.*[a-z]).{6,}$/;
    return psPattern.test(password)
  }
  const validateId = (id) => {
    const idPattern = /^[0-9]{6,8}$/;
    return idPattern.test(id)
  }
  const validateBatch = (batch) => {
    const batchPattern = /^[A-Z][0-9]{2,3}$/;
    return batchPattern.test(batch)
  }
  const EmailCell = ({ email }) => {
    return validateEmail(email) && !checkDuplicateEmail(email) ?
      <div style={{ backgroundColor: "", height: "100%", width: "100%" }}>{email}</div> :
      <div data-tooltip-id="email_not_valid"
        data-tooltip-content="Invalid email"
        data-tooltip-place="top"
        style={{ textDecoration: 'underline', color: 'red', height: "100%", width: "100%" }}>
        <Tooltip id="email_not_valid" delayShow={200}
          style={{ backgroundColor: 'grey', color: "white", border: '0' }} />{email}</div>
  }
  const EmailCell2 = ({ email }) => {
    return <div data-tooltip-id="email_not_valid2"
      data-tooltip-content="Duplicate Data"
      data-tooltip-place="top"
      style={{ textDecoration: 'underline', color: 'red', height: "100%", width: "100%" }}>
      <Tooltip id="email_not_valid2" />{email}</div>
  }
  const IdCell = ({ id }) => {
    return validateId(id) && !checkDuplicateId(id) ?
      <div style={{ height: "100%", width: "100%" }}>
        <Tooltip id="id_not_valid" />{id}</div>
      : <div data-tooltip-id="id_not_valid"
        data-tooltip-content="Invalid Id"
        style={{ textDecoration: 'underline', color: 'red', height: "100%", width: "100%" }}>
        <Tooltip id="id_not_valid" />{id}</div>
  }
  const IdCell2 = ({ id }) => {
    return <div data-tooltip-id="id_not_valid2"
      data-tooltip-content="Duplicate Data"
      data-tooltip-place="top"
      style={{ textDecoration: 'underline', color: 'red', height: "100%", width: "100%" }}>
      <Tooltip id="id_not_valid2" />{id}</div>
  }


  const PasswordCell = ({ password }) => {
    return validatePW(password) ?
      <div style={{ backgroundColor: "", height: "100%", width: "100%" }}>
        <Tooltip class="tooltip swing" id="pw_not_valid" />{password}</div>
      :
      <div data-tooltip-id="pw_not_valid"
        data-tooltip-content="Password is not Strong"
        style={{ textDecoration: 'underline', color: 'red', height: "100%", width: "100%" }}>
        <Tooltip id="pw_not_valid" />{password}</div>
  }


  const checkAllValid = () => {
    let allvalid = rows.filter((user) => {

      return !validateEmail(user.email) || !validatePW(user.password)
        || !validateId(user.empId) || checkDuplicateEmail(user.email)
        || checkDuplicateId(user.empId)
    })
    setisValid(allvalid.length === 0)
  }
