import React, { useContext, useEffect, useState } from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import PropTypes from "prop-types";
import { IoMdAdd, IoMdCloudUpload } from "react-icons/io";
import { MdEdit, MdCancel } from "react-icons/md";
import { GrPowerReset } from "react-icons/gr";
import { FaPlus, FaSave } from "react-icons/fa";
import { HashLoader } from "react-spinners";
import { JsonToExcel, exportToExcel } from "react-json-to-excel";
import {
  GridRowModes,
  DataGrid,
  GridToolbarContainer,
  GridActionsCellItem,
  GridRowEditStopReasons,
} from "@mui/x-data-grid";
import { randomId } from "@mui/x-data-grid-generator";
import axios from "axios";
import { useCookies } from "react-cookie";
import { errortoast, successtoast } from "./ExtraExports/Exports";
import "./ManageUser.css";
import { BatchContext } from "./context/BatchContext";
import { Tooltip } from "react-tooltip";
import { NavLink } from "react-router-dom";
import { ImUpload2 } from "react-icons/im";
import { colors } from "@mui/material";

function EditToolbar(props) {

  const { setRows, setRowModesModel } = props;
  const handleClick = () => {
    const id = randomId();
    setRows((oldRows) => [
      ...oldRows,
      { id, name: "", email: "", isNew: true },
    ]);
    setRowModesModel((oldModel) => ({
      ...oldModel,
      [id]: { mode: GridRowModes.Edit, fieldToFocus: "name" },
    }));

  };

  return (
    <GridToolbarContainer>

      <button style={{ display: 'flex', alignItems: "center", justifyContent: "center" }} onClick={handleClick}>
        <FaPlus />&nbsp;
        Add Users
      </button>
      <NavLink
        end
        to="../dataupload"
      >
        <button style={{ display: 'flex', alignItems: "center", justifyContent: "center" }} >
          <IoMdCloudUpload size={"1.4rem"} />&nbsp;
          Add Bulk Users
        </button>
      </NavLink>
      <NavLink
        end
        to="../batchdataup"
      >
        <button style={{ display: 'flex', alignItems: "center", justifyContent: "center" }} >
          <ImUpload2 size={"1.2rem"} />&nbsp;
          Permanent Batching
        </button>
      </NavLink>

    </GridToolbarContainer>

  );
}

function ManageUser() {
  const { batchName, setBatchName,refresh,setrefresh } = useContext(BatchContext);
  const [isValid, setisValid] = useState(true)
  // const [batchName, setbatchName] = useState("39");
  const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL;

  const [rows, setRows] = React.useState([]);
  const [rowModesModel, setRowModesModel] = useState({});
  const [loading, setloading] = useState(true);
  const [excelExportData, setexcelExportData] = useState([]);


  const getAllUsers = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/user/getAllUsers/${batchName?.label}`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setloading(false)
        setRows((initialData) =>
          response?.data?.map((data) => ({
            id: data.id,
            name: data.name,
            email: data.email,
            empId: data.empId,
            mainBatch: data.mainBatch,
            tempBatch: data.tempBatch,
            batch: data.batch,
            asset: data.asset ? "Yes" : "No"
          }))
        );
      })
      .catch((error) => {
        setloading(false)
        console.log(error);
      });
  };
  useEffect(() => {
    let temp = rows;
    temp = temp.map((mydata) => {
      let tempJson = {};
      tempJson["Name"]=mydata.name;
      tempJson["Employee Id"]=mydata.empId;
      tempJson["Email"] = mydata.email;
      tempJson["Temporary Batch"]=mydata.tempBatch;
      tempJson["Permanent Batch"]=mydata.batch;
      tempJson["Main Batch"]=mydata.mainBatch;
      tempJson["Asset Registered"]=mydata.asset;
      return tempJson; 
    });
    setexcelExportData(temp);
  }, [rows]);

 

  useEffect(() => {
    setloading(true)
    getAllUsers();
    checkAllValid();
  }, [batchName,refresh]);

  const updateUserData = (userData) => {
    axios({
      url: `${REACT_APP_BASE_URL}/admin/addUpdateUser`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "POST",
      data: userData.isNew
        ? { ...userData, id: 0 }
        : { ...userData, isNew: false },
    })
      .then((response) => {
        getAllUsers();
        if (response.data == 1) {
          errortoast("You Cannot Update Your Own Details");
        } else if (response.data == 2) {
          successtoast("User Data Updated Successfully");
        } else if (response.data == 3) {
          successtoast("New User Added Successfully");
        } else if (response.data == 4) {
          errortoast("Pleas Add Valid Data");
        }
      })
      .catch((error) => {
        errortoast("Pleas Add Valid Data");
      });
  };

  const handleRowEditStop = (params, event) => {
    if (params.reason === GridRowEditStopReasons.rowFocusOut) {
      event.defaultMuiPrevented = true;
    }
  };

  const handleEditClick = (id) => () => {
    setRowModesModel({ ...rowModesModel, [id]: { mode: GridRowModes.Edit } });
  };

  const handleSaveClick = (id) => () => {
    setRowModesModel({ ...rowModesModel, [id]: { mode: GridRowModes.View } });
  };

  const handlePasswordReset = (id) => () => {
    axios({
      url: `${REACT_APP_BASE_URL}/admin/resetPassword/${id}`,
      headers: { Authorization: `Bearer ${cookies.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        if (response.data) {
          successtoast("Password Reseted Successfully");
        } else {
          errortoast("Something Went Wrong");
        }
      })
      .catch((error) => {
        errortoast("Something Went Wrong");
      });
  };

  const handleCancelClick = (id) => () => {
    setRowModesModel({
      ...rowModesModel,
      [id]: { mode: GridRowModes.View, ignoreModifications: true },
    });

    const editedRow = rows.find((row) => row.id === id);
    if (editedRow.isNew) {
      setRows(rows.filter((row) => row.id !== id));
    }
  };

  const processRowUpdate = (newRow) => {
    console.log(newRow);
    updateUserData(newRow);
    const updatedRow = { ...newRow, isNew: false };
    setRows(rows.map((row) => (row.id === newRow.id ? updatedRow : row)));
    checkAllValid();
    return updatedRow;

  };

  const handleRowModesModelChange = (newRowModesModel) => {
    setRowModesModel(newRowModesModel);
    checkAllValid();
  };
  const checkDuplicateId = (empId) => {
    let seen = [], dupl = [];
    rows.filter(user => {
      if (seen.includes(user.empId)) {
        dupl.push(user.empId)
        return true
      }
      seen.push(user.empId)
      return false
    })
    return dupl.includes(empId)
  }
  const validateId = (id) => {
    const idPattern = /^[0-9]{6,8}$/;
    return idPattern.test(id)
  }
  const IdCell = ({ id }) => {
    return validateId(id) && !checkDuplicateId(id) ?
      <div style={{ height: "100%", width: "100%" }}><Tooltip id="id_not_valid" />{id}</div>
      : <div data-tooltip-id="id_not_valid" data-tooltip-content="Invalid Id"
        style={{ backgroundColor: "#f1c84e", height: "100%", width: "100%" }}><Tooltip id="id_not_valid" />{id}</div>
  }
  const IdCell2 = ({ id }) => {
    return <div data-tooltip-id="id_not_valid2" data-tooltip-content="Duplicate Id" data-tooltip-place="top"
      style={{ backgroundColor: "#f8e4d5", height: "100%", width: "100%" }}> <Tooltip id="id_not_valid2" />{id}</div>
  }
  const checkAllValid = () => {
    let allvalid = rows.filter((user) => {

      return !validateId(user.empId) || checkDuplicateId(user.empId)
    })
    setisValid(allvalid.length === 0)
  }

  const columns = [
    { field: "name", headerName: "Name", flex: 1, editable: true, headerClassName: 'boldHeader' },
    {
      field: "empId", headerName: "Employee Id", flex: 1, editable: true,
      renderCell: (params) => !checkDuplicateId(params.value) ?
        <IdCell id={params.value} /> : <IdCell2 id={params.value} />
    },
    {
      field: "email",
      headerName: "Email",
      flex: 1,
      align: "left",
      headerAlign: "left",
      editable: true,
    },

    {
      field: "mainBatch",
      headerName: "Main Batch",
      flex: 1,
      editable: true,
      type: "singleSelect",
      valueOptions: [`${batchName?.label}`],
    },
    {
      field: "tempBatch",
      headerName: "Temp Batch",
      flex: 1,
      editable: true,
    },
    {
      field: "batch",
      headerName: "Permanent Batch",
      flex: 1,
      editable: true,
    },
    {
      field: "asset",
      headerName: "Asset Registered",
      flex: 1,
      editable: false,
    },
    {
      field: "actions",
      type: "actions",
      headerName: "Actions",
      flex: 1,
      cellClassName: "actions",
      getActions: ({ id }) => {
        const isInEditMode = rowModesModel[id]?.mode === GridRowModes.Edit;

        if (isInEditMode) {
          return [
            <GridActionsCellItem
              // disabled={!isValid}
              key={id}
              icon={<FaSave size={"1.2rem"} />}
              label="Save"
              sx={{
                color: "#2f215e",
                borderRadius: "8px",
                background: "#fefdfe",
                fontWeight: "bold",
              }}
              onClick={handleSaveClick(id)}
            />,
            <GridActionsCellItem
              key={id}
              icon={<MdCancel size={"1.3rem"} />}
              label="Cancel"
              className="textPrimary"
              onClick={handleCancelClick(id)}
              sx={{
                color: "#2f215e",
                borderRadius: "8px",
                background: "#fefdfe",
                fontWeight: "bold",
              }}
            />,
          ];
        }

        return [
          <><Tooltip style={{ background: " #20c38d" }} className="tooltip swing" id="edit_data" />
            <GridActionsCellItem
              data-tooltip-id="edit_data"
              data-tooltip-delay-show={1600}
              data-tooltip-content="Edit"
              data-tooltip-place="left-start"
              key={id}
              icon={<MdEdit size={"1.3rem"} />}
              label="Edit"
              className="textPrimary"
              onClick={handleEditClick(id)}
              sx={{
                color: "#2f215e",
                borderRadius: "8px",
                background: "#fefdfe",
                fontWeight: "bold",
              }}

            /></>,
          <><Tooltip style={{ background: " #20c38d" }} className="tooltip fade" id="reset_password" />
            <GridActionsCellItem
              data-tooltip-id="reset_password"
              data-tooltip-delay-show={1600}
              data-tooltip-content="Reset Password"
              data-tooltip-place="left-start"
              key={id}
              icon={<GrPowerReset size={"1.3rem"} />}
              label="Reset Password"
              onClick={handlePasswordReset(id)}
              sx={{
                color: "#2f215e",
                borderRadius: "8px",
                background: "#fefdfe",
                fontWeight: "bold",
                label: "Reset Password",
              }}
            /></>,
        ];
      },
    },
  ];
  const [cookies] = useCookies();
  const REACT_APP_BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

  return (
    <>

      <Box
        sx={{
          mx: "auto",
          height: "100%",
          width: "100%",
          "& .actions": {},
          "& .textPrimary": {},
          fontWeight: "bold",
          border: "none !important"
        }}
      >

        {loading ?
          <div className="loaderdiv">
            <HashLoader color={"#2f215e"} size={"60"} ></HashLoader>
          </div>
          :
          <DataGrid
            rows={rows}
            columns={columns}
            editMode="row"
            rowModesModel={rowModesModel}
            onRowModesModelChange={handleRowModesModelChange}
            onRowEditStop={handleRowEditStop}
            processRowUpdate={processRowUpdate}
            sx={{
              padding: "8px",
              borderRadius: "10px",
              maxHeight: "90%",
              border: "1px solid #2f215e",
              backgroundColor: "#ffffffab",
              color: "#2f215e"
            }}
            slots={{
              toolbar: EditToolbar,
            }}
            slotProps={{
              toolbar: { setRows, setRowModesModel },
            }}
            componentsProps={{
              columnHeader: {
                style: { fontWeight: 'bold' },
              },
            }}
          />
        }
      </Box>
      <JsonToExcel
        styleSheet={{ color: "black" }}
        title="Download"
        data={excelExportData}
        fileName="UsersData"
        btnClassName='btn'
        btnColor='#fefdfe'
      />


    </>

  );
}
EditToolbar.propTypes = {
  setRows: PropTypes.func.isRequired,
  setRowModesModel: PropTypes.func.isRequired,
};

export default ManageUser;
