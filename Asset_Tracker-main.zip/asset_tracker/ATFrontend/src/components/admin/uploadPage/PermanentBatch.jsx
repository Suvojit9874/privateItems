import { useEffect, useState } from "react";
import "./UploadPage.css";
import "../../../App.css"
import { MdCloudUpload, MdDelete } from "react-icons/md";
import { FaFileCsv } from "react-icons/fa6";
import { Box, Typography } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
// import validator from 'validator';
// import Papa from 'papaparse';
import { BsFiletypeXlsx } from "react-icons/bs";
import { Tooltip } from 'react-tooltip'
import { errortoast, successtoast } from "../../ExtraExports/Exports";
import axios from "axios";
import * as xlsx from 'xlsx'
import { useCookies } from "react-cookie";
import { useNavigate } from "react-router-dom";
import { ImUpload2 } from "react-icons/im";
function PemanentBatch() {
  const [Cookie, setCookie] = useCookies();
  const [file, setFile] = useState(null);
  const [fileName, setFileName] = useState("No selected file");
  const [rows, setRows] = useState([]);
  const [isValid, setisValid] = useState(true)
  const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL
  const navigate = useNavigate()
  useEffect(() => {
    if (rows != []) { checkAllValid() }
  }, rows[1])
  useEffect(() => {

    console.log(REACT_APP_BASE_URL);
  }, [])

  const checkDuplicateId = (empId) => {
    let seen = [], dupl = [];
    let res = rows.filter(user => {
      if (seen.includes(user.empId)) {
        dupl.push(user.empId)
        return true
      }
      seen.push(user.empId)
      return false
    })
    return dupl.includes(empId)
  }

  const validateId = (id) => {
    const idPattern = /^[0-9]{6,7}$/;
    return idPattern.test(id)
  }

  const IdCell = ({ id }) => {
    return validateId(id) && !checkDuplicateId(id) ?
      <div style={{ height: "100%", width: "100%" }}>
        <Tooltip id="id_not_valid" />{id}</div>
      : <div data-tooltip-id="id_not_valid"
        data-tooltip-content="Invalid Id"
        style={{ textDecoration: 'underline', color: 'red', height: "100%", width: "100%" }}>
        <Tooltip id="id_not_valid" />{id}</div>
  }
  const IdCell2 = ({ id }) => {
    return <div data-tooltip-id="id_not_valid2"
      data-tooltip-content="Duplicate Data"
      data-tooltip-place="top"
      style={{ textDecoration: 'underline', color: 'red', height: "100%", width: "100%" }}>
      <Tooltip id="id_not_valid2" />{id}</div>
  }




  const checkAllValid = () => {
    let allvalid = rows.filter((user) => {

      return !validateId(user.empId)
        || checkDuplicateId(user.empId)
    })
    return setisValid(allvalid.length == 0)
  }

  useEffect(() => {

    checkAllValid()
  }, [rows])

  // Submit of bulk data handled pemanentBatch
  const handleClick = () => {
    if (isValid) {
      checkAllValid()
      axios({
        url: `${REACT_APP_BASE_URL}/admin/permanentBulkUpload`,
        method: "POST",
        data: rows,
        headers: {
          "Authorization": `Bearer ${Cookie.jwttoken}`
        }
      })
        .then((response) => {
          setRows([])
          setFile(null)

          setFileName("No selected file")
          successtoast("Data Uploaded Successfully")
          // navigate('/Home/users')
        })
        .catch((error) => {
          errortoast("Can't have duplicate entry");
        });
    }
    else {
      errortoast("Data is invalid");
    }
  }
  const handleProcessRowUpdate = (updatedRow, originalRow) => {
    const newRows = [...rows];
    const idx = newRows.findIndex((row) => row.id === originalRow.id);
    newRows[idx] = updatedRow;
    setRows(newRows);
    checkAllValid()
    return updatedRow;
  };
  function validateJSONFields(jsonArray) {
    const requiredFields = ["id", "empId", "batch", "mainBatch"];
    let out = false;
    jsonArray.forEach((obj, index) => {
      const keys = Object.keys(obj);

      requiredFields.forEach(field => {
        if (!keys.includes(field)) {
          out = true;

        }
      });

      keys.forEach(key => {
        if (!requiredFields.includes(key)) {
          out = true;

        }
      });
    });
    return out;
  }
  const columns = [
    {
      field: "empId", headerName: "EmpId", width: 180, editable: true,
      renderCell: (params) => !checkDuplicateId(params.value) ?
        <IdCell id={params.value} /> : <IdCell2 id={params.value} />
    },
    { field: "batch", headerName: "Batch", width: 180, editable: true },
    { field: "mainBatch", headerName: "Main Batch", width: 200, editable: true },
  ];

  return (
    <>
      {rows == "" ? (
        <div className="uploadparent">
          <div className="uploadcenterdiv">
            <div className="page">
              <form className="uploaduserform" onClick={() => {
                document.querySelector(".input-field").click()
              }}>
                <input type="file" accept=".xls,.xlsx" className="input-field" hidden
                  onChange={
                    ({ target: { files } }) => {
                      files[0] && setFileName(files[0].name);
                      if (files) {
                        setFile(URL.createObjectURL(files[0]));
                      }
                      const file = files[0];
                      const fileType =
                        file.name.split('.').pop().toLowerCase();
                      if (fileType !== 'xlsx') {
                        alert('Please upload a xlsx file.');
                        return;
                      }
                      else {
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = (e) => {
                            const data = e.target.result;
                            const workbook = xlsx.read(data, { type: "array" });
                            const sheetName = workbook.SheetNames[0];
                            const worksheet = workbook.Sheets[sheetName];
                            const json = xlsx.utils.sheet_to_json(worksheet);
                            console.log(json);
                            let out = validateJSONFields(json);
                            if (out) {
                              errortoast("Please Provide Valid Data")
                              setRows([])
                              setFile(null)
                              setFileName("No selected file")
                            } else {
                              successtoast("Data read successfully")
                              setRows(json)

                            }
                          };
                          reader.readAsArrayBuffer(file);
                        }
                      }

                      // Papa.parse(file, {
                      //   complete: (result) => {
                      //     let out = validateJSONFields(result.data);
                      //     if (out) {
                      //       errortoast("Please Provide Valid Data")
                      //       setRows([])
                      //       setFile(null)
                      //       setFileName("No selected file")
                      //     } else {
                      //       successtoast("Data read successfully")
                      //       setRows(result.data)

                      //     }
                      //   },
                      //   header: true,
                      // });
                    }
                  }
                />
                <div className="uploadpage1"></div>
                {file ? (
                  <>
                    <h3>File uploaded</h3>
                  </>
                ) : (
                  <>
                    <ImUpload2 color="#2f215e" size={50} />&nbsp;
                    <p>Permanent Batch Data Upload</p>
                  </>
                )}
              </form>
            </div>
            <section className="uploaded-row">
              {/* <AiFillFileImage color='#20c38d' /> */}
              <span className="upload-content">
                {fileName} -
                <MdDelete
                  color="#2f215e"
                  onClick={() => {
                    setFileName("No selected File");
                    setFile(null);
                  }}
                />
              </span>
            </section>
            Click this for sample data  &nbsp;
            <a href={'/permanentBatchSampleData.xlsx'} download="permanentBatchSampleData.xlsx">
              <Tooltip class="tooltip swing" id="sample_csv" />
              <button data-tooltip-id="sample_csv"
                data-tooltip-content="Download sample xlsx"
                type="button"><BsFiletypeXlsx size={26} /></button>
            </a>
          </div>
        </div>
      ) : (
        <Box>
          <Typography variant="h5" color="#2f215e" style={{ fontWeight: 'bolder' }} align="center">
            Users Data
          </Typography>
          <Box m={2} sx={{
            fontWeight: "bold",
            padding: "8px",
            borderRadius: "10px",
            maxHeight: "90%",
            border: "1px solid #2f215e",
            backgroundColor: "#fefdfe", height: 400, width: "50%", mx: "auto"
          }}>
            <DataGrid rows={rows} columns={columns} processRowUpdate={handleProcessRowUpdate} sx={{
              color:"#2f215e"
            }}/>
          </Box>
          <button disabled={!isValid} color='#2f215e' onClick={handleClick}>Submit</button>

        </Box>
      )
      }
    </>
  );
}

export default PemanentBatch;
