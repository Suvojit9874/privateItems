import { useContext, useEffect, useState } from "react";
import "./UploadPage.css";
import "../../../App.css"
import { MdCloudUpload, MdDelete } from "react-icons/md";
import { SiMicrosoftexcel } from "react-icons/si";
// import { FaFileCsv } from "react-icons/fa6";
import { PiMicrosoftExcelLogoFill } from "react-icons/pi";
import { BsFiletypeXlsx } from "react-icons/bs";
import { Box, Typography } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
// import validator from 'validator';
// import Papa from 'papaparse'
import { Tooltip } from 'react-tooltip'
import { errortoast, successtoast } from "../../ExtraExports/Exports";
import axios from "axios";
import { useCookies } from "react-cookie";
import * as xlsx from 'xlsx'
import { useNavigate } from "react-router-dom";
import { BatchContext } from "../../context/BatchContext";
function UploadPage() {
  const [Cookie, setCookie] = useCookies();
  const { batchName, setBatchName,role,setrole,refresh,setrefresh } = useContext(BatchContext);

  const [file, setFile] = useState(null);
  const [fileName, setFileName] = useState("No selected file");
  const [rows, setRows] = useState([]);
  const [isValid, setisValid] = useState(true)
  const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL
  const navigate = useNavigate()
  useEffect(() => {
    if (rows != []) { checkAllValid() }
  }, rows[1])
  useEffect(() => {

    console.log(REACT_APP_BASE_URL);
  }, [])
  

  const checkDuplicateEmail = (email) => {
    let seen = [], dupl = [];
    rows.filter(user => {
      if (seen.includes(user.email)) {
        dupl.push(user.email)
        return true
      }
      seen.push(user.email)
      return false
    })
    return dupl.includes(email)
  }
  const checkDuplicateId = (empId) => {
    let seen = [], dupl = [];
    let res = rows.filter(user => {
      if (seen.includes(user.empId)) {
        dupl.push(user.empId)
        return true
      }
      seen.push(user.empId)
      return false
    })
    return dupl.includes(empId)
  }
  const validateEmail = (email) => {
    const emailPattern = /^[a-zA-Z0-9._%+-]+@tcs.com$/;
    return emailPattern.test(email)
  };
  const validatePW = (password) => {
    const psPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[@#$%^&!*]).{6,}$/;
    return psPattern.test(password)
  }
  const validateId = (id) => {
    const idPattern = /^[0-9]{6,7}$/;
    return idPattern.test(id)
  }
  const validateBatch = (batch) => {
    const batchPattern = /^[A-Z][0-9]{2,3}$/;
    return batchPattern.test(batch)
  }
  const EmailCell = ({ email }) => {
    return validateEmail(email) && !checkDuplicateEmail(email) ?
      <div style={{ backgroundColor: "", height: "100%", width: "100%" }}>{email}</div> :
      <div data-tooltip-id="email_not_valid"
        data-tooltip-content="Invalid email"
        data-tooltip-place="top"
        style={{ textDecoration: 'underline', color: 'red', height: "100%", width: "100%" }}>
        <Tooltip id="email_not_valid" delayShow={200}
          style={{ backgroundColor: 'grey', color: "white", border: '0' }} />{email}</div>
  }
  const EmailCell2 = ({ email }) => {
    return <div data-tooltip-id="email_not_valid2"
      data-tooltip-content="Duplicate Data"
      data-tooltip-place="top"
      style={{ textDecoration: 'underline', color: 'red', height: "100%", width: "100%" }}>
      <Tooltip id="email_not_valid2" />{email}</div>
  }
  const IdCell = ({ id }) => {
    return validateId(id) && !checkDuplicateId(id) ?
      <div style={{ height: "100%", width: "100%" }}>
        <Tooltip id="id_not_valid" />{id}</div>
      : <div data-tooltip-id="id_not_valid"
        data-tooltip-content="Invalid Id"
        style={{ textDecoration: 'underline', color: 'red', height: "100%", width: "100%" }}>
        <Tooltip id="id_not_valid" />{id}</div>
  }
  const IdCell2 = ({ id }) => {
    return <div data-tooltip-id="id_not_valid2"
      data-tooltip-content="Duplicate Data"
      data-tooltip-place="top"
      style={{ textDecoration: 'underline', color: 'red', height: "100%", width: "100%" }}>
      <Tooltip id="id_not_valid2" />{id}</div>
  }


  const PasswordCell = ({ password }) => {
    return validatePW(password) ?
      <div style={{ backgroundColor: "", height: "100%", width: "100%" }}>
        <Tooltip class="tooltip swing" id="pw_not_valid" />{password}</div>
      :
      <div data-tooltip-id="pw_not_valid"
        data-tooltip-content="Password is not Strong"
        style={{ textDecoration: 'underline', color: 'red', height: "100%", width: "100%" }}>
        <Tooltip id="pw_not_valid" />{password}</div>
  }


  const checkAllValid = () => {
    let allvalid = rows.filter((user) => {

      return !validateEmail(user.email) || !validatePW(user.password)
        || !validateId(user.empId) || checkDuplicateEmail(user.email)
        || checkDuplicateId(user.empId)
    })
    return setisValid(allvalid.length == 0)
  }


  useEffect(() => {

    checkAllValid()
  }, [rows])
  // Submit of bulk data handled
  const handleClick = () => {
    if (isValid) {
      checkAllValid()
      axios({
        url: `${REACT_APP_BASE_URL}/admin/bulk`,
        method: "POST",
        data: rows,
        headers: {
          "Authorization": `Bearer ${Cookie.jwttoken}`
        }
      })
        .then((response) => {
          getBatch()
          setRows([])
          setFile(null)

          setFileName("No selected file")
          successtoast("Data Uploaded Successfully")
          // navigate('/Home/users')
        })
        .catch((error) => {
          errortoast("Can't have duplicate entry");
        });
    }
    else {
      errortoast("Data is invalid");
    }
  }


  const getBatch = () => {
    axios({
      url: `${REACT_APP_BASE_URL}/admin/getBatches`,
      headers: { Authorization: `Bearer ${Cookie.jwttoken}` },
      method: "GET",
    })
      .then((response) => {
        setBatchName(response.data[response.data.length - 1]);
        setrefresh(!refresh);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handleProcessRowUpdate = (updatedRow, originalRow) => {
    const newRows = [...rows];
    const idx = newRows.findIndex((row) => row.id === originalRow.id);
    newRows[idx] = updatedRow;
    setRows(newRows);
    checkAllValid()
    return updatedRow;
    
  };

  function validateJSONFields(jsonArray) {
    const requiredFields = ["email", "id", "empId", "name", "password", "tempBatch", "mainBatch"];
    let out = false;
    jsonArray.forEach((obj, index) => {
      const keys = Object.keys(obj);

      requiredFields.forEach(field => {
        if (!keys.includes(field)) {
          out = true;

        }
      });

      keys.forEach(key => {
        if (!requiredFields.includes(key)) {
          out = true;

        }
      });
    });
    return out;
  }
  const readUploadFile = (e) => {
    e.preventDefault();
    if (e.target.files) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const data = e.target.result;
        const workbook = xlsx.read(data, { type: "array" });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const json = xlsx.utils.sheet_to_json(worksheet);
        console.log(json);
      };
      reader.readAsArrayBuffer(e.target.files[0]);
    }
  }
  const columns = [
    {
      field: "empId", headerName: "EmpId", width: 130, editable: true,
      renderCell: (params) => !checkDuplicateId(params.value) ?
        <IdCell id={params.value} /> : <IdCell2 id={params.value} />
    },
    {
      field: "email", headerName: "Email", width: 200, editable: true,
      renderCell: (params) => !checkDuplicateEmail(params.value) ?
        <EmailCell email={params.value} /> : <EmailCell2 email={params.value} />
    },
    { field: "name", headerName: "Name", width: 150, editable: true, },
    {
      field: "password", headerName: "Password", width: 180, editable: true,
      renderCell: (params) => <PasswordCell password={params.value} />
    },
    { field: "tempBatch", headerName: "Temp Batch", width: 150, editable: true },
    { field: "mainBatch", headerName: "Batch", width: 150, editable: true }
  ];

  return (
    <>
      {rows == "" ? (
        <div className="uploadparent">
          <div className="uploadcenterdiv">
            <div className="page">
              <form className="uploaduserform" onClick={() => {
                document.querySelector(".input-field").click()
              }}>
                <input type="file" accept=".xls,.xlsx" className="input-field" hidden
                  onChange={
                    ({ target: { files } }) => {
                      files[0] && setFileName(files[0].name);
                      if (files) {
                        setFile(URL.createObjectURL(files[0]));
                      }
                      const file = files[0];
                      // readUploadFile()?
                      const fileType =
                        file.name.split('.').pop().toLowerCase();

                      if (fileType !== 'xlsx') {

                        alert('Please upload a xlsx file.');

                        return;
                      }
                      else {
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = (e) => {
                            const data = e.target.result;
                            const workbook = xlsx.read(data, { type: "array" });
                            const sheetName = workbook.SheetNames[0];
                            const worksheet = workbook.Sheets[sheetName];
                            const json = xlsx.utils.sheet_to_json(worksheet);
                            console.log(json);
                            let out = validateJSONFields(json);
                            if (out) {
                              errortoast("Please Provide Valid Data")
                              setRows([])
                              setFile(null)
                              setFileName("No selected file")
                            } else {
                              successtoast("Data read successfully")
                              setRows(json)

                            }
                          };
                          reader.readAsArrayBuffer(file);
                        }
                      }
                     
                      // Papa.parse(file, {
                      //   complete: (result) => {
                      //     let out = validateJSONFields(result.data);
                      //     if (out) {
                      //       errortoast("Please Provide Valid Data")
                      //       setRows([])
                      //       setFile(null)
                      //       setFileName("No selected file")
                      //     } else {
                      //       successtoast("Data read successfully")
                      //       setRows(result.data)

                      //     }
                      //   },
                      //   header: true,
                      // });
                      /* Boilerplate to set up FileReader */

                      // if (fileType !== 'xlsx') {
                      //     const reader = new FileReader();
                      //     reader.onload = (file) => {
                      //         const data = file.target.result;
                      //         const workbook = xlsx.read(data, { type: "array" });
                      //         const sheetName = workbook.SheetNames[0];
                      //         const worksheet = workbook.Sheets[sheetName];
                      //         const json = xlsx.utils.sheet_to_json(worksheet);
                      //         console.log(json);
                      //     };
                      //     reader.readAsArrayBuffer(file.target.files[0]);
                      // }
                    }
                  }
                />
                <div className="uploadpage1"></div>
                {file ? (
                  <>
                    <h3>File uploaded</h3>
                  </>
                ) : (
                  <>
                    <MdCloudUpload color="#2f215e" size={60} />
                    <p>New Batch Data Upload</p>
                  </>
                )}
              </form>
            </div>
            <section className="uploaded-row">
              {/* <AiFillFileImage color='#20c38d' /> */}
              <span className="upload-content">
                {fileName} -
                <MdDelete
                  color="#2f215e"
                  onClick={() => {
                    setFileName("No selected File");
                    setFile(null);
                  }}
                />
              </span>
            </section>
            Click this for sample data  &nbsp;
            <a href={'/SampleUsersData.xlsx'} download="SampleUsersData.xlsx">
              <Tooltip class="tooltip swing" id="sample_csv" />
              <button data-tooltip-id="sample_csv"
                data-tooltip-content="Download sample xlsx"
                type="button" ><BsFiletypeXlsx size={26} /></button>
            </a>
          </div>
        </div>
      ) : (
        <Box>
          <Typography variant="h5" color="#2f215e" style={{ fontWeight: 'bolder' }} align="center">
            Users Data
          </Typography>
          <Box m={2} sx={{
            fontWeight: "bold",
            padding: "8px",
            borderRadius: "10px",
            maxHeight: "90%",
            border: "1px solid #2f215e",
            backgroundColor: "#fefdfe", height: 400, width: "90%", mx: "auto"
          }}>
            <DataGrid rows={rows} columns={columns} processRowUpdate={handleProcessRowUpdate} 
            sx={{
              color:"#2f215e"
            }}
            />
          </Box>
          <button disabled={!isValid} color='#2f215e' onClick={handleClick}>Submit</button>

        </Box>
      )
      }
    </>
  );
}

export default UploadPage;
