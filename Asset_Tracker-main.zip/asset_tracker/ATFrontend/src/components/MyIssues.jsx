import React from 'react'

function MyIssues() {
  return (
    <div>MyIssues</div>
    
  )
}

export default MyIssues