import React, { useState } from "react";
import "./Login.css";
import { useCookies } from "react-cookie";
import axios from "axios";
import { errortoast, successtoast } from "./ExtraExports/Exports";
import { useNavigate } from "react-router-dom";
import "../App.css";
import { FaEye, FaEyeSlash } from "react-icons/fa";
import { BsTablet } from "react-icons/bs";
import { CiDesktopMouse2 } from "react-icons/ci";
import { CiDesktop } from "react-icons/ci";
import { FaMobileScreenButton } from "react-icons/fa6";
import { LiaLaptopSolid } from "react-icons/lia";


const Login = ({ onLogin }) => {
  const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL;

  const [cookies, setCookie] = useCookies();
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [loginDetails, setLoginDetails] = useState({
    email: "",
    password: "",
  });

  const handleSubmit = (event) => {
    event.preventDefault();
    axios({
      url: `${REACT_APP_BASE_URL}/api/v1/auth/authenticate`,
      method: "POST",
      data: loginDetails,
    })
      .then((response) => {
        console.log(response.data.token);
        setCookie("jwttoken", response.data.token, {
          path: "/",
          sameSite: "strict",
        });
        successtoast("Login Success");
        navigate("/Home");
      })
      .catch((error) => {
        errortoast("Login Failed");
        console.error("There was an error authenticating!", error);
      });
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <div className="login-container">
      <div className="login-main">
        <div className="login-left">
          <h1>Asset Tracker</h1>
          <h4>Secure Asset Management</h4>
          <form onSubmit={handleSubmit}>
            <div className="input-group">
              <input
                className="inputbox"
                onChange={(e) =>
                  setLoginDetails({ ...loginDetails, email: e.target.value })
                }
                type="email"
                placeholder="employeeid@tcs.com"
                pattern="[a-z0-9.]+@tcs.com$"
                maxLength={16}
                // ='Please Provide a valid tcs Email ID'
                required
              />
            </div>
            <div className="input-group">
              <input
                className="inputbox"
                onChange={(e) =>
                  setLoginDetails({ ...loginDetails, password: e.target.value })
                }
                maxLength={20}
                type={showPassword ? "text" : "password"}
                
                // label="Please provide a valid password" 
                placeholder="Password"
                required
              />
              <span className="eyebutton" onClick={togglePasswordVisibility}>
                {showPassword ? (
                  <FaEye size={"1.2rem"} />
                ) : (
                  <FaEyeSlash size={"1.2rem"} />
                )}
              </span>
            </div>
            <button type="submit" className="login-btn">
              Login
              <span></span>
            </button>
          </form>
        </div>
        <div className="login-right">
        </div>
      </div>
    </div>
  );
};

export default Login;
