import React from 'react';
import './Navbar.css';

const Navbar = () => {
    return (
        <nav className="navbarl">
            {/* <div className="logol">Asset Tracker</div> */}
            <div className="nav-buttonsl">
                {/* <div className="nav-buttonl">Docs</div> */}
                {/* <div className="nav-buttonl">Sign In</div> */}
            </div>
        </nav>
    );
};

export default Navbar;